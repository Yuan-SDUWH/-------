// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

const db = cloud.database()
const _ = db.command

// 云函数入口函数
exports.main = async (event, context) => {
	const collection = db.collection(event.collection)
	try {
		if(event.type == "insert"){
	    return await collection.add({
			  data: event.data
			})         //insert调用返回的result只包含_id字段 其他data都没有 所以res.result._id存在 res.result.其他 全都是null
		}
//update这里是通过.doc的方式查询_id定位一条记录来更新记录中的字段
		if(event.type == "update"){
	    return await collection.doc(event._id).update({
	      data: event.data
	    })
		}


    if (event.type == "orderBy") {
      return await collection
        .orderBy('ecology._2020_02', 'asc')
        .get({
          complete: function (res) {
            return res
          }
        })
    }

    if (event.type == "orderBy1") {
      return await collection
        .orderBy('donation._2020_02', 'asc')
        .get({
          complete: function (res) {
            return res
          }
        })
    }

    // exports.main = async (event, context) => {
    //   try {
    //     return await db.collection('dbtest').orderBy('createTime', 'desc').get();
    //   } catch (e) {
    //     console.error(e);
    //   }
    // }




    // if (event.type == "orderBy") {
    //   return await where(event.condition)
    //     .orderBy('_id', 'desc')
    //     .get({
    //       complete: function (res) {
    //         return res
//另外写法
    // success: function(res) {
    //   return res;
    // }

    //       }
    //     })
    // }




		if(event.type == "delete"){
	    return await collection.where(event.condition).remove()
		}

		if(event.type == "get"){
      return await collection
        // .field({
        //   test: true
        // })
       .where(event.condition)
		//  .skip(20*event.skip) 
		//  .limit(event.limit) 
        
      .get({
        complete: function (res) {
          return res
        }
      })
    }
  } catch (e) {
    console.error(e)
  }
}

//对应在小程序端如果需要进行数据库操作时，只要调用runDB云函数并传入指定的参数即可 
//下面是查找和更新的两个函数例子 增添数据用AddDoc云函数就行（用runDB也行）
//函数体内要有云函数调用callFunction
// wx.cloud.callFunction({
//   name: 'runDB',
//   data: {
//     type:"get", //指定操作是get  查找
//     collection:"customer", //指定操作的集合
//     condition:{ //指定where查找的要求字段
//        _id:'hhytest0206',
//    //   username:123,
//        学工号:201800820001
    
//     }
//   },
//   complete: res => {
//     this.setData({
//       data: res.result.data,
//     })
//     console.log(res.result.data)
//   }
// })


// wx.cloud.callFunction({
// 	name: 'runDB',
// 	data: {
// 		type:"update", //指定操作是update
// 		collection:"customer", //指定操作的集合
// 		_id:'hhytest0206',
// 		data:{ //指定update的数据
// 			 学院:'数学院',
// 			username:'哈哈哈',
// 		}
// 	},
// 	success: res => {
// 		console.log('[云函数] [updateDB] 已更改Subjcts信息'+res.result)
// 	},
// 	fail: err => {
// 		console.error('[云函数] [updateDB]更改Subject失败', err)
// 	}
// })

