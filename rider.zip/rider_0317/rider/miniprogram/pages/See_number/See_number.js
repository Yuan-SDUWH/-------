//index.js
const app = getApp()
var util = require('../../utils/util.js');
const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`

Page({
  // 捎带物品没有取货码，而是物品内容，填上未接单这一状态
  data: {
    todaydate:'',
    today_year: '',
    today_month: '',
    today_day: '',
    order_day:'',
    my:'',
    income_day:'',
    sales_day:'',
    arry7_number:'',
    sales_number_7:'',
    arry7_income: '',
    sales_income_7: '',
    sales_number_30: '',
    sales_income_30: '',
  },
  onLoad(){
    this.getToday();
    var _customer = wx.getStorageSync('customer');
    console.log('customer',_customer)
    var userid = _customer.stu_ID;

    console.log('userid',userid);
    //console.log(userid);
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "rider", //指定操作的集合
        condition: { //指定where查找的要求字段
          stu_ID: userid
        }
      },
      success: res => {
        this.setData({
          my: res.result.data[0]
        })
      // console.log(this.data.my);
        var todaydate = this.data.todaydate;
        var me = this;
        var today_month=this.data.today_month;
        var today_day = this.data.today_day;
        var today_year = this.data.today_year;
        console.log(todaydate)
//今日接单数量
        if (typeof me.data.my.sales_number[todaydate] != 'undefined') {
          me.setData({
            sales_day: me.data.my.sales_number[todaydate],
          });
          console.log(me.data.sales_day)
        }
        else { console.log("查不到") }
//今日接单收入
        if (typeof me.data.my.income[todaydate] != 'undefined') {
          me.setData({
            income_day: me.data.my.income[todaydate],
          });
     //     console.log(me.data.order_day)
        }
        else { console.log("查不到") }
//近7天接单数量
       var arry7_number=[0,0,0,0,0,0,0];
       var j=0;
       var date;
       var i;
       var m;
        if(today_day>7){
            i=today_day-7;
            
            for(i;i<today_day;i++){
              date = "_" + today_year+ '_' +today_month + '_' + i;
              if (typeof me.data.my.sales_number[date] != 'undefined'){
                arry7_number[j]=me.data.my.sales_number[date];
                }
              else{
                arry7_number[j] = 0;
              }
              j++;
            }
       //     console.log(arry7_number)
        }
        //日<=7时，考虑上个月末(暂时没考虑！！！！！！)
        else{
          j = 7 - today_day + 1;//上个月的最后j天
          for(i=1;i<today_day;i++){           
              date = "_" + today_year + '_' + today_month + '_' + i;
              arry7_number[j] = me.data.my.sales_number[date];
              j++;
          }
          j = 7 - today_day + 1;//上个月的最后j天
          for(i=0;i<j;i++){
            arry7_number[i]=0;
          }
       //   console.log(arry7_number)
        }
        me.setData({
          arry7_number: arry7_number 
        })
        var sales_number_7=0;
        for(j=0;j<7;j++){
          sales_number_7 = sales_number_7 + arry7_number[j];
          
        }
        me.setData({
          sales_number_7:sales_number_7
        })
       // console.log(me.data.sales_number_7)
//近7天接单收入
        var arry7_income = [0, 0, 0, 0, 0, 0, 0];
        var j = 0;
        var date;
        var i;
        var m;
        if (today_day > 7) {
          i = today_day - 7;

          for (i; i < today_day; i++) {
            date = "_" + today_year + '_' + today_month + '_' + i;
            if (typeof me.data.my.income[date] != 'undefined') {
              arry7_income[j] = me.data.my.income[date];
            }
            else {
              arry7_income[j] = 0;
            }
            j++;
          }
        //  console.log(arry7_income)
        }
        //日<=7时，考虑上个月末(暂时没考虑！！！！！！)
        else {
          j = 7 - today_day + 1;//上个月的最后j天
          for (i = 1; i < today_day; i++) {
            date = "_" + today_year + '_' + today_month + '_' + i;
            arry7_income[j] = me.data.my.income[date];
            j++;
          }
          j = 7 - today_day + 1;//上个月的最后j天
          for (i = 0; i < j; i++) {
            arry7_income[i] = 0;
          }
          console.log(arry7_income)
        }
        me.setData({
          arry7_income: arry7_income
        })
        var sales_income_7 = 0;
        for (j = 0; j < 7; j++) {
          sales_income_7 = sales_income_7 + arry7_income[j];

        }
        me.setData({
          sales_income_7: sales_income_7
        })
       // console.log(me.data.sales_income_7)
//上个月接单数量
      var arry_number_30=[];
      var last_month=today_month-1;
      var time;
      for(i=0;i<31;i++){
        j=i+1;
        time = "_" + today_year + '_' + last_month + '_' + j;
        if (typeof me.data.my.sales_number[time] != 'undefined') {
          arry_number_30[i] = me.data.my.sales_number[time];
        }
        else{
          arry_number_30[i] =0;
        }
     //   console.log(arry_number_30[i])
      }
      var sales_number_30=0; 
      for(i=0;i<31;i++){
        sales_number_30 = sales_number_30 + arry_number_30[i];
        //console.log(sales_number_30)
      }
      me.setData({
        sales_number_30: sales_number_30
      })
      console.log(me.data.sales_number_30)   

        //上个月接单收入
        var arry_income_30 = [];
        var last_month = today_month - 1;
        var time;
        for (i = 0; i < 31; i++) {
          j = i + 1;
          time = "_" + today_year + '_' + last_month + '_' + j;
          if (typeof me.data.my.income[time] != 'undefined') {
            arry_income_30[i] = me.data.my.income[time];
          }
          else {
            arry_income_30[i] = 0;
          }
          console.log(arry_income_30[i])
        }
        var sales_income_30 = 0;
        for (i = 0; i < 31; i++) {
          sales_income_30 = sales_income_30 + arry_income_30[i];
          //console.log(sales_number_30)
        }
        me.setData({
          sales_income_30: sales_income_30
        })
        console.log(me.data.sales_income_30)   
  

      }
    })




  },
  onShow() {
  
  },
  getToday: function () {

    var timestamp = Date.parse(new Date());
    var date = new Date(timestamp);
    //获取年份  
    var Y = date.getFullYear();
    //获取月份  
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    //获取当日日期 
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    // console.log("_" + Y + '_' + M + '_' + D);
    var todaydate = "_" + Y + '_' + M + '_' + D;
    var today = this;

    today.setData({
      today_year: Y,
      today_month: M,
      today_day: D,
      todaydate: todaydate,
    });
    //console.log(today.data.todaydate);
    // console.log(today.data.today_month);
    // console.log(today.data.today_day)

  }
})