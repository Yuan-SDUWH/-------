const db = wx.cloud.database()
var util = require('../../utils/util.js');
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    currtab: 0,
    swipertab: [{ name: '进行中', index: 0 }, { name: '加急送', index: 1 },{ name: '已完成', index: 2 }],
    id:'',
    success_order_url:''
    
  },
 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // 页面渲染完成
    this.getDeviceInfo()
    this.orderShow()
  },
  //订单完成后点击  实现改变订单状态+上传图片
  SuccessOrder:function(e){
  //先上传图片
    //获取点击的订单id为$_id
    var $_id = e.currentTarget.dataset.id; //打印可以看到，此处已获取到了对应的id
    console.log($_id)
    var that = this;
    var date = util.formatTime1(new Date());
    var minutes = util.formatTime2(new Date());
    //让用户选择或拍摄一张照片
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        //选择完成会先返回一个临时地址保存备用
        const tempFilePaths = res.tempFilePaths
        console.log('tempFilePaths为', tempFilePaths)
        //将照片上传至云端需要刚才存储的临时地址
        wx.cloud.uploadFile({
          cloudPath: 'order/' + $_id + '/' + 'successOrder.png',
          filePath: tempFilePaths[0],        
          success(res) {
            //上传成功后会返回永久地址
            console.log('tempFilePaths[0]为', tempFilePaths[0])
            console.log('res.fileID为',res.fileID)
            that.setData({
              success_order_url: res.fileID
            })
            wx.cloud.callFunction({
                name: 'runDB',
                data: {
                  type:"update", //指定操作是update
                  collection:"extra_need", //指定操作的集合
                  _id: $_id,
                  data:{ //指定update的数据
                    success_order_url: res.fileID,
                    当前状态:'已完成',
                    'time_to_date': date,
                    'time_to_minutes':minutes
                  }
                },
                success: res => {
                  console.log('已经上传图片地址' + res.fileID)
                },
                fail: err => {
                  console.error('上传失败', err)
                }
              })
            that.onReady();
            console.log('能加载的')
          }
        })
      }
    })
   

  },
  getDeviceInfo: function () {
    let that = this
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          deviceW: res.windowWidth,
          deviceH: res.windowHeight
        })
      }
    })
  },
 
  /**
  * @Explain：选项卡点击切换
  */
  tabSwitch: function (e) {
    var that = this
    if (this.data.currtab === e.target.dataset.current) {
      return false
    } else {
      that.setData({
        currtab: e.target.dataset.current
      })
    }
  },
 
  tabChange: function (e) {
    this.setData({ currtab: e.detail.current })
    this.orderShow()
  },
 
  orderShow: function () {
    let that = this
    switch (this.data.currtab) {
      case 0:
        that.alreadyShow()
        break
      case 1:
        that.waitPayShow()
        break
      case 2:
        that.lostShow()
        break
    }
  },

  //进行中（不要被英文迷惑！）
 alreadyShow:function(){
   var stu_ID = wx.getStorageSync('stu_ID');
  

  wx.cloud.callFunction({
    name: 'runDB',
    data: {
      type:"get", //指定操作是get  查找
      collection:"extra_need", //指定操作的集合
      condition:{ //指定where查找的要求字段
         //rider: '201800820109',
        rider_ID: stu_ID,
         当前状态:'已接单'
      }
    },
    complete: res => {
      console.log('ridermenu',res.result.data)
      for(var i=0;i<res.result.data.length;i++){
        res.result.data[i].qh=res.result.data[i].取货地址
        delete res.result.data[i].取货地址
        res.result.data[i].sd=res.result.data[i].送达地点
        delete res.result.data[i].送达地点
        res.result.data[i].state=res.result.data[i].当前状态
        delete res.result.data[i].当前状态
        res.result.data[i].rapid=res.result.data[i].是否加急
        delete res.result.data[i].是否加急
        res.result.data[i].goods_money=res.result.data[i].货物价值_元
        delete res.result.data[i].货物价值_元
        res.result.data[i].rider_money=res.result.data[i].跑腿费
        delete res.result.data[i].跑腿费
        res.result.data[i].goods_num=res.result.data[i].取货码
        delete res.result.data[i].取货码
      }
      this.setData({
        ne1:res.result.data,
  })

      }

    })
 },

 
  waitPayShow:function(){
    var _customer = wx.getStorageSync('customer');
    var rider_stuID = _customer.stu_ID;
    console.log('riderstuID',rider_stuID)
  
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type:"get", //指定操作是get  查找
        collection:"extra_need", //指定操作的集合
        condition:{ //指定where查找的要求字段
          // 接单骑手stu_ID: rider_stuID,
          rider_ID: rider_stuID,
          当前状态:'已接单',
          是否加急:'Yes'
        }
      },
      complete: res => {
        console.log('ridermenu',res.result.data)
        for(var i=0;i<res.result.data.length;i++){
          res.result.data[i].qh=res.result.data[i].取货地址
          delete res.result.data[i].取货地址
          res.result.data[i].sd=res.result.data[i].送达地点
          delete res.result.data[i].送达地点
          res.result.data[i].state=res.result.data[i].当前状态
          delete res.result.data[i].当前状态
          res.result.data[i].rapid=res.result.data[i].是否加急
          delete res.result.data[i].是否加急
          res.result.data[i].goods_money=res.result.data[i].货物价值_元
          delete res.result.data[i].货物价值_元
          res.result.data[i].rider_money=res.result.data[i].跑腿费
          delete res.result.data[i].跑腿费
          res.result.data[i].goods_num=res.result.data[i].取货码
          delete res.result.data[i].取货码
        }
        this.setData({
          ne2:res.result.data,
    })
  
        }
  
      })
  },

 
  lostShow: function (){
    var _customer = wx.getStorageSync('customer');
    var rider_stuID = _customer.stu_ID;
    console.log('riderstuID',rider_stuID)
  
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type:"get", //指定操作是get  查找
        collection:"extra_need", //指定操作的集合
        condition:{ //指定where查找的要求字段
           //接单骑手stu_ID: rider_stuID,
           rider_ID: rider_stuID,
           当前状态:'已完成',
        }
      },
      complete: res => {
        console.log('ridermenu',res.result.data)
        for(var i=0;i<res.result.data.length;i++){
          res.result.data[i].qh=res.result.data[i].取货地址
          delete res.result.data[i].取货地址
          res.result.data[i].sd=res.result.data[i].送达地点
          delete res.result.data[i].送达地点
          res.result.data[i].state=res.result.data[i].当前状态
          delete res.result.data[i].当前状态
          res.result.data[i].rapid=res.result.data[i].是否加急
          delete res.result.data[i].是否加急
          res.result.data[i].goods_money=res.result.data[i].货物价值_元
          delete res.result.data[i].货物价值_元
          res.result.data[i].rider_money=res.result.data[i].跑腿费
          delete res.result.data[i].跑腿费
          res.result.data[i].goods_num=res.result.data[i].取货码
          delete res.result.data[i].取货码
          res.result.data[i].rider_point=res.result.data[i].服务评分
          delete res.result.data[i].服务评分
        }
        this.setData({
          ne3:res.result.data,
    })
  
        }
  
      })
  },
})
 
