const db = wx.cloud.database()

Page({
  data: {
    ne: [],
    isSignin: false
  },

  onShow: function () {
    var _isSignin = wx.getStorageSync('isSignin');
    this.setData({
      isSignin: _isSignin
    })

    var _customer = wx.getStorageSync('customer');
    let target = _customer.stu_ID

    console.log('tar',target)
    if(typeof(target) == "undefined"){
      console.log('undefined')
      this.setData({
        isSignin:false
      })
    } else {
      db.collection('customer').where({
        // _openid: this.data.orderInfo
        stu_ID: target
      })
        .get({
          success: res => {
            console.log(res.data)
            for (var i = 0; i < res.data.length; i++) {
              res.data[i].grade = res.data[i].年级
              delete res.data[i].年级
              res.data[i].college = res.data[i].学院
              delete res.data[i].学院
            }
            this.setData({
              ne: res.data,
            })
          }
        })
      }

      var _customer = wx.getStorageSync('customer');
      var target0 = _customer.stu_ID
  
        console.log('tar',target0)

        db.collection('rider').where({
          stu_ID:target0
      })
        .get({
          success: res => {
            console.log('chenggong',res.data[0].rider_name)
          if(typeof(res.data[0].rider_name) !== "undefined"){
            this.setData({
              nen: res.data[0].rider_name
            })
          } else {
            db.collection('customer').where({
              stu_ID: target0
          })
            .get({
              success: res => {
                console.log(res.data[0].username)
              this.setData({
                nen: res.data[0].username
              })
            }
            })



          }         
        }
        })
  },

  Changeicon:function(){
    wx.navigateTo({
      url: '/pages/homepage/homepage',
    })
  },

  //进入主页
  home() {
    wx.switchTab({
      url: '/pages/homepage/homepage',
    })
  },


  //进入账号管理
  setting() {
    wx.navigateTo({
      url: '/pages/setting/setting',
    })
  },

  //初次进入点击登录注册跳转
  signinorup() {
    wx.navigateTo({
      url: '/pages/signin/signin',
    })
  },

  //进入意见反馈
  feedback() {
    wx.navigateTo({
      url: '/pages/feedback/feedback',
    })
  },

  //进入评价情况
  evaluation() {
    wx.navigateTo({
      url: '/pages/evaluation/evaluation',
    })
  },

  //收入统计
  my_menu() {
    wx.navigateTo({
      url: '/pages/riderFinancial/riderFinancial',
    })
  }




})

