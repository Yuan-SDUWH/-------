// pages/evaluation/evaluation.js
const db = wx.cloud.database()

Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (){
    var _customer = wx.getStorageSync('customer');
      var target0 = _customer.stu_ID
  
        console.log('tar',target0)

        db.collection('rider').where({
          stu_ID:target0
      })
        .get({
          success: res => {
            console.log('chenggong',res.data[0].rider_name)
          if(typeof(res.data[0].rider_name) !== "undefined"){
            this.setData({
              nen: res.data[0].rider_name
            })
          } else {
            db.collection('customer').where({
              stu_ID: target0
          })
            .get({
              success: res => {
                console.log(res.data[0].username)
              this.setData({
                nen: res.data[0].username
              })
            }
            })
          }         
        }
        })
   

    let target = _customer.stu_ID

    console.log('tar',target)
   
    // db.collection('customer').where({
    //   // _openid: this.data.orderInfo
    //   stu_ID: target
    // })
    //   .get({
    //     success: res => {
          
    //     this.setData({
    //       ne1: res.data,
    //     })      
      // }
      // })
    

    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type:"get", //指定操作是get  查找
        collection:"extra_need", //指定操作的集合
        condition:{ //指定where查找的要求字段
          rider_ID: target,
          当前状态:'已完成'
        }
      },
      complete: res => {
        console.log('看一下',res.result.data)
        var sum = 0
        let scorenum = res.result.data.length
        console.log('数量',typeof(scorenum))

        for(var i=0;i<res.result.data.length;i++){
          sum = sum + res.result.data[i].服务评分
          console.log('sumnow',sum)
          // res.result.data[i].score_sum=res.result.data[i].综合评分
          // delete res.result.data[i].综合评分
        }
        // let totalscore = this.data.sum
        this.setData({
          ne2: (sum)/scorenum
          // ne2: res.result.data,
        }) 
        console.log('ne2',this.data.ne2)  
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  enter(){
    wx.navigateTo({
      url: '/pages/point_detail/point_detail',
    })
  }
})