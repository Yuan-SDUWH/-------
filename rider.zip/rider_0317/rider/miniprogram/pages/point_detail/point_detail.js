// pages/order/order.js
//var util = require('../../utils/util.js');
const db = wx.cloud.database()
Page({
 
  /**
   * 页面的初始数据
   */
  data: {

    
  },
 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
 
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  //   // 页面渲染完成
  //   this.getDeviceInfo()
  //   this.orderShow()
  // },
 
  // getDeviceInfo: function () {
  //   let that = this
  //   wx.getSystemInfo({
  //     success: function (res) {
  //       that.setData({
  //         deviceW: res.windowWidth,
  //         deviceH: res.windowHeight
  //       })
  //     }
  //   })
  // },
 
  // lostShow: function (){
    var _customer = wx.getStorageSync('customer');
    var rider_stuID = _customer.stu_ID;
    console.log('riderstuID',rider_stuID)
  
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type:"get", //指定操作是get  查找
        collection:"extra_need", //指定操作的集合
        condition:{ //指定where查找的要求字段
           //接单骑手stu_ID: rider_stuID,
           rider_ID: rider_stuID,
           当前状态:'已完成',
        }
      },
      complete: res => {
        console.log('ridermenu',res.result.data)
        for(var i=0;i<res.result.data.length;i++){
          res.result.data[i].qh=res.result.data[i].取货地址
          delete res.result.data[i].取货地址
          res.result.data[i].sd=res.result.data[i].送达地点
          delete res.result.data[i].送达地点
          res.result.data[i].state=res.result.data[i].当前状态
          delete res.result.data[i].当前状态
          res.result.data[i].rapid=res.result.data[i].是否加急
          delete res.result.data[i].是否加急
          res.result.data[i].goods_money=res.result.data[i].货物价值_元
          delete res.result.data[i].货物价值_元
          res.result.data[i].rider_money=res.result.data[i].跑腿费
          delete res.result.data[i].跑腿费
          res.result.data[i].goods_num=res.result.data[i].取货码
          delete res.result.data[i].取货码
          res.result.data[i].rider_point=res.result.data[i].服务评分
          delete res.result.data[i].服务评分
        }
        this.setData({
          ne3:res.result.data,
    })
  
        }
  
      })
  },
})
 
