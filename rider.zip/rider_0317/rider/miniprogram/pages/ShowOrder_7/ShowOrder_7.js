// pages/addFunction/addFunction.js

// const _ = db.command
// db.collection('todos')


var util = require('../../utils/util.js');
const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`
Page({
  data: {
    time: '',
    today: '',
    showOrder_today:[],
    today_year: '',
    today_month: '',
    today_day: '',
  
    // currentTab: 0,
    // navbar: ['日', '周'],
  },
  //   navbarTap: function (e) {
  //   this.setData({
  //     currentTab: e.currentTarget.dataset.idx   
      
  //   })
  //   //全局变量
  //   // app.globalData.currentTab = e.currentTarget.dataset.idx;
  //    console.log(e)
  //  if(this.data.currentTab==0){
  //    var userid = wx.getStorageSync('stu_ID');
  //    this.getToday();
  //    var me = this;
  //    var time;
  //    var today_month=me.data.today_month-1+1;
  //    var today_day = me.data.today_day-1 + 1;
  
  //    time = '_' + me.data.today_year + '_' + today_month + '_' + today_day;
  //    console.log(time)
  //    wx.cloud.callFunction({
  //      name: 'runDB',
  //      data: {
  //        type: "get", //指定操作是get  
  //        collection: "extra_need", //指定操作的集合
  //        condition: { //指定where查找的要求字段
  //          rider_ID: userid,
  //          time_to_date: time
  //        }
  //      },
  //      success: res => {
  //        this.setData({
  //          showOrder_today: res.result.data
  //        });
  //        console.log("第一天", res.result.data)
  //      }
  //    })
  //  }
  //   else {
  //     wx.navigateTo({
  //       url: '../income_chart/income_chart'
  //     })
  //   }


  // },
  getToday: function () {

    var timestamp = Date.parse(new Date());
    var date = new Date(timestamp);
    //获取年份  
    var Y = date.getFullYear();
    //获取月份  
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    //获取当日日期 
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    // console.log("_" + Y + '_' + M + '_' + D);
    var todaydate = "_" + Y + '_' + M + '_' + D;
    var today = this;

    today.setData({
      today_year: Y,
      today_month: M,
      today_day: D,
    });
  },

  onLoad: function () {

    // this.navbarTap({ currentTarget: { dataset: { idx: 0 } } });
     this.getToday();
     var userid = wx.getStorageSync('stu_ID');
    var me = this;
    var time;
    var today_day = me.data.today_day;
    var today_month = me.data.today_month;
    var i=0;
    var seven_date=[];
    if(today_day>7){
      for(i=0;i<7;i++){
        seven_date[i] = today_day-7+i;
      }
    }
 //第一天
    time = '_' + me.data.today_year + '_' + today_month + '_' + seven_date[0];
       console.log(time)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "extra_need", //指定操作的集合
        condition: { //指定where查找的要求字段
          rider_ID: userid,
          time_to_date: time       
        }
      },
      success: res => {
        this.setData({
          showOrder1: res.result.data
        });
      console.log("第一天",res.result.data)
      }
    })
//     //第二天
    time = '_' + me.data.today_year + '_' + today_month + '_' + seven_date[1];
    console.log(time)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "extra_need", //指定操作的集合
        condition: { //指定where查找的要求字段
          rider_ID: userid,
          time_to_date: time
        }
      },
      success: res => {
        this.setData({
          showOrder2: res.result.data
        });
        console.log("第2天", res.result.data)
      }
    })
//     //第三天
    time = '_' + me.data.today_year + '_' + today_month + '_' + seven_date[2];
    console.log(time)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "extra_need", //指定操作的集合
        condition: { //指定where查找的要求字段
          rider_ID: userid,
          time_to_date: time
        }
      },
      success: res => {
        this.setData({
          showOrder3: res.result.data
        });
        console.log("第3天", res.result.data)
      }
    })
//     //第四天
    time = '_' + me.data.today_year + '_' + today_month + '_' + seven_date[3];
    console.log(time)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "extra_need", //指定操作的集合
        condition: { //指定where查找的要求字段
          rider_ID: userid,
          time_to_date: time
        }
      },
      success: res => {
        this.setData({
          showOrder4: res.result.data
        });
        console.log("第4天", res.result.data)
      }
    })
//     //第五天
    time = '_' + me.data.today_year + '_' + today_month + '_' + seven_date[4];
    console.log(time)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "extra_need", //指定操作的集合
        condition: { //指定where查找的要求字段
          rider_ID: userid,
          time_to_date: time
        }
      },
      success: res => {
        this.setData({
          showOrder5: res.result.data
        });
        console.log("第5天", res.result.data)
      }
    })
    //     //第6天
    time = '_' + me.data.today_year + '_' + today_month + '_' + seven_date[5];
    console.log(time)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "extra_need", //指定操作的集合
        condition: { //指定where查找的要求字段
          rider_ID: userid,
          time_to_date: time
        }
      },
      success: res => {
        this.setData({
          showOrder6: res.result.data
        });
        console.log("第6天", res.result.data)
      }
    })
    //     //第7天
    time = '_' + me.data.today_year + '_' + today_month + '_' + seven_date[6];
    console.log(time)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "extra_need", //指定操作的集合
        condition: { //指定where查找的要求字段
          rider_ID: userid,
          time_to_date: time
        }
      },
      success: res => {
        this.setData({
          showOrder7: res.result.data
        });
        console.log("第7天", res.result.data)
      }
    })



  },
  onShow() {

    // this.setData({
    //   currentTab: 0
    // })

  },
});

