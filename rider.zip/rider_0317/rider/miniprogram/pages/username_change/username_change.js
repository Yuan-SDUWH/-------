// pages/username_change/username_change.js
const db = wx.cloud.database()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    username: '',

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

      var _customer = wx.getStorageSync('customer');
      let target = _customer.stu_ID
  
        console.log('tar',target)

        db.collection('rider').where({
          stu_ID:target
      })
        .get({
          success: res => {
            console.log('chenggong',res.data[0].rider_name)
          if(typeof(res.data[0].rider_name) !== "undefined"){
            this.setData({
              ne: res.data[0].rider_name
            })
          } else {
            db.collection('customer').where({
              stu_ID: target
          })
            .get({
              success: res => {
                console.log(res.data[0].username)
              this.setData({
                ne: res.data[0].username
              })
            }
            })



          }         
        }
        })



        
    },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  
   //获取账号
   inputName(event) {
     console.log('获取输入的用户名', event.detail.value)
     this.setData({
       username: event.detail.value
     })
    },

   signup(){
    var _customer = wx.getStorageSync('customer');
    let target = _customer.stu_ID

      console.log('tar',target)

            db.collection('rider').where({
        stu_ID:target
    })
      .get({
        success: res => {
          console.log('chenggong',res.data[0])
          this.setData({
            _id :res.data[0]._id

          })
console.log('id',this.data._id)
let rider_id = this.data._id

      //   }
      // })

      wx.cloud.callFunction({
	name: 'runDB',
	data: {
		type:"update", //指定操作是update
    collection:"rider", //指定操作的集合
    _id:this.data._id,
		// stu_ID:'201800820109',
		data:{ //指定update的数据
			 rider_name:this.data.username
		}
	},
	success: res => {
    console.log('[云函数] [updateDB] 已更改Subjcts信息'+res.result)
    wx.showToast({
    title: '设置成功',
  })
  setTimeout(function(){
    wx.navigateTo({
      url: '/pages/mine/mine',
    })
  },2000)
},            
           
	fail: err => {
    console.error('[云函数] [updateDB]更改Subject失败', err)
    wx.showToast({
      title: '设置成失败',
      icon:"none"
    })
	}
})
}
      })
    }
  })

    //   db.collection('rider').where({
    //     stu_ID:target
    // })
    //   .get({
    //     success: res => {
    //       console.log('chenggong',res.data[0])

    //       let _id = res.data[0]._id

    //     if(typeof(res.data[0].rider_name) !== "undefined"){
    //       db.collection('rider').doc(_id).update({
    //         data:{
    //           rider_name:this.data.username
    //         },
    //         success(res){
    //           console.log,
    //           wx.showToast({
    //           title: '修改成功',
    //         }),
    //           wx.navigateTo({
    //            url: '/pages/setting/setting',
    //          })
    //        },
    //         fail(res){
    //          console.error,
    //          wx.showToast({
    //            icon: 'none',
    //            title: '修改失败',
    //          })
    //         } 
    //        })
    //       } else {
    //         console.log('添加',_id,this.data.username,target)
    //         db.collection('rider').doc(_id).update({
    //           data:{
    //             rider_name:this.data.username
    //           },             
    //           success(res){
    //             console.log('添加成功'),
    //             wx.showToast({
    //             title: '骑手昵称设置成功',
    //           }),
    //             wx.navigateTo({
    //              url: '/pages/setting/setting',
    //            })
    //          },
    //           fail(res){
    //            console.error,
    //            wx.showToast({
    //              icon: 'none',
    //              title: '昵称设置失败',
    //            })
    //           } 
    //          })
    //          console.log('跳过')
    //       }
          
          
        //   this.setData({
        //     ne: res.data[0].rider_name
        //   })
        // } else {
        //   db.collection('customer').where({
        //     // _openid: this.data.orderInfo
        //     stu_ID: target
    
        
        // db.collection('customer').where({
          //done: false,
          //progress: 50,
          // _openid: this.data.orderInfo
        // })
        //   .get({
        //     success: res => {
        //       console.log(res.data[0].username)
        //     //success: console.log,
        //     this.setData({
        //       ne: res.data[0].username
        //     })
        //   }
        //   })



        // }         
      
    



      












    // if(this.data.username.length <= 0){
    //   wx.showToast({
    //     icon: 'none',
    //     title: '昵称不能为空',
    //   })} else {

    //     //修改本地
    //     var _customer = wx.getStorageSync('customer');
    //     let username=this.data.username;
    //     console.log(username)
    //     _customer.username = username;
    //     wx.setStorageSync('customer', _customer);

    //     //修改云端
    //     var _id= _customer._id
    //  db.collection('customer').doc(_id).update({
    //    data:{
    //      username:this.data.username
    //    },
    //    success(res){
    //      console.log,
    //      wx.showToast({
    //      title: '修改成功',
    //    }),
    //      wx.navigateTo({
    //       url: '/pages/setting/setting',
    //     })
    //   },
    //    fail(res){
    //     console.error,
    //     wx.showToast({
    //       icon: 'none',
    //       title: '修改失败',
    //     })
    //    } 
    //   })
    //  }
    //   }
    // })


  
//更改本地username
// let username = this.data.username
// var _customer = wx.getStorageSync('customer');
// _customer.username = username;
// wx.setStorageSync('customer', _customer)
