//index.js
const app = getApp()
var util = require('../../utils/util.js');
const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`

Page({
  // 捎带物品没有取货码，而是物品内容，填上未接单这一状态
  data: {
    navbar: ['日', '周','月'],
    currentTab: 0,
  
  },
  onLoad(){
 
  },
  Tochart() {
    wx.navigateTo({
      url: '../income_chart/income_chart'
    })
  },
  ToOrder() {
    wx.navigateTo({
      url: '../ShowOrder_1/ShowOrder_1'
    })
  },
  ToSeeNumber() {
    wx.navigateTo({
      url: '../See_number/See_number'
    })
  },
  //切换bar
  // navbarTap: function (e) {
  //   this.setData({
  //     currentTab: e.currentTarget.dataset.idx   
  //   })
  //   //全局变量
  //   // app.globalData.currentTab = e.currentTarget.dataset.idx;
  //   console.log(e.currentTarget.dataset.idx)
  //  if(this.data.currentTab==0){
  //    wx.navigateTo({
  //      url: '../ShowOrder_1/ShowOrder_1'
  //    })
  //  }
  //   else if (this.data.currentTab == 1) {
  //     wx.navigateTo({
  //       url: '../ShowOrder_1/ShowOrder_1'
  //     })
  //   }
  //   else {
  //     wx.navigateTo({
  //       url: '../ShowOrder_1/ShowOrder_1'
  //     })
  //   }
    
  // },
  onShow() {
   
    this.setData({
      currentTab: 0
    })
  
  },
  

})