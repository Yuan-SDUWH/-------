const app = getApp()
var util = require('../../utils/util.js');
const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`

Page({
  data: {
    star: 0
  },
  inputComment(event) {
    console.log('获取输入的评价', event.detail.value)
    this.setData({
      commentdetail: event.detail.value
    })
  },
  select: function (event) {
    this.setData({
      star: event.detail
    })
    console.log("传递成功啦", this.data.star)
  },
  select_speed: function (event) {
    this.setData({
      star_speed: event.detail
    })
    console.log("传递成功啦", this.data.star)
  },
  select_taste: function (event) {
    this.setData({
      star_taste: event.detail
    })
    console.log("传递成功啦", this.data.star)
  },
  select_health: function (event) {
    this.setData({
      star_health: event.detail
    })
    console.log("传递成功啦", this.data.star)
  },
  star_ratings: function (e) {
    wx.showToast({

      title: '感谢您的评价',

    })
    var comment;
    var comment_speed;
    var comment_taste;
    var comment_health;
    var Star_ID = wx.getStorageSync('i_d');
    var Star_OrderID=wx.getStorageSync('$order_id');
    
    var star = this.data.star;
    var star_speed=this.data.star_speed;
    var star_taste=this.data.star_taste;
    var star_health=this.data.star_health;
    var commentdetail=this.data.commentdetail;
    console.log('XINGXINg',star)
    wx.cloud.callFunction({
      name:'runDB',
      data:{
        type:"get",
        collection:"store",
        condition:{
          _id:Star_ID,
        }
      },
      success: res=> {
        console.log(res.result.data[0]);
        comment=res.result.data[0].comment;
        comment_speed = res.result.data[0].comment_speed;
        comment_taste = res.result.data[0].comment_taste;
        comment_health = res.result.data[0].comment_health;
        comment.push(star);
        comment_speed.push(star_speed);
        comment_taste.push(star_taste);
        comment_health.push(star_health);
        
        wx.cloud.callFunction({
          name: 'runDB',
          data: {
            type: "update", //指定操作是update
            collection: "store", //指定操作的集合
            _id: Star_ID,
            data: { //指定update的数据
              comment_speed: comment_speed,
              comment_taste:comment_taste,
              comment_health:comment_health,
              comment: comment,
            }
          },
          success: res => {
            console.log('[云函数] [updateDB] 已更改当前状态信息' + star)
            wx.cloud.callFunction({
              name:'runDB',
              data:{
                type:"update",
                collection:"order",
                _id: Star_OrderID,
                data:{
                  是否已评价:true,
                  出餐速度评分:star_speed,
                  好吃程度评分:star_taste,
                  饮食卫生评分:star_health,
                  综合评分:star,
                  用户评价:commentdetail,
                }
              },
              success: res =>{
                console.log('又一个三层嵌套');
              }
            })
            wx.switchTab({
              url: '../my_order/my_order',
            })
            
          },
          fail: err => {
            console.error('[云函数] [updateDB]更改当前状态失败', err)
          }
        })
      }
    })

  }


})

// Component({
//   /**
//    * 组件的属性列表
//    */
//   properties: {

//   },

//   /**
//    * 组件的初始数据
//    */
//   data: {
//     imgs: [{
//       id: 1
//     }, {
//       id: 2
//     }, {
//       id: 3
//     }, {
//       id: 4
//     }, {
//       id: 5
//     }],
//     starId: 0,
//     src1: '../../images/Star/Yellow.png',
//     src2: '../../images/Star/white.png',
//   },

//   /**
//    * 组件的方法列表
//    */
//   methods: {
//     select(e) {
//       console.log(e)
//       this.data.starId = e.currentTarget.dataset.index;
//       this.setData({
//         starId: this.data.starId
//       });

//     }
//   },

// })
