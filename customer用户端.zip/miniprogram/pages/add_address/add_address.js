// pages/username_change/username_change.js
const db = wx.cloud.database()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    new_address: '',
    // id:'024dd936-4717-464b-a75c-6ef1f446cb2d'

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      var that = this;
      wx.getStorage({
        key: 'customer',
        success: function (res) {
          that.setData({
            orderInfo: res.data._openid
          })
        }
      }),
  
      
      db.collection('customer').where({
        //done: false,
        //progress: 50,
        _openid: 'orderInfo'
      })
        .get({
          success: res => {
            console.log(res.data)
          //success: console.log,
          this.setData({
            ne: res.data
          })
        }
        })
    },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  
   //获取账号
   inputName(event) {
     console.log('获取输入的地址', event.detail.value)
     
     var _customer = wx.getStorageSync('customer');
     var _address=_customer.address;
     
     _address.push({地址:event.detail.value})

     console.log('原始',_address)
     
     this.setData({
      address:_address
      })
    //  this.setData({
    //   address: event.detail.value
    // })
    },

   signup(){
     let add_address= this.data.address
    // var _customer = wx.getStorageSync('customer');
    // var _address=_customer.address;
console.log('获取数据库',add_address)
    // if(this.data.add_address.length <= 0){
    //   wx.showToast({
    //     icon: 'none',
    //     title: '地址不能为空',
    //   })} else {

        //修改本地
        var _customer = wx.getStorageSync('customer');

        _customer.address = add_address;
        wx.setStorageSync('customer', _customer);
        


        // }

        

        //修改云端
        var _id= _customer._id
      db.collection('customer').doc(_id).update({
       data:{
         address: add_address
       },
       success(res){
         console.log,
         wx.showToast({
         title: '修改成功',
         duration:2000
       })
       setTimeout(function(){
        wx.navigateTo({
          url: '/pages/adress/adress',
        }),2000
    
      })

        //  wx.navigateTo({
        //   url: '/pages/setting/setting',
        // })
      },
       fail(res){
        console.error,
        wx.showToast({
          icon: 'none',
          title: '修改失败',
        })
       } 
      })
    },
     })
      
    


  
//更改本地username
// let username = this.data.username
// var _customer = wx.getStorageSync('customer');
// _customer.username = username;
// wx.setStorageSync('customer', _customer)
 