// miniprogram/pages/search/search.js
Page({
  data: {
      inputShowed: false,
      inputVal: ""
  },

  onLoad:function(event){
    let _this = this
    //获取全部店家
    wx.cloud.callFunction({ name: 'getDATA', data: { _DBName: 'store'} })
    .then(res => {
      let allStores = res.result.data;
      console.log("allStores: ", allStores);
      for( var i=0;i<res.result.data.length;i++){//数组对key操作：中英字符转换-英文数据绑定wxml
        res.result.data[i].safetyScore=res.result.data[i].饮食卫生评分
        delete res.result.data[i].饮食卫生评分
        res.result.data[i].tasteScore=res.result.data[i].好吃程度评分
        delete res.result.data[i].好吃程度评分
        res.result.data[i].speedScore=res.result.data[i].出餐速度评分
        delete res.result.data[i].出餐速度评分
        res.result.data[i].totalScore=res.result.data[i].综合评分
        delete res.result.data[i].综合评分
      }
      _this.setData({allStores:res.result.data})
    })
  },

  showInput: function () {
      this.setData({
          inputShowed: true
      });
  },
  hideInput: function () {
      this.setData({
          inputVal: "",
          inputShowed: false
      });
  },
  clearInput: function () {
      this.setData({
          inputVal: ""
      });
  },
  inputTyping: function (e) {
      this.setData({
          inputVal: e.detail.value
      });
      let value = e.detail.value;
      console.log(value)
  //    this.setData({ searchContent: value });
      var regStr = `.*${value}`
      var reg = RegExp(`${regStr}`);
      //查询项目的名字
      let allStores = this.data.allStores;
      let res = allStores.filter(item => {
        let storeName = item.store_name;
        if (reg.test(storeName)) {return item }
        let goods=item.goods
        if(goods!=undefined){
            for(var i=0;i<goods.length;i++){
                if(reg.test(goods[i][0].商品名称)){return item}
            }
        }
      });
      if (this.data.inputVal.length > 0) {this.setData({searchStores:res})} 
      else {this.setData({ searchStores: allStores })}
  },
  toDetailStore:function(event){
    wx.navigateTo({
      url: '../storeDetail/storeDetail?store_id='+event.currentTarget.dataset.id,
    })
  }
});