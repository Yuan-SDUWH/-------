var util = require('../../utils/util.js');

Page({
  data:{

  },
  onLoad:function(options){
    var _d=new Date()
    _d = new Date(_d.valueOf() + 60 * 1000 * 20);// 当前时间加上20分钟
    var time = util.formatTime3(_d);
    var date = util.formatTime4(_d);
    console.log(time,date)
  }



})