// pages/adress/adress.js
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    var that = this;
    wx.getStorage({
      key: 'customer',
      success: function (res) {
        that.setData({
          orderInfo: res.data._openid
        })
      }
    }),

      db.collection('customer').where({
        _openid: 'orderInfo'
      })
        .get({
          success: res => {
            console.log('res',res.data)
            console.log('addressc',res.data[0].address.length)
            for(var i=0;i<res.data.length;i++){
              for(var j=0;j<res.data[0].address.length;j++){
              
              res.data[i].address[j]._address=res.data[i].address[j].地址
              delete res.data[i].address[j].地址

                
            }
            
            }
            console.log(res.data[0].address)
            //success: console.log,
            this.setData({
              ne: res.data[0].address
            })

          }
        })


  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },


  add(){
    wx.navigateTo({
      url: '/pages/add_address/add_address',
    })




  }
})