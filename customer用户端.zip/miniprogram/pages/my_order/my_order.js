// pages/order/order.js
//var util = require('../../utils/util.js');
const db = wx.cloud.database()
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    hiddenmodalput: true,
    hiddenmodalput_refund: true,
    hiddenmodalput_cancel: true,
    hiddenmodalput_cancel_10: true,
    space: '  ',
    tabCur: 0, //默认选中
    tabs: [{
      name: '未接单',
      id: 0
    },
    {
      name: '正常进行',
      id: 1
    },
    {
      name: '已完成',
      id: 2
    },
    {
      name: '待取消',
      id: 3
    },
    {
      name: '已取消',
      id: 4
    },
    {
      name: '待赔付',
      id: 5
    },
    {
      name: '已赔付',
      id: 6
    },
    {
      name: '待退款',
      id: 7
    },
    {
      name: '已退款',
      id: 8
    },
    {
      name: '预订单',
      id: 9
    },
    {
      name: '催单',
      id: 10
    },
    {
      name: '已拒单',
      id: 11
    },
    ]

  },
  //条件筛选导航栏
  tabSelect(e) {
    console.log('点到了！', e.currentTarget.dataset.id)
    this.setData({
      tabCur: e.currentTarget.dataset.id,
      scrollLeft: (e.currentTarget.dataset.id - 2) * 200
    })
    this.onReady()
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
 
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // 页面渲染完成
    this.getDeviceInfo()
    this.orderShow()
  },
 
  getDeviceInfo: function () {
    let that = this
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          deviceW: res.windowWidth,
          deviceH: res.windowHeight
        })
      }
    })
  },
 
  /**
  * @Explain：选项卡点击切换
  */
  /*
  tabSwitch: function (e) {
    var that = this
    if (this.data.currtab === e.target.dataset.current) {
      return false
    } else {
      that.setData({
        currtab: e.target.dataset.current
      })
    }
  },
  */
 /*
  tabChange: function (e) {
    this.setData({ currtab: e.detail.current })
    this.orderShow()
  },
  */
 
  orderShow: function () {
    let that = this
    switch (this.data.tabCur) {
      case 0:
        that.waitPayShow()
        break
      case 1:
        that.ongoingShow()
        break
      case 2:
        that.alreadyShow()
        break
      case 3:
        that.prelostShow()
        break
      case 4:
        that.lostShow()
        break
      case 5:
        that.precompensateShow()
        break
      case 6:
        that.compensateShow()
        break
      case 7:
        that.prerefundShow()
        break
      case 8:
        that.refundShow()
        break
      case 9:
        that.futureShow()
        break
      case 10:
        that.hurryShow()
        break
      case 11:
        that.rejectShow()
        break
    }
  },

 
  waitPayShow:function () {
    var _customer = wx.getStorageSync('customer');
    var orderInfo = _customer._openid;
    //console.log(orderInfo)

    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type:"get", //指定操作是get  查找
        collection:"order", //指定操作的集合
        condition:{ //指定where查找的要求字段
          _openid: orderInfo,
          订单状态:'未接单'
        }
      },
    complete: res => {
  
      for (var i = 0; i < res.result.data.length; i++) {
        res.result.data[i].money = res.result.data[i].应付金额_元
        delete res.result.data[i].应付金额_元
        res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
        delete res.result.data[i].date_order
        delete res.result.data[i].time_order
        res.result.data[i].state = res.result.data[i].订单状态
        delete res.result.data[i].订单状态
        res.result.data[i].name = res.result.data[i].store_name
        delete res.result.data[i].store_name
        res.result.data[i].url = res.result.data[i].store_icon_url
        delete res.result.data[i].store_icon_url
        res.result.data[i].goods = res.result.data[i].goodsList
        delete res.result.data[i].goodsList
      }
      console.log('调试',res.result.data),
      this.setData({
        ne1:res.result.data,
    })
      }
    })
  },


  ongoingShow: function () {
    var _customer = wx.getStorageSync('customer');
    var orderInfo = _customer._openid;
    //console.log(orderInfo)

    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          _openid: orderInfo,
          订单状态: '正常进行'
        }
      },
      complete: res => {
        console.log('正常进行订单信息', res)
        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          delete res.result.data[i].date_order
          delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
          if (res.result.data[i].拒绝取消原因 == undefined) {
            res.result.data[i].cancelRejectReason = '!@#'
          }
          else if (res.result.data[i].拒绝取消原因 != undefined) {
            res.result.data[i].cancelRejectReason = res.result.data[i].拒绝取消原因
            delete res.result.data[i].拒绝取消原因
          }
        }
        console.log('xx调试', res.result.data),
          this.setData({
            ne2: res.result.data,
          })
      }
    })
  }, 

//已完成
  alreadyShow: function () {
    var _customer = wx.getStorageSync('customer');
    var orderInfo = _customer._openid;
    //console.log(orderInfo)

    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          _openid: orderInfo,
          订单状态: '已完成'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          delete res.result.data[i].date_order
          delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
          res.result.data[i].storeid = res.result.data[i].接单商家id
          delete res.result.data[i].接单商家id
          if (res.result.data[i].拒绝赔付原因 == undefined) {
            res.result.data[i].compensateRejectReason = '!@#'
          }
          else if (res.result.data[i].拒绝赔付原因 != undefined) {
            res.result.data[i].compensateRejectReason = res.result.data[i].拒绝赔付原因
            delete res.result.data[i].拒绝赔付原因
          }
          if (res.result.data[i].拒绝退款原因 == undefined) {
            res.result.data[i].refundRejectReason = '!@#'
          }
          else if (res.result.data[i].拒绝退款原因 != undefined) {
            res.result.data[i].refundRejectReason = res.result.data[i].拒绝退款原因
            delete res.result.data[i].拒绝退款原因
          }
          if (res.result.data[i].是否已评价 == true) {
            res.result.data[i].commentflag = '!@#'
          }
          /*
          else if (res.result.data[i].拒绝退款原因 != undefined) {
            res.result.data[i].refundRejectReason = res.result.data[i].拒绝退款原因
            delete res.result.data[i].拒绝退款原因
          }
          */

        }
        console.log('调试', res.result.data),
          this.setData({
            ne3: res.result.data,
          })
      }
    })
  },


  //待取消
  prelostShow: function () {
    var _customer = wx.getStorageSync('customer');
    var orderInfo = _customer._openid;
    //console.log(orderInfo)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          _openid: orderInfo,
          订单状态: '待取消'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          delete res.result.data[i].date_order
          delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
          res.result.data[i].cancelReason = res.result.data[i].申请取消原因
          delete res.result.data[i].申请取消原因
        }
        console.log('调试', res.result.data),
          this.setData({
            ne4: res.result.data,
          })
      }
    })
  },

  //已取消
  lostShow: function () {
    var _customer = wx.getStorageSync('customer');
    var orderInfo = _customer._openid;
    //console.log(orderInfo)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          _openid: orderInfo,
          订单状态: '已取消'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          delete res.result.data[i].date_order
          delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
          res.result.data[i].cancelReason = res.result.data[i].申请取消原因
          delete res.result.data[i].申请取消原因
        }
        console.log('调试', res.result.data),
          this.setData({
            ne5: res.result.data,
          })
      }
    })
  },

  //待赔付
  precompensateShow: function () {
    var _customer = wx.getStorageSync('customer');
    var orderInfo = _customer._openid;
    //console.log(orderInfo)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          _openid: orderInfo,
          订单状态: '待赔付'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          delete res.result.data[i].date_order
          delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
          res.result.data[i].compensateReason = res.result.data[i].申请赔付原因
          delete res.result.data[i].申请赔付原因
        }
        console.log('调试', res.result.data),
          this.setData({
            ne6: res.result.data,
          })
      }
    })
  },

  //已赔付
  compensateShow: function () {
    var _customer = wx.getStorageSync('customer');
    var orderInfo = _customer._openid;
    //console.log(orderInfo)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          _openid: orderInfo,
          订单状态: '已赔付'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          delete res.result.data[i].date_order
          delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
          res.result.data[i].compensateReason = res.result.data[i].申请赔付原因
          delete res.result.data[i].申请赔付原因
        }
        console.log('调试', res.result.data),
          this.setData({
            ne7: res.result.data,
          })
      }
    })
  },

  //待退款
  prerefundShow: function () {
    var _customer = wx.getStorageSync('customer');
    var orderInfo = _customer._openid;
    //console.log(orderInfo)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          _openid: orderInfo,
          订单状态: '待退款'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          delete res.result.data[i].date_order
          delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
          res.result.data[i].refundReason = res.result.data[i].申请退款原因
          delete res.result.data[i].申请退款原因
        }
        console.log('调试', res.result.data),
          this.setData({
            ne8: res.result.data,
          })
      }
    })
  },

  //退款
  refundShow: function () {
    var _customer = wx.getStorageSync('customer');
    var orderInfo = _customer._openid;
    //console.log(orderInfo)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          _openid: orderInfo,
          订单状态: '已退款'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          delete res.result.data[i].date_order
          delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
          res.result.data[i].refundReason = res.result.data[i].申请退款原因
          delete res.result.data[i].申请退款原因
        }
        console.log('调试', res.result.data),
          this.setData({
            ne9: res.result.data,
          })
      }
    })
  },

  //预订单
  futureShow: function () {
    var _customer = wx.getStorageSync('customer');
    var orderInfo = _customer._openid;
    //console.log(orderInfo)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          _openid: orderInfo,
          订单状态: '预订单'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          delete res.result.data[i].date_order
          delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
        }
        console.log('调试', res.result.data),
          this.setData({
            ne10: res.result.data,
          })
      }
    })
  },


  //催单
  hurryShow: function () {
    var _customer = wx.getStorageSync('customer');
    var orderInfo = _customer._openid;
    //console.log(orderInfo)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          _openid: orderInfo,
          订单状态: '催单'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          delete res.result.data[i].date_order
          delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
        }
        console.log('调试', res.result.data),
          this.setData({
            ne11: res.result.data,
          })
      }
    })
  },



  //拒单
  rejectShow: function () {
    var _customer = wx.getStorageSync('customer');
    var orderInfo = _customer._openid;
    //console.log(orderInfo)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          _openid: orderInfo,
          订单状态: '已拒单'
        }
      },
      complete: res => {
        console.log('FINISH')
        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          delete res.result.data[i].date_order
          delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
          res.result.data[i].rejectReason = res.result.data[i].拒单原因
          delete res.result.data[i].拒单原因
        }
        console.log('调试', res.result.data),
          this.setData({
            ne12: res.result.data,
          })
      }
    })
  },




//正常进行订单ne2
  /*****申请取消的几个函数******/
  cancelOG:function(e){
    var index = e.currentTarget.dataset.index;
    this.setData({
      hiddenmodalput_cancel: !this.data.hiddenmodalput_cancel,
      cancelIndex: index,
    })
  },

  cancel_cancel: function () {
    this.setData({
      hiddenmodalput_cancel: true,
    });
  },

  confirm_cancel: function () {
    var that = this;
    var index = this.data.cancelIndex;
    let ongoingOrders = that.data.ne2;
    var _id = ongoingOrders[index]._id;
    console.log('IDDDDDD', _id)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "update",
        collection: "order",
        _id: _id,
        data: {
          订单状态: '待取消',
          申请取消原因: that.data.cancelReason,
        }
      },
      success: res => {
        console.log('成功了！');
      }
    })
    this.setData({
      hiddenmodalput_cancel: true
    })
    that.onReady()
  },



  inputCancelReason: function (e) {
    console.log(e.detail.value)
    var reason = e.detail.value
    this.setData({
      cancelReason: reason,
    })
  },




  /**********催单***********/
  hurryOG: function (e) {
    var that = this;
    var index = e.currentTarget.dataset.index;
    console.log('IDX',index);
    let ongoingOrders = that.data.ne2;
    var _id = ongoingOrders[index]._id;
    wx.showModal({
      title: "催单",
      content: "确定要催单吗？将心比心，多多理解",
      showCancel: true,
      cancelText: "取消",
      cancelColor: "#000",
      confirmText: "确定",
      confirmColor: "#0a0",
      success: function (res) {
        console.log(res)
        if (res.confirm) {
          wx.cloud.callFunction({
            name: 'runDB',
            data: {
              type: "update",
              collection: "order",
              _id: _id,
              data: {
                订单状态: '催单',
              }
            },
            success: res => {
              console.log('催单成功了！');
            }
          })
        }
      }
    })
  },


  /**********确认收货***********/
  recieveOG: function (e) {
    var that = this;
    var index = e.currentTarget.dataset.index;
    console.log('IDX', index);
    let ongoingOrders = that.data.ne2;
    var _id = ongoingOrders[index]._id;
    var storeid = ongoingOrders[index].接单商家id;
    wx.showModal({
      title: "确认收货",
      content: "要确认收货吗？",
      showCancel: true,
      cancelText: "取消",
      cancelColor: "#000",
      confirmText: "确定",
      confirmColor: "#0a0",
      success: function (res) {
        console.log(res)
        if (res.confirm) {
          wx.cloud.callFunction({
            name: 'runDB',
            data: {
              type: "update",
              collection: "order",
              _id: _id,
              data: {
                订单状态: '已完成',
              }
            },
            success: res => {
              console.log('确认收货成功了！');
              wx.cloud.callFunction({
                name:'runDB',
                data:{
                  type:"get",
                  collection:"store",
                  condition:{
                    _id:storeid
                  }
                },
                success: res => {
                  console.log('AAAAAA',res.result.data[0])//res.result.data[0]是商家Object
                  var datex = ongoingOrders[index].time;
                  var date = '_' + datex[0] + datex[1] + datex[2] + datex[3] + '_' + datex[5] + datex[6] + '_' + datex[8] + datex[9];//凑出_2020_03_17这种格式
                  var month = '_' + datex[0] + datex[1] + datex[2] + datex[3] + '_' + datex[5] + datex[6]
                  var donationall = res.result.data[0].donation; 
                  //donationall={'_2020_03_12':12,'_2020_03_14':9.8,...}
                  var countall = res.result.data[0].sales_number;
                  //countall={'_2020_03_12':7,'_2020_03_14':9,...}
                  var salesall = res.result.data[0].sales;
                  //salesall={'_2020_03_12':120,'_2020_03_14':123,...}
                  var goods=ongoingOrders[index].goods;
                  console.log('GOODS',goods);
                  var money=ongoingOrders[index].实付金额_元;
                  var donatemoney=0;
                  var donationTMPvalue;//临时值
                  var countTMPvalue;//临时值
                  var salesTMPvalue;//临时值
                  var key;
                  var value;
                  console.log('月份🈷️',month)
                  console.log('日期📅',date);
                  for(var i=0;i<goods.length;i++)
                  {
                    donatemoney+=(goods[i].price+goods[i].packFee)*goods[i].num*goods[i].公益抽成百分比*0.01;//一个订单的捐赠额
                  }//循环出来以后donatemoney就是捐赠额对应的value

                  //donatemoney是公益捐助额value，money是收入额value，countall里面对应的value记得+1，三个兼职对的key都是date
                  console.log('全捐出去！！',donationall)
                  console.log('donationall/month', donationall[month])
                  if(donationall[month]==undefined){
                    //如果之前大的键值对组中没有这条订单的日期key
                    key=month;
                    value=donatemoney;
                    donationall[key]=value;
                  }
                  else if(donationall[month]!=undefined){
                    donationTMPvalue=donationall[month];
                    donationTMPvalue+=donatemoney;
                    console.log('donation', donationTMPvalue)
                    donationall[month]=donationTMPvalue;
                  }
                  console.log('countall/date', countall[date])
                  if(countall[date]==undefined){
                    key=date;
                    value=1;
                    countall[key]=value;
                  }
                  else if (countall[date] != undefined){
                    countTMPvalue=countall[date];
                    countTMPvalue+=1;
                    console.log('count', countTMPvalue)
                    countall[date]=countTMPvalue;
                  }
                  console.log('salesall/date', salesall[date])
                  if(salesall[date]==undefined){
                    key=date;
                    value=money;
                    salesall[key]=value;
                  }
                  else if(salesall[date]!=undefined)
                  {
                    salesTMPvalue=salesall[date];
                    salesTMPvalue+=money;
                    console.log('sales',salesTMPvalue)
                    salesall[date]=salesTMPvalue;
                  }
                  
                  
                  //[{'_2020_03_16':120},{'_2020_03_17':220}]


                  wx.cloud.callFunction({
                    name:'runDB',
                    data:{
                      type:"update",
                      collection:"store",
                      _id:storeid,
                      data:{
                        donation: donationall,
                        sales_number: countall,
                        sales: salesall,
                      },
                    },
                    success: res => {
                      console.log(res);
                      console.log('三层嵌套');
                    },
                  })
                }
              })
            }
          })
        }
        that.onReady()
      }
    })
  },


//已完成订单ne3
/*******以下几个是赔付函数**********/
  compensateOG:function(e){
    var index = e.currentTarget.dataset.index;
    this.setData({
      hiddenmodalput: !this.data.hiddenmodalput,
      compensateIndex: index,
    })
    
  },

  cancel: function () {
    this.setData({
      hiddenmodalput: true
    });
  },

  confirm: function () {
    var that=this;
    var index = this.data.compensateIndex;
    let ongoingOrders = that.data.ne3;
    var _id = ongoingOrders[index]._id;
    console.log('IDDDDDD',_id)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "update",
        collection: "order",
        _id: _id,
        data: {
          订单状态: '待赔付',
          申请赔付原因: that.data.compensateReason,
          申请赔付金额: that.data.compensatePrice,
        }
      },
      success: res => {
        console.log('成功了！');
      }
    })
    this.setData({
      hiddenmodalput: true
    })
    that.onReady()
  },

  inputCompensateReason: function (e) {
    console.log(e.detail.value)
    var reason=e.detail.value
    this.setData({
      compensateReason: reason,
    })
  },

  inputCompensatePrice: function (e) {
    console.log(e.detail.value)
    var price = e.detail.value
    this.setData({
      compensatePrice: price,
    })
  },

  commentOG:function(e){
    console.log(e);
    console.log(e.currentTarget.dataset.id);
    var i_d = e.currentTarget.dataset.id
    var $i_d=e.currentTarget.dataset.idd
    wx.setStorageSync('i_d', i_d);
    wx.setStorageSync('$order_id', $i_d)
    wx.navigateTo({
      url: '../Star2/Star2',
    })
  },

  closeComment:function(){
    console.log('HelloWORLD!');
  },



/*****退款函数*********/
  refundOG:function(e){
    var index = e.currentTarget.dataset.index;
    this.setData({
      hiddenmodalput_refund: !this.data.hiddenmodalput_refund,
      refundIndex: index,
    })
  },

  cancel_refund: function () {
    this.setData({
      hiddenmodalput_refund: true,
    });
  },

  confirm_refund: function () {
    var that = this;
    var index = this.data.refundIndex;
    let ongoingOrders = that.data.ne3;
    var _id = ongoingOrders[index]._id;
    console.log('IDDDDDD', _id)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "update",
        collection: "order",
        _id: _id,
        data: {
          订单状态: '待退款',
          申请退款原因: that.data.refundReason,
        }
      },
      success: res => {
        console.log('成功了！');
      }
    })
    this.setData({
      hiddenmodalput_refund: true
    })
    that.onReady()
  },



  inputRefundReason: function (e) {
    console.log(e.detail.value)
    var reason = e.detail.value
    this.setData({
      refundReason: reason,
    })
  },


  //预订单ne10
  /*****申请取消的几个函数******/
  cancelOG_10: function (e) {
    var index = e.currentTarget.dataset.index;
    this.setData({
      hiddenmodalput_cancel_10: !this.data.hiddenmodalput_cancel_10,
      cancelIndex: index,
    })
  },

  cancel_cancel_10: function () {
    this.setData({
      hiddenmodalput_cancel_10: true,
    });
  },

  confirm_cancel_10: function () {
    var that = this;
    var index = this.data.cancelIndex;
    let ongoingOrders = that.data.ne10;
    var _id = ongoingOrders[index]._id;
    console.log('IDDDDDD', _id)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "update",
        collection: "order",
        _id: _id,
        data: {
          订单状态: '待取消',
          申请取消原因: that.data.cancelReason,
        }
      },
      success: res => {
        console.log('成功了！');
      }
    })
    this.setData({
      hiddenmodalput_cancel_10: true
    })
    that.onReady()
  },



  inputCancelReason_10: function (e) {
    console.log(e.detail.value)
    var reason = e.detail.value
    this.setData({
      cancelReason: reason,
    })
  },




  /**********催单***********/
  hurryOG_10: function (e) {
    console.log(e.currentTarget.dataset.index);
    var index = e.currentTarget.dataset.index;
    var that = this;
    let ongoingOrders = that.data.ne2;
    var _id = ongoingOrders[index]._id;
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "update",
        collection: "order",
        _id: _id,
        data: {
          hurryFLAG: 1,
        }
      }
    })
  },


  recieveOG_10: function (e) {
    var that = this;
    var index = e.currentTarget.dataset.index;
    console.log('IDX', index);
    let ongoingOrders = that.data.ne10;
    var _id = ongoingOrders[index]._id;
    var storeid = ongoingOrders[index].接单商家id;
    wx.showModal({
      title: "确认收货",
      content: "要确认收货吗？",
      showCancel: true,
      cancelText: "取消",
      cancelColor: "#000",
      confirmText: "确定",
      confirmColor: "#0a0",
      success: function (res) {
        console.log(res)
        if (res.confirm) {
          wx.cloud.callFunction({
            name: 'runDB',
            data: {
              type: "update",
              collection: "order",
              _id: _id,
              data: {
                订单状态: '已完成',
              }
            },
            success: res => {
              console.log('确认收货成功了！');
              wx.cloud.callFunction({
                name: 'runDB',
                data: {
                  type: "get",
                  collection: "store",
                  condition: {
                    _id: storeid
                  }
                },
                success: res => {
                  console.log('AAAAAA', res.result.data[0])//res.result.data[0]是商家Object
                  var datex = ongoingOrders[index].time;
                  var date = '_' + datex[0] + datex[1] + datex[2] + datex[3] + '_' + datex[5] + datex[6] + '_' + datex[8] + datex[9];//凑出_2020_03_17这种格式
                  var month = '_' + datex[0] + datex[1] + datex[2] + datex[3] + '_' + datex[5] + datex[6]
                  var donationall = res.result.data[0].donation;
                  //donationall={'_2020_03_12':12,'_2020_03_14':9.8,...}
                  var countall = res.result.data[0].sales_number;
                  //countall={'_2020_03_12':7,'_2020_03_14':9,...}
                  var salesall = res.result.data[0].sales;
                  //salesall={'_2020_03_12':120,'_2020_03_14':123,...}
                  var goods = ongoingOrders[index].goods;
                  console.log('GOODS', goods);
                  var money = ongoingOrders[index].实付金额_元;
                  var donatemoney = 0;
                  var donationTMPvalue;//临时值
                  var countTMPvalue;//临时值
                  var salesTMPvalue;//临时值
                  var key;
                  var value;
                  console.log('月份🈷️', month)
                  console.log('日期📅', date);
                  for (var i = 0; i < goods.length; i++) {
                    donatemoney += (goods[i].price + goods[i].packFee) * goods[i].num * goods[i].公益抽成百分比 * 0.01;//一个订单的捐赠额
                  }//循环出来以后donatemoney就是捐赠额对应的value

                  //donatemoney是公益捐助额value，money是收入额value，countall里面对应的value记得+1，三个兼职对的key都是date
                  console.log('全捐出去！！', donationall)
                  console.log('donationall/month', donationall[month])
                  if (donationall[month] == undefined) {
                    //如果之前大的键值对组中没有这条订单的日期key
                    key = month;
                    value = donatemoney;
                    donationall[key] = value;
                  }
                  else if (donationall[month] != undefined) {
                    donationTMPvalue = donationall[month];
                    donationTMPvalue += donatemoney;
                    console.log('donation', donationTMPvalue)
                    donationall[month] = donationTMPvalue;
                  }
                  console.log('countall/date', countall[date])
                  if (countall[date] == undefined) {
                    key = date;
                    value = 1;
                    countall[key] = value;
                  }
                  else if (countall[date] != undefined) {
                    countTMPvalue = countall[date];
                    countTMPvalue += 1;
                    console.log('count', countTMPvalue)
                    countall[date] = countTMPvalue;
                  }
                  console.log('salesall/date', salesall[date])
                  if (salesall[date] == undefined) {
                    key = date;
                    value = money;
                    salesall[key] = value;
                  }
                  else if (salesall[date] != undefined) {
                    salesTMPvalue = salesall[date];
                    salesTMPvalue += money;
                    console.log('sales', salesTMPvalue)
                    salesall[date] = salesTMPvalue;
                  }


                  //[{'_2020_03_16':120},{'_2020_03_17':220}]


                  wx.cloud.callFunction({
                    name: 'runDB',
                    data: {
                      type: "update",
                      collection: "store",
                      _id: storeid,
                      data: {
                        donation: donationall,
                        sales_number: countall,
                        sales: salesall,
                      },
                    },
                    success: res => {
                      console.log(res);
                      console.log('三层嵌套');
                    },
                  })
                }
              })
            }
          })
        }
        that.onReady()
      }
    })
  },


})
 
