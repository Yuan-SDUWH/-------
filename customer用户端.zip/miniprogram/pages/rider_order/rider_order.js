// pages/order/order.js
//var util = require('../../utils/util.js');
const db = wx.cloud.database()
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    currtab: 0,
    swipertab: [{ name: '进行中', index: 0 }, { name: '待接单', index: 1 },{ name: '已完成', index: 2 }],
    id:''
    
  },
  onShow: function () {

    this.onLoad() 

  },

 GetDetail:function(e){

   var $_id = e.currentTarget.dataset.id; //打印可以看到，此处已获取到了对应的id
   console.log($_id)
   wx.setStorage({

     key: "Star_ID",

     data: $_id

   }),
   wx.navigateTo({
     url: '../Star/Star',
   })
 },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
 
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // 页面渲染完成
    this.getDeviceInfo()
    this.orderShow()
  },
 
  getDeviceInfo: function () {
    let that = this
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          deviceW: res.windowWidth,
          deviceH: res.windowHeight
        })
      }
    })
  },
 
  /**
  * @Explain：选项卡点击切换
  */
  tabSwitch: function (e) {
    var that = this
    if (this.data.currtab === e.target.dataset.current) {
      return false
    } else {
      that.setData({
        currtab: e.target.dataset.current
      })
    }
  },
 
  tabChange: function (e) {
    this.setData({ currtab: e.detail.current })
    this.orderShow()
  },
 
  orderShow: function () {
    let that = this
    switch (this.data.currtab) {
      case 0:
        that.alreadyShow()
        break
      case 1:
        that.waitPayShow()
        break
      case 2:
        that.lostShow()
        break
    }
  },

  //进行中（不要被英文迷惑！）
 alreadyShow:function(){
  var _customer = wx.getStorageSync('customer');
  var customer_ID = _customer._openid;
   console.log('customer_ID',customer_ID)

  wx.cloud.callFunction({
    name: 'runDB',
    data: {
      type:"get", //指定操作是get  查找
      collection:"extra_need", //指定操作的集合
      condition:{ //指定where查找的要求字段
         //rider: '201800820109',
        _openid: customer_ID,
         当前状态:'已接单'
      }
    },
    complete: res => {
      console.log('ridermenu',res.result.data)
      for(var i=0;i<res.result.data.length;i++){
        res.result.data[i].qh=res.result.data[i].取货地址
        delete res.result.data[i].取货地址
        res.result.data[i].sd=res.result.data[i].送达地点
        delete res.result.data[i].送达地点
        res.result.data[i].state=res.result.data[i].当前状态
        delete res.result.data[i].当前状态
        res.result.data[i].rapid=res.result.data[i].是否加急
        delete res.result.data[i].是否加急
        res.result.data[i].goods_money=res.result.data[i].货物价值_元
        delete res.result.data[i].货物价值_元
        res.result.data[i].rider_money=res.result.data[i].跑腿费
        delete res.result.data[i].跑腿费
        res.result.data[i].goods_num=res.result.data[i].取货码
        delete res.result.data[i].取货码
      }
      this.setData({
        ne1:res.result.data,
  })

      }

    })
 },

 
  waitPayShow:function(){
    var _customer = wx.getStorageSync('customer');
    var customer_ID = _customer._openid;
    console.log('customer_ID', customer_ID)
  
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type:"get", //指定操作是get  查找
        collection:"extra_need", //指定操作的集合
        condition:{ //指定where查找的要求字段
          // 接单骑手stu_ID: rider_stuID,
          _openid: customer_ID,
          当前状态:'待接单',
        }
      },
      complete: res => {
        console.log('ridermenu',res.result.data)
        for(var i=0;i<res.result.data.length;i++){
          res.result.data[i].qh=res.result.data[i].取货地址
          delete res.result.data[i].取货地址
          res.result.data[i].sd=res.result.data[i].送达地点
          delete res.result.data[i].送达地点
          res.result.data[i].state=res.result.data[i].当前状态
          delete res.result.data[i].当前状态
          res.result.data[i].rapid=res.result.data[i].是否加急
          delete res.result.data[i].是否加急
          res.result.data[i].goods_money=res.result.data[i].货物价值_元
          delete res.result.data[i].货物价值_元
          res.result.data[i].rider_money=res.result.data[i].跑腿费
          delete res.result.data[i].跑腿费
          res.result.data[i].goods_num=res.result.data[i].取货码
          delete res.result.data[i].取货码
        }
        this.setData({
          ne2:res.result.data,
    })
  
        }
  
      })
  },

 
  lostShow: function (){
    var _customer = wx.getStorageSync('customer');
    var customer_ID = _customer._openid;
    console.log('customer_ID', customer_ID)
  
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type:"get", //指定操作是get  查找
        collection:"extra_need", //指定操作的集合
        condition:{ //指定where查找的要求字段
           //接单骑手stu_ID: rider_stuID,
          _openid: customer_ID,
           当前状态:'已完成',
        }
      },
      complete: res => {
        console.log('ridermenu',res.result.data)
        for(var i=0;i<res.result.data.length;i++){
          res.result.data[i].qh=res.result.data[i].取货地址
          delete res.result.data[i].取货地址
          res.result.data[i].sd=res.result.data[i].送达地点
          delete res.result.data[i].送达地点
          res.result.data[i].state=res.result.data[i].当前状态
          delete res.result.data[i].当前状态
          res.result.data[i].rapid=res.result.data[i].是否加急
          delete res.result.data[i].是否加急
          res.result.data[i].goods_money=res.result.data[i].货物价值_元
          delete res.result.data[i].货物价值_元
          res.result.data[i].rider_money=res.result.data[i].跑腿费
          delete res.result.data[i].跑腿费
          res.result.data[i].goods_num=res.result.data[i].取货码
          delete res.result.data[i].取货码
          res.result.data[i].rider_point=res.result.data[i].服务评分
          delete res.result.data[i].服务评分
        }
        this.setData({
          ne3:res.result.data,
    })
  
        }
  
      })
  },
})
 
