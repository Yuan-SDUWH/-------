const db = wx.cloud.database()

  Page({
    data: {
      ne:[],
      isSignin:false
    },

    onShow: function (){
      var _isSignin = wx.getStorageSync('isSignin');
      this.setData({
        isSignin: _isSignin
      })
    // },

    // onLoad: function (){
   
    // var that = this;
    // wx.getStorage({
    //   key: 'customer',
    //   success: function (res) {
    //     that.setData({
    //       orderInfo: res.data.stu_ID
    //     })
    //   }
    // })
    // let target = this.data.orderInfo
    // console.log('tar',this.data.target)
    var _customer = wx.getStorageSync('customer');
    let target = _customer.stu_ID

    console.log('tar',target)

  
    db.collection('customer').where({
      //done: false,
      //progress: 50,
      stu_ID: target
    })
      .get({
        success: res => {
          console.log(res.data)

          for(var i=0;i<res.data.length;i++){
            res.data[i].grade=res.data[i].年级
            delete res.data[i].年级
            res.data[i].college=res.data[i].学院
            delete res.data[i].学院
          }
        this.setData({
          ne: res.data,
          coupon_total:res.data[0].coupon
        })
console.log('necoupon',this.data.ne,this.data.coupon_total)
        var couple_total_num = 0

        for(var i=0;i<res.data[0].coupon.length;i++){     
          couple_total_num += res.data[0].coupon[i].coupon_num
          }
          this.setData({
            _number:couple_total_num
          })

        var credit_total_num = 0

          for(var i=0;i<res.data[0].credit.length;i++){     
            credit_total_num += res.data[0].credit[i].credit_change
            }
            this.setData({
              _number2:credit_total_num
            })
            
            
          this.setData({
            _number3:res.data[0].favorites.length
          })
          console.log('number3',this.data._number3)
      
    }
      })
    },
    

  //进入积分界面
  credit(){
    wx.navigateTo({
      url: '/pages/credit/credit',
    })
  },

  //进入红包界面
    packet() {
      wx.navigateTo({
        url: '/pages/packet/packet',
      })
    },

  //进入收藏界面
    collect() {
      wx.navigateTo({
        url: '/pages/collect/collect',
      })
    },

    //进入主页
    home() {
      wx.switchTab({
        url: '/pages/homepage/homepage',
      })
    },

    //进入公益排行
    donate_doc() {
      wx.navigateTo({
        url: '/pages/donate_doc/donate_doc',
      })
    },

    //进入设置
    setting() {
      wx.navigateTo({
        url: '/pages/setting/setting',
      })
    },

    //进入我的订单
    my_menu() {
      wx.switchTab({
        url: '/pages/my_order/my_order',
      })
    },

    //进入朋友论坛
    forum() {
      wx.navigateTo({
        url: '/pages/forum/forum',
      })
    },

    //进入朋友论坛
    gosign() {
      wx.navigateTo({
        url: '/pages/signin/signin',
      })
    },

    //进入我的地址
    adress() {
      wx.navigateTo({
        url: '/pages/adress/adress',
      })
    },

   

})

