const db = wx.cloud.database()

Page({
  data: {
    ne: []
  },

  onLoad: function () {
    var that = this;
    wx.getStorage({
      key: 'customer',
      success: function (res) {
        that.setData({
          orderInfo: res.data._openid
        })
      }
    }),

      db.collection('customer').where({
        _openid: 'orderInfo'
      })
        .get({
          success: res => {
            console.log(res.data)
            //success: console.log,
            this.setData({
              ne: res.data[0].coupon
            })

          }
        })


  },
  button() {
    wx.switchTab({
      url: '/pages/homepage/homepage',
    })
  }
})

