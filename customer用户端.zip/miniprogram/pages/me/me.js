// miniprogram/pages/me/me.js
Page({
  data: {
    signinOK: false,
    username:''
  },
  //去登陆页
  signin() {
    wx.navigateTo({
      url: '/pages/signin/signin',
    })
  },
  //去注册页
  signup() {
    wx.navigateTo({
      url: '/pages/signup/signup',
    })
  },
  onShow() {
    let customer = wx.getStorageSync('customer')
    if (customer && customer.用户名) {
      this.setData({
        signinOK: true,
        username: customer.用户名
      })
    } else {
      this.setData({
        signinOK: false
      })
    }
  },

  //退出登陆
  logout() {
    wx.setStorageSync('customer', null)
    let customer = wx.getStorageSync('customer')
    if (customer && customer.用户名) {
      this.setData({
        signinOK: true,
        username: customer.用户名
      })
    } else {
      this.setData({
        signinOK: false
      })
    }
  }

})