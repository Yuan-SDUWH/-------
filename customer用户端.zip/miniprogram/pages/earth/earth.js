const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`



Page({
  data: {
    showsearch: false,   
    searchtext: '', 
    filterdata: {},  
    showfilter: false, 
    showfilterindex: null, 
    sortindex: 0,  
    sortid: null,  
    subsortindex: 0, 
    subsortid: null, 
    cityindex: 0,  
    cityid: null,  
    subcityindex: 0,  
    subcityid: null, 
    customer:[],
    today_month:'',
    today_year:'',
    scrolltop: null, //滚动位置
    page: 0  //分页
  },
  onLoad: function (options) {   //返回customer集合的全部字段给customer集合（AppData中显示）  {key1:{key11:value11}}
    this.fetchServiceData();
    this.getToday();
    var time = '_' + this.data.today_year + '_' + this.data.today_month;
    var ecology='ecology'+'.'+time ;
    //console.log(ecology)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "orderBy", //指定操作是get  
        collection: "customer", //指定操作的集合
        condition: ecology
      },
      success: res => {  
      this.setData({
              customer: res.result.data
            });
        console.log(res.result.data)
      }
    }
    )
  },
  getToday: function () {
    var timestamp = Date.parse(new Date());
    var date = new Date(timestamp);
    //获取年份  
    var Y = date.getFullYear();
    //获取月份  
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    //获取当日日期 
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    // console.log("_" + Y + '_' + M + '_' + D);
    var todaydate = "_" + Y + '_' + M + '_' + D;
    var today = this;

    today.setData({
      today_month: M,
      today_year:Y
    });
     console.log(today.data.today_month);
  },

  fetchServiceData: function () { 
    wx.showToast({
      title: '加载中',
      icon: 'loading'
    })
  },
  setFilterPanel: function (e) { //展开筛选面板
    const d = this.data;
    const i = e.currentTarget.dataset.findex;
    if (d.showfilterindex == i) {
      this.setData({
        showfilter: false,
        showfilterindex: null
      })
    } else {
      this.setData({
        showfilter: true,
        showfilterindex: i,
      })
    }
    console.log(d.showfilterindex);
  },
  scrollHandle: function (e) { //滚动事件
    this.setData({
      scrolltop: e.detail.scrollTop
    })
  },
  goToTop: function () { //回到顶部
    this.setData({
      scrolltop: 0
    })
  },
  scrollLoading: function () { //滚动加载
    this.fetchServiceData();
  },
  onPullDownRefresh: function () { //下拉刷新
    this.setData({
      page: 0,
      servicelist: []
    })
    this.fetchServiceData();
    this.fetchFilterData();
    setTimeout(() => {
      wx.stopPullDownRefresh()
    }, 1000)
  }
})