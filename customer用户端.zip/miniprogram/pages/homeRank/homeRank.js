
Page({
data:{ 
  tabbars1:[
    {id:0,name:'快递代取',imgUrl:'../../images/174-ereader.png'},
    {id:1,name:'顺路捎东西',imgUrl:'../../images/154-folders-1.png'},
    {id:2,name:'代买东西',imgUrl:'../../images/161-idea.png'},
    {id:3,name:'我的筋斗云',imgUrl:'../../images/009-browsing.png'},
          ],
},
      //顶部tabbar点击响应事件
        itemclick:function(event){
          console.log(event.detail);//detail==>myEventDetail
          let index=event.detail.index;
          let name=event.detail.name;
          //todo界面跳转等 根据传过去的index值
          if(name=='快递代取')
          wx.navigateTo({
            url: '../MessageKuaidi/MessageKuaidi',
          })
          if(name=='顺路捎东西')
          wx.navigateTo({
            url: '../MessagePass/MessagePass',
          })
          if(name=='代买东西')
          wx.navigateTo({
            url: '../MessageShop/MessageShop',
          })
          if(name=='我的筋斗云')
          wx.navigateTo({
            url: '../rider_order/rider_order',
          })
      },
  // onLoad: function (options) {   //返回customer集合的全部字段（只能查询到我的openid的字段）
  //   productcollection.get().then(res=>{
  //     console.log(res)
  //   }
  //   )
  // },
 

// addData:function(event){
  
//   console.log(event)
//   productcollection.add({
//     data:{
//       "_id": "201800820001",
//       "公益捐助金额": { "2020_2月": { "月排名": 1} },
//       "环保公益量": { "2020_2月": { "月排名": 5}}
//     },
//       success:res=>{
//         console.log(res)
//       }
//   })
// },

ToEarth: function() {
  wx.navigateTo({
    url: '../earth/earth'
  })
},
ToBusiness: function () {
  wx.navigateTo({
    url: '../Business/business'
  })
},//navigete to页面跳转自带层级关系，所以左上角自动生成返回上一级按钮
ToIndividual: function () {
  wx.navigateTo({
    url: '../individual/individual'
  })
}
})