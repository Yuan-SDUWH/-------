// pages/order/order.js
//var util = require('../../utils/util.js');
const db = wx.cloud.database()
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    currtab: 0,
    swipertab: [{ name: '已完成', index: 0 }, { name: '待付款', index: 1 }, { name: '已取消', index: 2 }],
    id:''
  },
 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
 
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // 页面渲染完成
    this.getDeviceInfo()
    this.orderShow()
  },
 
  getDeviceInfo: function () {
    let that = this
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          deviceW: res.windowWidth,
          deviceH: res.windowHeight
        })
      }
    })
  },
 
  /**
  * @Explain：选项卡点击切换
  */
  tabSwitch: function (e) {
    var that = this
    if (this.data.currtab === e.target.dataset.current) {
      return false
    } else {
      that.setData({
        currtab: e.target.dataset.current
      })
    }
  },
 
  tabChange: function (e) {
    this.setData({ currtab: e.detail.current })
    this.orderShow()
  },
 
  orderShow: function () {
    let that = this
    switch (this.data.currtab) {
      case 0:
        that.alreadyShow()
        break
      case 1:
        that.waitPayShow()
        break
      case 2:
        that.lostShow()
        break
    }
  },

 alreadyShow:function(){
  var _customer = wx.getStorageSync('customer');
  var orderInfo = _customer._openid;
  //console.log(orderInfo)

wx.cloud.callFunction({
  name: 'runDB',
  data: {
    type:"get", //指定操作是get  查找
    collection:"order", //指定操作的集合
    condition:{ //指定where查找的要求字段
       _openid: orderInfo,
       订单状态:'已完成'
    }
  },
  complete: res => {
 
    for(var i=0;i<res.result.data.length;i++){
      res.result.data[i].money=res.result.data[i].实付金额_元
      delete res.result.data[i].实付金额_元
      res.result.data[i].time=res.result.data[i].实际送达时间
      delete res.result.data[i].实际送达时间
      res.result.data[i].state=res.result.data[i].订单状态
      delete res.result.data[i].订单状态
      res.result.data[i].name=res.result.data[i].店铺名称
      delete res.result.data[i].店铺名称
      res.result.data[i].url=res.result.data[i].店铺图片
      delete res.result.data[i].店铺图片
    }
    console.log('调试',res.result.data),
    this.setData({
      ne1:res.result.data,
})
  }
})
 },

 
  waitPayShow:function(){
    var _customer = wx.getStorageSync('customer');
  var orderInfo = _customer._openid;
  //console.log(orderInfo)

wx.cloud.callFunction({
  name: 'runDB',
  data: {
    type:"get", //指定操作是get  查找
    collection:"order", //指定操作的集合
    condition:{ //指定where查找的要求字段
      _openid: orderInfo,
       订单状态:'待付款'
    }
  },
  complete: res => {
 
    for(var i=0;i<res.result.data.length;i++){
      res.result.data[i].money=res.result.data[i].应付金额_元
      delete res.result.data[i].应付金额_元
      res.result.data[i].time=res.result.data[i].接单时间
      delete res.result.data[i].接单时间
      res.result.data[i].state=res.result.data[i].订单状态
      delete res.result.data[i].订单状态
      res.result.data[i].name=res.result.data[i].店铺名称
      delete res.result.data[i].店铺名称
      res.result.data[i].url=res.result.data[i].店铺图片
      delete res.result.data[i].店铺图片
    }
    console.log('调试',res.result.data),
    this.setData({
      ne2:res.result.data,
})
  }
})
  },
    // var _customer = wx.getStorageSync('customer');
    // var _wait1 = _customer.wait_pay.wait1;
    // this.setData({
    //   waitPayOrder: [{ name: _wait1.shop, state: "待付款", time:_wait1.time, status: _wait1.state, url: _wait1.shop_url, money: _wait1.money }],
    // })
  // },
 
  lostShow: function (){
    var _customer = wx.getStorageSync('customer');
  var orderInfo = _customer._openid;
  //console.log(orderInfo)

wx.cloud.callFunction({
  name: 'runDB',
  data: {
    type:"get", //指定操作是get  查找
    collection:"order", //指定操作的集合
    condition:{ //指定where查找的要求字段
      _openid: orderInfo,
       订单状态:'已取消'
    }
  },
  complete: res => {
 
    for(var i=0;i<res.result.data.length;i++){
      res.result.data[i].money=res.result.data[i].应付金额_元
      delete res.result.data[i].应付金额_元
      res.result.data[i].time=res.result.data[i].取消订单时间
      delete res.result.data[i].取消订单时间
      res.result.data[i].state=res.result.data[i].订单状态
      delete res.result.data[i].订单状态
      res.result.data[i].name=res.result.data[i].店铺名称
      delete res.result.data[i].店铺名称
      res.result.data[i].url=res.result.data[i].店铺图片
      delete res.result.data[i].店铺图片
    }
    console.log('调试',res.result.data),
    this.setData({
      ne3:res.result.data,
})
  }
})
  },
})
 
