// miniprogram/pages/tabDetail/tabDetail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    hasMoreData: true,
    isRefreshing: false,
    isLoadingMoreData: false,
    stores:[],
   // stores_id:[],
    count:1,
    // 汤煲快餐:['煲','锅','快餐'],
    // 炸鸡薯条:['炸鸡','薯条','汉堡'],
    // 奶茶甜品:['奶茶','甜品','蛋糕'],
    // 烧烤夜宵:['烧烤','夜宵','小吃'],
    // 面点简餐:['面食','馍','饼'],
    // 超市水果:['超市','水果']

  },

 toDetailStore:function(event){
    wx.navigateTo({
      url: '../storeDetail/storeDetail?store_id='+event.currentTarget.dataset.id,
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      name:options.name
    })
    var that=this
    if(options.name.length==2){
      wx.cloud.callFunction({
        name:'queryDB',
        data:{
            key:options.name,
            type:'查找地址',
            collection:'store'
        },success: res => {
          for( var i=0;i<res.result.data.length;i++){//数组对key操作：中英字符转换-英文数据绑定wxml
            res.result.data[i].safetyScore=res.result.data[i].饮食卫生评分
            delete res.result.data[i].饮食卫生评分
            res.result.data[i].tasteScore=res.result.data[i].好吃程度评分
            delete res.result.data[i].好吃程度评分
            res.result.data[i].speedScore=res.result.data[i].出餐速度评分
            delete res.result.data[i].出餐速度评分
            res.result.data[i].totalScore=res.result.data[i].综合评分
            delete res.result.data[i].综合评分
          }
          this.setData({
            stores:res.result.data,
          })
          console.log(res.result.data)
        }
      })
    }
    else if(options.name=='汤煲快餐'){
      wx.cloud.callFunction({
        name:'queryDB',
        data:{
            key:options.name,
            type:'查找商品',
            collection:'store'
        },success: res => {
          for( var i=0;i<res.result.data.length;i++){//数组对key操作：中英字符转换-英文数据绑定wxml
            res.result.data[i].safetyScore=res.result.data[i].饮食卫生评分
            delete res.result.data[i].饮食卫生评分
            res.result.data[i].tasteScore=res.result.data[i].好吃程度评分
            delete res.result.data[i].好吃程度评分
            res.result.data[i].speedScore=res.result.data[i].出餐速度评分
            delete res.result.data[i].出餐速度评分
            res.result.data[i].totalScore=res.result.data[i].综合评分
            delete res.result.data[i].综合评分
          }
          this.setData({
            stores:res.result.data,
          })
          console.log(res.result.data)
        }
      })
    }
    else if(options.name=='炸鸡薯条'){
      wx.cloud.callFunction({
        name:'queryDB',
        data:{
            key:options.name,
            type:'查找商品',
            collection:'store'
        },success: res => {
          for( var i=0;i<res.result.data.length;i++){//数组对key操作：中英字符转换-英文数据绑定wxml
            res.result.data[i].safetyScore=res.result.data[i].饮食卫生评分
            delete res.result.data[i].饮食卫生评分
            res.result.data[i].tasteScore=res.result.data[i].好吃程度评分
            delete res.result.data[i].好吃程度评分
            res.result.data[i].speedScore=res.result.data[i].出餐速度评分
            delete res.result.data[i].出餐速度评分
            res.result.data[i].totalScore=res.result.data[i].综合评分
            delete res.result.data[i].综合评分
          }
          this.setData({
            stores:res.result.data,
          })
          console.log(res.result.data)
        }
      })
    }
    else if(options.name=='奶茶甜品'){
      wx.cloud.callFunction({
        name:'queryDB',
        data:{
            key:options.name,
            type:'查找商品',
            collection:'store'
        },success: res => {
          for( var i=0;i<res.result.data.length;i++){//数组对key操作：中英字符转换-英文数据绑定wxml
            res.result.data[i].safetyScore=res.result.data[i].饮食卫生评分
            delete res.result.data[i].饮食卫生评分
            res.result.data[i].tasteScore=res.result.data[i].好吃程度评分
            delete res.result.data[i].好吃程度评分
            res.result.data[i].speedScore=res.result.data[i].出餐速度评分
            delete res.result.data[i].出餐速度评分
            res.result.data[i].totalScore=res.result.data[i].综合评分
            delete res.result.data[i].综合评分
          }
          this.setData({
            stores:res.result.data,
          })
          console.log(res.result.data)
        }
      })
    }
    else if(options.name=='烧烤小吃'){
      wx.cloud.callFunction({
        name:'queryDB',
        data:{
            key:options.name,
            type:'查找商品',
            collection:'store'
        },success: res => {
          for( var i=0;i<res.result.data.length;i++){//数组对key操作：中英字符转换-英文数据绑定wxml
            res.result.data[i].safetyScore=res.result.data[i].饮食卫生评分
            delete res.result.data[i].饮食卫生评分
            res.result.data[i].tasteScore=res.result.data[i].好吃程度评分
            delete res.result.data[i].好吃程度评分
            res.result.data[i].speedScore=res.result.data[i].出餐速度评分
            delete res.result.data[i].出餐速度评分
            res.result.data[i].totalScore=res.result.data[i].综合评分
            delete res.result.data[i].综合评分
          }
          this.setData({
            stores:res.result.data,
          })
          console.log(res.result.data)
        }
      })
    }
    else if(options.name=='面点简餐'){
      wx.cloud.callFunction({
        name:'queryDB',
        data:{
            key:options.name,
            type:'查找商品',
            collection:'store'
        },success: res => {
          for( var i=0;i<res.result.data.length;i++){//数组对key操作：中英字符转换-英文数据绑定wxml
            res.result.data[i].safetyScore=res.result.data[i].饮食卫生评分
            delete res.result.data[i].饮食卫生评分
            res.result.data[i].tasteScore=res.result.data[i].好吃程度评分
            delete res.result.data[i].好吃程度评分
            res.result.data[i].speedScore=res.result.data[i].出餐速度评分
            delete res.result.data[i].出餐速度评分
            res.result.data[i].totalScore=res.result.data[i].综合评分
            delete res.result.data[i].综合评分
          }
          this.setData({
            stores:res.result.data,
          })
          console.log(res.result.data)
        }
      })
    }
    else if(options.name=='超市水果'){
      wx.cloud.callFunction({
        name:'queryDB',
        data:{
            key:options.name,
            type:'查找商品',
            collection:'store'
        },success: res => {
          for( var i=0;i<res.result.data.length;i++){//数组对key操作：中英字符转换-英文数据绑定wxml
            res.result.data[i].safetyScore=res.result.data[i].饮食卫生评分
            delete res.result.data[i].饮食卫生评分
            res.result.data[i].tasteScore=res.result.data[i].好吃程度评分
            delete res.result.data[i].好吃程度评分
            res.result.data[i].speedScore=res.result.data[i].出餐速度评分
            delete res.result.data[i].出餐速度评分
            res.result.data[i].totalScore=res.result.data[i].综合评分
            delete res.result.data[i].综合评分
          }
          this.setData({
            stores:res.result.data,
          })
          console.log(res.result.data)
        }
      })
    }








    //改成查找name字段
    // wx.cloud.callFunction({
    //   name: 'runDB',
    //   data: {
    //     type:"col_get", //指定操作是collection get直接获取数据
    //     collection:"store", //指定操作的集合
    //     skip:0,
    //     limit:10
    //   },
    //   success: res => {
    //     for( var i=0;i<res.result.data.length;i++){//数组对key操作：中英字符转换-英文数据绑定wxml
    //       res.result.data[i].safetyScore=res.result.data[i].饮食卫生评分
    //       delete res.result.data[i].饮食卫生评分
    //       res.result.data[i].tasteScore=res.result.data[i].好吃程度评分
    //       delete res.result.data[i].好吃程度评分
    //       res.result.data[i].speedScore=res.result.data[i].出餐速度评分
    //       delete res.result.data[i].出餐速度评分
    //       res.result.data[i].totalScore=res.result.data[i].综合评分
    //       delete res.result.data[i].综合评分
    //     }
    //     this.setData({
    //       stores:res.result.data,
    //     })
    //     console.log(res.result.data)
    //   }
    // })

    wx.setNavigationBarTitle({
      title: options.name 
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  toDetailStore:function(event){
    wx.navigateTo({
      url: '../storeDetail/storeDetail?store_id='+event.currentTarget.dataset.id,
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
   onReachBottom: function () {
     this.setData({
      isLoadingMoreData:false,
      hasMoreData:false
     })
   
  //   if (this.data.isRefreshing || this.data.isLoadingMoreData || !this.data.hasMoreData) {
  //     return
  //   }
    
  //   this.setData({
  //     isLoadingMoreData: true
  //   })

  //   wx.cloud.callFunction({
  //           name: 'runDB',
  //           data: {
  //             type:"col_get", //指定操作是collection get直接获取数据
  //             collection:"store", //指定操作的集合
  //             skip:this.data.count,
  //             limit:20
  //           },
  //           success: res => {
  //             this.setData({
  //               count:this.data.count+1
  //             })
  //             if(res.result.data.length==0){
  //               this.setData({
  //                 hasMoreData:false,
  //                 isLoadingMoreData:false
  //               })
  //             }
  //             else{
  //               var new_store=res.result.data
  //               this.data.stores=this.data.stores.concat(new_store)
  //               this.setData({
  //                 stores: this.data.stores,
  //                 isLoadingMoreData:false,
  //                 hasMoreData:true

  //               })
  //               console.log(res.result.data)
  //               console.log(this.data.stores)
  //             }
              
  //           }
  //         })

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})