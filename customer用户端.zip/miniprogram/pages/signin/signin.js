// miniprogram/pages/signin/signin.js
Page({
  data: {
    stu_ID: '',
    密码: ''
  },
  //获取用户账号
  inputAccount(event) {
 //   console.log('获取输入的账号', event.detail.value)
    this.setData({
      stu_ID: event.detail.value
    })
  },
  // 获取密码
  inputPassword(event) {
    console.log('获取输入的密码', event.detail.value)
    this.setData({
      密码: event.detail.value
    })
  },
  //去注册
  signup() {
    wx.navigateTo({
      url: '/pages/signup/signup',
    })
  },

  //登陆
  signin() {
    let stu_ID = this.data.stu_ID
    let 密码 = this.data.密码
    console.log('学工号',stu_ID, '密码', 密码)
    //校验账号
    if (stu_ID.length < 8) {
      wx.showToast({
        icon: 'none',
        title: '学工号至少8位',
      })
      return
    }
    //校验密码
    if (密码.length < 6) {
      wx.showToast({
        icon: 'none',
        title: '密码至少6位',
      })
      return
    }
  //登陆
  wx.cloud.database().collection('customer').where({
    stu_ID: stu_ID
  }).get({
    success(res) {
      console.log("获取数据成功", res)
      let customer = res.data[0]
      if(res.data.length==0){
        wx.showToast({
          icon:'none',
          title: '学工号未注册',
        })
      }
      console.log("customer", customer)
      if (密码 == customer.密码) {
        console.log('登陆成功')
        wx.showToast({
          title: '登陆成功',
        })
        wx.setStorage({
          data: true,
          key: 'isSignin',//查询本地缓存isSignin字段为true则代表用户已经登陆过 可以直接跳转功能页面
        }),
        wx.switchTab({
          url: '../homepage/homepage',
        })
   //     wx.navigateTo({
    //       url: '../me/me?name=' + user.name,
    //     })//跳转到主页
        //保存用户登陆状态
        wx.setStorageSync('customer', customer)
        
      } else {
        console.log('登陆失败')
        wx.showToast({
          icon: 'none',
          title: '账号或密码不正确',
        })
      }
    },
    fail(res) {
      console.log("获取数据失败", res)
    }
  })

 }
})