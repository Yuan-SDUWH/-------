// miniprogram/pages/signup/signup.js
Page({
  data: {
    用户名: '',
    学工号: '',
    密码: '',
    重复密码:'',
    学院:'',
    availableAddress:['数学与统计学院','商学院','法学院','翻译学院','文化传播学院','机电与信息工程学院','东北亚学院','艺术学院','海洋学院','空间科学与物理学院','马克思主义学院','山东大学澳国立联合理学院','体育教学部'],
    avADindex:0,
  },

  bindPickerChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      avADindex: e.detail.value
    })
  },
  //获取账号
  inputName(event) {
    console.log('获取输入的用户名', event.detail.value)
    this.setData({
      用户名: event.detail.value
    })
  },
  //获取用户学工号
  inputAccount(event) {
    console.log('获取输入的学工号', event.detail.value)
    this.setData({
      学工号: event.detail.value
    })
  },
  // 获取密码
  inputPassword(event) {
    console.log('获取输入的密码', event.detail.value)
    this.setData({
      密码: event.detail.value
    })
  },
    // 再一次输入密码
    inputPasswordAgain(event) {
      console.log('获取输入的密码', event.detail.value)
      this.setData({
        重复密码: event.detail.value
      })
    },

    userInfoHandler(event){
      this.setData({
        customer_icon_url:event.detail.userInfo.avatarUrl
      })
    },

  //注册
  signup() {
    var that=this
    let 用户名 = this.data.用户名
    let 学工号 = this.data.学工号
    let 密码 = this.data.密码
    let 重复密码 = this.data.重复密码
    console.log("点击了注册")
    console.log("用户名", 用户名)
    console.log("学工号", 学工号)
    console.log("密码", 密码)
    console.log("重复密码",重复密码)
    //校验用户名
    if (用户名.length < 2) {
      wx.showToast({
        icon: 'none',
        title: '用户名至少2位',
      })
      return
    }
    if (用户名.length > 15) {
      wx.showToast({
        icon: 'none',
        title: '用户名最多15位',
      })
      return
    }
    //校验账号
    if (学工号.length < 8) {
      wx.showToast({
        icon: 'none',
        title: '学工号至少8位',
      })
      return
    }
    //校验密码
    if (密码.length < 6) {
      wx.showToast({
        icon: 'none',
        title: '密码至少6位',
      })
      return
    }
        //校验重复输入密码
        if (重复密码!=密码) {
          wx.showToast({
            icon: 'none',
            title: '两次输入密码不一致',
          })
          return
        }
    //注册功能的实现
    wx.cloud.database().collection('customer').where({
      stu_ID:学工号
    }).get({
      success(res){
        if(res.data.length>=1)
        {
          console.log("存在重复学工号")
          wx.showToast({
            icon:'none',
            title: '该学工号已注册',
          })
          return
        }
        else if(res.data.length==0)
        {
          wx.cloud.database().collection('customer').add({
            data: {
              username:用户名,
              stu_ID: 学工号,
              密码: 密码,
              学院:that.data.availableAddress[that.data.avADindex],
              customer_icon_url:that.data.customer_icon_url,
              address:[],
              favorites:[],
              coupon:[{coupon_name:'5元优惠券',coupon_num:2},{coupon_name:'免费配送券',coupon_num:2}]
            },
            success(res) {
              console.log('注册成功', res)
              wx.showToast({
                title: '注册成功',
              })
              wx.navigateTo({
                url: '../signin/signin',
              })
            },
            fail(res) {
              console.log('注册失败', res)
            }
          })
        }
      }
      
    })
   
 }
})