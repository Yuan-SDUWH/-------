// pages/collect/collect.js
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      // var _customer = wx.getStorageSync('customer');
      // var _collect1 = _customer.collect.collect1;
      // // var _order2 = _customer.already_order.order2;
  
      // this.setData({
      //   alreadyOrder: [{ name: _collect1.shop, state: "我的最爱",detail: _collect1.reason, url: _collect1.shop_url, score: _collect1.score }]
      // })



////////////////////////
var that = this;
wx.getStorage({
  key: 'customer',
  success: function (res) {
    that.setData({
      orderInfo: res.data._openid
    })
  }
}),

  db.collection('customer').where({
    _openid: 'orderInfo'
  })
    .get({
      success: res => {
        console.log(res.data)
        //success: console.log,
        this.setData({
          ne: res.data[0].favorites
        })

        // console.log('看一下ne',this.data.ne)
        var ne1=[]
        for(var i=0;i<this.data.ne.length;i++)({
          ne1:ne1.push(this.data.ne[i].商家_id)
        })
        // console.log('看一下ne1',ne1)

        var ne2=[]

      for(var i=0;i<ne1.length;i++){
        wx.cloud.callFunction({
        name: 'runDB',
        data: {
          type:"get", //指定操作是get  查找
          collection:"store", //指定操作的集合
          condition:{ //指定where查找的要求字段
            _id: ne1[i],
          }
        },
        complete: res => {
          for(var i=0;i<res.result.data.length;i++){
            res.result.data[i].score_sum=res.result.data[i].综合评分
            delete res.result.data[i].综合评分
            res.result.data[i].score_clear=res.result.data[i].饮食卫生评分
            delete res.result.data[i].饮食卫生评分
            res.result.data[i].score_v=res.result.data[i].出餐速度评分
            delete res.result.data[i].出餐速度评分
            res.result.data[i].score_e=res.result.data[i].好吃程度评分
            delete res.result.data[i].好吃程度评分
            res.result.data[i].url=res.result.data[i].store_icon_url
            delete res.result.data[i].store_icon_url
          }
          // console.log('调试',res.result.data[0]),
          ne2.push(res.result.data[0])
          this.setData({
            ne2:ne2
      })
      // console.log('ne2',ne2)
    }
   
        })

        // var ne3=[]
        // for(var i=0;i<ne2.length;i++){
        //   ne3:ne3.push(ne2[i])



        // }
        // console.log('ne3',ne3)
      }
    }
  })
    
      

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})