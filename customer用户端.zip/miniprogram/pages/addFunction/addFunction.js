// pages/addFunction/addFunction.js
const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`

Page({

  data: {
    result: '',
    canIUseClipboard: wx.canIUse('setClipboardData'),
  },

  onLoad: function (options) {

  },

  copyCode: function() {
    wx.setClipboardData({
      data: code,
      success: function () {
        wx.showToast({
          title: '复制成功',
        })
      }
    })
  },

  testFunction:function() {
    
    // db.collection('customer').doc('d68532785e3ba0f50b0538983e52ff94').update({
    //   data:{学院:'艾利斯顿',
    //   username:'楚雨荨'
    //   },
    //   success: res => {
    //            console.log('本地函数 [updateDB] 已更改Subjcts信息'+res.result)
    //          },
    //   fail: err => {
    //        console.error('本地函数 [updateDB]更改Subject失败', err)
    //                }

    // })
    // wx.cloud.callFunction({
    //     name: 'runDB',
    //     data: {
    //       type:"update", //指定操作是insert  
    //       collection:"customer", //指定操作的集合
    //       _id:'hhytest0206',
    //       data:{ //指定update的数据
    //          学院:'艾利斯顿',
    //         username:'哈哈哈',
    //       }
    //     },
    //     success: res => {
    //       console.log('[云函数] [updateDB] 已更改Subjcts信息'+res.result)
    //     },
    //     fail: err => {
    //       console.error('[云函数] [updateDB]更改Subject失败', err)
    //     }
    //   })
 
    



        wx.cloud.callFunction({
        name: 'runDB',
        data: {
          type:"get", //指定操作是get  
          collection:"rider", //指定操作的集合
          condition:{ //指定where查找的要求字段
           //  _id:'hhytest0206',
         //  username:123,
           //  学工号:201800820001
            综合评分:4.6
          }
        },
        complete: res => {
          this.setData({
            data: res.result.data,
          });
          console.log(res.result.data)
          console.log(this.data)
        }
      })
      
    
  }
})
