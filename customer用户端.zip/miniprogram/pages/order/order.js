// miniprogram/pages/order/order.js
var util = require('../../utils/util.js');
wx.cloud.init({
  env: 'bluetooth-fd3ok'
})
Page({

  /**
   * 页面的初始数据
   */
  data: {
    show:false,//控制下拉列表的显示隐藏，false隐藏、true显示
    // addressData:[],//下拉列表的数据
    // addressIndex:0,//选择的下拉列表下标
    availableAddress:['学1','学2','学3','学4','学5','学6','学7','学8','学9','学10','学11','学12','学13','学14','学15','学16','学17','学18','学19','学20','学21','学22','数学与统计学院','商学院','闻天楼','法学院','翻译学院','文化传播学院','机电与信息工程学院','东北亚学院','艺术学院','海洋学院','空间科学与物理学院','马克思主义学院','山东大学澳国立联合理学院','体育教学部'],
    avADindex:0,
    deliverWay:['小车快跑','人工骑手'],
    deliverIndex:0,
    coupon:[''],
    couponName:[''],
    couponIndex:0,
    youhuijine:0,
    preOrder:false,
    date_order:'',
    time_order:'',
    tableware:[0,1,2,3,4,5],
    wareIndex:0,
    customer_id:''
  },


  bindPickerChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      avADindex: e.detail.value
    })
  },
  bindPickerChange1: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      wareIndex: e.detail.value
    })
  },
  bindPickerChange2: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      deliverIndex: e.detail.value
    })
  },
  // inputName(event) {
  //   console.log('获取输入的地址', event.detail.value) 
  //   var _customer = wx.getStorageSync('customer');
  //   var _address=_customer.address;
  //   _address.push({地址:event.detail.value})
  //   console.log('原始',_address)
  //   this.setData({
  //    address:_address
  //    })
  //  },

  //  signup(){
  //    var that=this
  //   let add_address= this.data.address 
  //   console.log('获取数据库',add_address)
  //  //修改本地
  //      var _customer = wx.getStorageSync('customer');
  //      _customer.address = add_address;
  //      wx.setStorageSync('customer', _customer);
  //      that.data.addressData=[]
  //      add_address.forEach(function(item,index,arr){
  //       that.data.addressData.push(item.地址)
  //     });
  //     that.setData({
  //       addressData:that.data.addressData
  //     })
  //      //修改云端
  //      var _id= _customer._id
  //    wx.cloud.database().collection('customer').doc(_id).update({
  //     data:{
  //       address: add_address
  //     },
  //     success(res){
  //       wx.showToast({
  //       title: '修改成功',
  //     }),
  //     that.setData({
  //       hasAddress:true
  //     })
  //    },
  //     fail(res){
  //      console.error,
  //      wx.showToast({
  //        icon: 'none',
  //        title: '修改失败',
  //      })
  //     } 
  //    })
  //  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this
      this.setData({
        store_id:options.store_id,
        store_name:options.store_name,
        store_icon_url:options.store_icon_url,
        prepareTime:options.prepareTime
      })
      let _id=wx.getStorageSync('customer')._id
      let goodsList=wx.getStorageSync('orders')
      var allGoodsPrice=0;
      console.log(allGoodsPrice)
      goodsList.forEach(item=>{
        allGoodsPrice+=(item.price+item.包装费_元)*item.num
        item.packFee=item.包装费_元
        delete item.包装费_元
      })
      console.log(allGoodsPrice,'1')
      this.setData({
        goodsList:goodsList,
        allGoodsPrice:allGoodsPrice,
        customer_id:_id
      })
     //获取运费和配送时间
     wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type:"get", //指定操作是get  查找
        collection:"management", //指定操作的集合
        condition:{ //指定where查找的要求字段
           Newest:true
        }
      },
      success: res => {
        that.setData({
          deliverFee: res.result.data[0].deliverFee,
          deliverTime: res.result.data[0].deliverTime
        })
       
          //获取当前时间
          var _d=new Date()
          var _d0 = new Date(_d.valueOf() + 60 * 1000 * that.data.deliverTime);// 当前时间加上配送时间
          var _d1 = new Date(_d0.valueOf() + 60 * 1000 * that.data.prepareTime);// 再加上出餐时间
          var _d2 = new Date(_d.valueOf() + 24* 60* 60 * 1000);// 预订单：当前时间加上24小时   +that.data.prepareTime
          var time = util.formatTime3(_d1);
          var date = util.formatTime4(_d1);
          var datePre = util.formatTime4(_d2);
          console.log(_d)
          
          that.setData({
            date1: datePre,//预订单起始日期：至少多一天
            time1: time,//要求送达时间至少等待足够配送时间
            date_order:date,//要求送达的日期
            date0:date //用来判断预订单是否选择了时间
          });
      }                      
    })
    
      //获取优惠券
      wx.cloud.database().collection('customer').doc(_id).get({
        success(res){
          console.log(res.data.coupon)
          if(res.data.coupon.length<=0){
            that.setData({
              hasNoCoupons:true
            })
          }
          else{
            res.data.coupon.forEach(item=>{
              if(item.coupon_num>0){
                that.data.couponName.push(item.coupon_name)
              }
            })
            that.setData({
              hasNoCoupons:false,
              coupon:res.data.coupon,
              couponName:that.data.couponName
            })
            console.log(res.data.coupon)

          }
        }
      })
     
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
   
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that=this
   
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
   // 点击下拉显示框
 selectTap(){
  this.setData({
   show: !this.data.show
  });
  },
  bindChangeCoupon: function(e) {
    var that=this
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      couponIndex: e.detail.value
    })
    if(this.data.couponName[this.data.couponIndex]=='5元优惠券'){
      this.setData({
        youhuijine:5
      })
    }
    else if(this.data.couponName[this.data.couponIndex]==''){
      this.setData({
        youhuijine:0
      })
    }
    else if(this.data.couponName[this.data.couponIndex]=='免费配送券'){
      this.setData({
        youhuijine:this.data.deliverFee
      })
    } 
  },

  bindDateChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      date_order: e.detail.value
    })
  },

  bindTimeChange1: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      time_order: e.detail.value
    })
  },

  preOrder:function(){
    this.setData({
      preOrder:true
    }),
    wx.showToast({
      title: '预订单选择成功',
      icon:'none'
    })
  },
  normalOrder:function(){
    this.setData({
      preOrder:false
    }),
    wx.showToast({
      title: '非预订单选择成功',
      icon:'none'
    })
  },

  

  createOrder: function(e) {
    var that = this;
    var remark = ""; // 备注信息
    var time = util.formatTime2(new Date());
    var date = util.formatTime4(new Date());
 
    wx.getStorageSync('customer')
      this.setData({
        time_post_date: date,
        time_post_minutes: time
      });
    if (e) {
      remark = e.detail.value.remark; // 备注信息
    }
    this.setData({
      remark:remark
    })
    if(this.data.preOrder){
      if(this.data.time_order==''){
        wx.showToast({
          title: '请选择送达时间',
          icon:'none'
        })
      }
      else if(this.data.date_order==this.data.date0){
        wx.showToast({
          title: '预订单请至少提前一天',
          icon:'none'
        })
      }
      else{
        wx.cloud.database().collection('order').add({
          data:{
            time_post_date: this.data.time_post_date,
            time_post_minutes: this.data.time_post_minutes,
            下单用户_id:this.data.customer_id,
            coupon_used:this.data.couponName[this.data.couponIndex],
            address:{where:this.data.availableAddress[this.data.avADindex],detail:"1号外卖柜"},
            date_order:this.data.date_order,
            time_order:this.data.time_order,
            goodsList:this.data.goodsList,
            实付金额_元:this.data.allGoodsPrice+this.data.deliverFee-this.data.youhuijine,
            接单商家id:this.data.store_id,
            store_icon_url:this.data.store_icon_url,
            store_name:this.data.store_name,
            应付金额_元:this.data.allGoodsPrice+this.data.deliverFee,
            用户备注:this.data.remark,
            订单状态:'未接单',
            配送费_元:this.data.deliverFee,
            餐具数量_套:this.data.tableware[this.data.wareIndex],
            是否预订单:this.data.preOrder,
            配送方式:this.data.deliverWay[this.data.deliverIndex]
          },
          success(res) {
            console.log('订单提交成功', res)
            wx.showToast({
              title: '订单提交成功',
            })
            if(that.data.youhuijine!=0){
              var newCoupon=that.data.coupon
              if(newCoupon[that.data.couponIndex-1].coupon_num-1>0){
                newCoupon[that.data.couponIndex-1].coupon_num=newCoupon[that.data.couponIndex-1].coupon_num-1
              }
              else{
                newCoupon.splice(that.data.couponIndex-1,1)
              }
              
              console.log(newCoupon)
              // wx.cloud.database().collection('customer').doc(that.data.customer_id)
              // .get({success(res){console.log(res.data)},
              // fail(res){console.log('失败')}})
              wx.cloud.database().collection('customer').doc(
                that.data.customer_id
              ).update({
                data:{
                  coupon:newCoupon
                },success:function(res){
                  console.log(res,'优惠券更新成功')
                }                
              })
            }
            wx.switchTab({
              url: '../my_order/my_order',
            })
          },
          fail(res) {
          console.log('订单提交失败')
          }
        })
      }
    }
    if(!this.data.preOrder){
      if(this.data.time_order==''){
        wx.showToast({
          title: '请选择送达时间',
          icon:'none'
        })
      }
      else{
        wx.cloud.database().collection('order').add({
          data:{
            time_post_date: this.data.time_post_date,
            time_post_minutes: this.data.time_post_minutes,
            下单用户_id:this.data.customer_id,
            coupon_used:this.data.couponName[this.data.couponIndex],
            address:{where:this.data.availableAddress[this.data.avADindex],detail:"1号外卖柜"},
            date_order:this.data.date_order,
            time_order:this.data.time_order,
            goodsList:this.data.goodsList,
            实付金额_元:this.data.allGoodsPrice+this.data.deliverFee-this.data.youhuijine,
            接单商家id:this.data.store_id,
            store_icon_url:this.data.store_icon_url,
            store_name:this.data.store_name,
            应付金额_元:this.data.allGoodsPrice+this.data.deliverFee,
            用户备注:this.data.remark,
            订单状态:'未接单',
            配送费_元:this.data.deliverFee,
            餐具数量_套:this.data.tableware[this.data.wareIndex],
            是否预订单:this.data.preOrder,
            配送方式:this.data.deliverWay[this.data.deliverIndex]
          },
          success(res) {
            console.log('订单提交成功', res)
            wx.showToast({
              title: '订单提交成功',
            })
            if(that.data.youhuijine!=0){
              var newCoupon=that.data.coupon
              if(newCoupon[that.data.couponIndex-1].coupon_num-1>0){
                newCoupon[that.data.couponIndex-1].coupon_num=newCoupon[that.data.couponIndex-1].coupon_num-1
              }
              else{
                newCoupon.splice(that.data.couponIndex-1,1)
              }
              console.log(newCoupon)
              wx.cloud.database().collection('customer').doc(
                that.data.customer_id
              ).update({
                data:{
                  coupon:newCoupon
                },success(res){
                  console.log(res)
                }             
              })
            }
            wx.switchTab({
              url: '../my_order/my_order',
            })
          },
          fail(res) {
          console.log('订单提交失败')
          }
        })
      }
    }
   
   
    console.log(e.detail.value)
  }
  // 点击下拉列表
  // optionTap(e){
  // let Index=e.currentTarget.dataset.index;//获取点击的下拉列表的下标
  // this.setData({
  //  addressIndex:Index,
  //  show:!this.data.show
  // });
  // },
})