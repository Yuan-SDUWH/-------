function formatTime1(date) {
  var year = date.getFullYear()
  var month = date.getMonth() + 1
  var day = date.getDate()
  return [,year, month, day].map(formatNumber).join('_') 
}
function formatTime2(date) {
  var hour = date.getHours()
  var minute = date.getMinutes()
  var second = date.getSeconds()

  return [hour, minute, second].map(formatNumber).join(':')
}
function formatTime3(date) {
  var hour = date.getHours()
  var minute = date.getMinutes()

  return [hour, minute].map(formatNumber).join(':')
}

function formatTime4(date) {
  var year = date.getFullYear()
  var month = date.getMonth() + 1
  var day = date.getDate()
  
  return [year, month, day].map(formatNumber).join('-') 
}
function formatNumber(n) {
  n = n.toString()
  return n[1] ? n : '0' + n
}
function removeEmptyArrayEle(arr) {
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] == "undefined") {
      arr.splice(i, 1);
      i = i - 1; // i - 1 ,因为空元素在数组下标 2 位置，删除空之后，后面的元素要向前补位，
      // 这样才能真正去掉空元素,觉得这句可以删掉的连续为空试试，然后思考其中逻辑
    }
  }
  return arr;
}

module.exports = {
  formatTime1: formatTime1,
  formatTime2: formatTime2,
  formatTime3:formatTime3,
  formatTime4:formatTime4,
  removeEmptyArrayEle: removeEmptyArrayEle

}