// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()
//数据库模糊查询

const db = cloud.database()
const _ = db.command
// 云函数入口函数
exports.main = async (event, context) => {
  let key = event.key;
    //console.log("查询的内容", key)
    try{
      if(event.type=='查找商品'){
        return await  db.collection(event.collection).where(_.or([{
          store_name: db.RegExp({
            regexp: '.*' + key,
            options: 'i',
          })
        },
        {
          店铺介绍: db.RegExp({
            regexp: '.*' + key,
            options: 'i',
          })
        }
      ])).get({
        success: function (res) {
          return res
        }
      })
      }
      if(event.type=='查找地址'){
        return await  db.collection(event.collection).where(_.or([{
         '店铺地址.建筑': db.RegExp({
            regexp: '.*' + key,
            options: 'i',
          })
        }
      ])).get({
        success: function (res) {
          return res
        }
      })
      }
  
          }catch (e) {
            console.error(e)
          }
}

// let key = "要搜索的关键字";
// console.log("查询的内容", key)
// const db = wx.cloud.database();
// const _ = db.command
// db.collection('').where(_.or([{
//     搜索的字段名1: db.RegExp({
//       regexp: '.*' + key,
//       options: 'i',
//     })
//   },
//   {
//     搜索的字段名2: db.RegExp({
//       regexp: '.*' + key,
//       options: 'i',
//     })
//   }
// ])).get({
//   success: res => {
//     console.log(res)
//   },
//   fail: err => {
//     console.log(err)
//   }
// })