// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init()

const db=cloud.database({env:'bluetooth-fd3ok'})
// 云函数入口函数
exports.main = async (event, context) => {

  try {
    return await db.collection('management').field({
     home_ad:true
    }).get({
      success: function(res) {
      return res
      }
    })
  } catch(e) {
    console.error(e)
  }
// return  db.collection('rider').where({
   
//     综合评分:4.6
//   })
//   .get({
//     success: function(res) {
//       // res.data 是包含以上定义的两条记录的数组
//       console.log(res.data)
//     }
//   })

}