const cloud = require('wx-server-sdk')
cloud.init()
exports.main = async(event, context) => {
  try {
    const result = await cloud.openapi.subscribeMessage.send({
      touser: event.openid, //要推送给那个用户
      page: 'pages/homepage/homepage', //要跳转到那个小程序页面
      data: {//推送的内容
        thing4: {
          value: '您的外卖已送达外卖柜'
        },
        character_string1: {
          value: 5278354
         },
      },
      templateId: 'eN5p1xnIR0nxLaqS-111YnYtIe-XpSUp1KZwwG_yAmA' //模板id
    })
    console.log(result)
    return result
  } catch (err) {
    console.log(err)
    return err
  }
}