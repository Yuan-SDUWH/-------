// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

//云函数中调用存储 上传在云函数目录中包含的一个图片文件（demo.jpg）
//在云函数中，__dirname 的值是云端云函数代码所在目录

const fs = require('fs')
const path = require('path')
exports.main = async (event, context) => {
  const fileStream = fs.createReadStream(path.join(__dirname, 'demo.jpg'))
  return await cloud.uploadFile({
    cloudPath: 'demo.jpg',
    fileContent: fileStream,
  })
}

