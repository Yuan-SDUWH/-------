// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init()

const db=cloud.database({env:'bluetooth-fd3ok'})

// 云函数入口函数
exports.main = async (event, context) => {
  if (event.addCustomer) {
    return await db.collection('customer').add({
      data: event.data
    })  
  } else if (event.addExtra_need) {
    return await db.collection('extra_need').add({
      data: event.data
    })
  } else if (event.addGoods) {
    return await db.collection('goods').add({
      data: event.data
    })
  } else if (event.addManagement) {
    return await db.collection('management').add({
      data: event.data
    })
  } else if (event.addOrder) {
    return await db.collection('order').add({
      data: event.data
    })
  } else if (event.addRider) {
    return await db.collection('rider').add({
      data: event.data
    })


    // .then(res => {
    //   console.log(res)
    // })


  } 
   else if (event.addStore) {
    return await db.collection('store').add({
      data: event.data
    })
  }
}


