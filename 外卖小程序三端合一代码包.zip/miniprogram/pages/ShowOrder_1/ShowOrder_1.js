// pages/addFunction/addFunction.js

// const _ = db.command
// db.collection('todos')


var util = require('../../utils/util.js');
const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`
Page({
  data: {
    time: '',
    today: '',
    showOrder_today:[],
    today_year: '',
    today_month: '',
    today_day: '',
    currentTab: 0,
    navbar: ['今日', '近7天'],
  },
    navbarTap: function (e) {
    this.setData({
      currentTab: e.currentTarget.dataset.idx   
      
    })
    //获取今日本人送达的订单并存入showOrder_today
   if(this.data.currentTab==0){
    var _customer = wx.getStorageSync('customer');
    console.log('customer',_customer)
    var userid = _customer.stu_ID;
     this.getToday();
     var me = this;
     var time;
     var today_month=me.data.today_month;
     var today_day = me.data.today_day; 
     time = '_' + me.data.today_year + '_' + today_month + '_' + today_day;
     wx.cloud.callFunction({
       name: 'runDB',
       data: {
         type: "get", //指定操作是get  
         collection: "extra_need", //指定操作的集合
         condition: { //指定where查找的要求字段
           rider_ID: userid,
           time_to_date: time
         }
       },
       success: res => {
         this.setData({
           showOrder_today: res.result.data
         });
         console.log("第一天", res.result.data)
       }
     })
   }
    else {
      wx.navigateTo({
        url: '../ShowOrder_7/ShowOrder_7'
      })
    }


  },
  getToday: function () {

    var timestamp = Date.parse(new Date());
    var date = new Date(timestamp);
    //获取年份  
    var Y = date.getFullYear();
    //获取月份  
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    //获取当日日期 
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    // console.log("_" + Y + '_' + M + '_' + D);
    var todaydate = "_" + Y + '_' + M + '_' + D;
    var today = this;

    today.setData({
      today_year: Y,
      today_month: M,
      today_day: D,
    });
  },

  onLoad: function () {

    this.navbarTap({ currentTarget: { dataset: { idx: 0 } } });
//     this.getToday();
//     var userid = wx.getStorageSync('stu_ID');
//     var me = this;
//     var time;
//     var today_day = me.data.today_day-1+1;
//     var today_month = me.data.today_month-1+1;
// //第一天
//     time = '_' + me.data.today_year + '_' + today_month + '_' + today_day ;
//       console.log(time)
//     wx.cloud.callFunction({
//       name: 'runDB',
//       data: {
//         type: "get", //指定操作是get  
//         collection: "extra_need", //指定操作的集合
//         condition: { //指定where查找的要求字段
//           接单骑手stu_ID: userid,
//           time_to_date: time       
//         }
//       },
//       success: res => {
//         this.setData({
//           showOrder1: res.result.data
//         });
//       console.log("第一天",res.result.data)
//       }
//     })
//     //第二天
//     i++;
//     time = '_' + me.data.today_year + '_' + me.data.today_month + '_' + i;
//     console.log(time)
//     wx.cloud.callFunction({
//       name: 'runDB',
//       data: {
//         type: "get", //指定操作是get  
//         collection: "extra_need", //指定操作的集合
//         condition: { //指定where查找的要求字段
//           接单骑手stu_ID: userid,
//           time_to_date: time
//         }
//       },
//       success: res => {
//         this.setData({
//           showOrder2: res.result.data
//         });
//         console.log("第二天",res.result.data)
//       }
//     })
//     //第三天
//     i++;
//     time = '_' + me.data.today_year + '_' + me.data.today_month + '_' + i;
//     console.log(time)
//     wx.cloud.callFunction({
//       name: 'runDB',
//       data: {
//         type: "get", //指定操作是get  
//         collection: "extra_need", //指定操作的集合
//         condition: { //指定where查找的要求字段
//           接单骑手stu_ID: userid,
//           time_to_date: time
//         }
//       },
//       success: res => {
//         this.setData({
//           showOrder3: res.result.data
//         });
//         console.log("第三天", res.result.data)
//       }
//     })
//     //第四天
//     i++;
//     time = '_' + me.data.today_year + '_' + me.data.today_month + '_' + i;
//     console.log(time)
//     wx.cloud.callFunction({
//       name: 'runDB',
//       data: {
//         type: "get", //指定操作是get  
//         collection: "extra_need", //指定操作的集合
//         condition: { //指定where查找的要求字段
//           接单骑手stu_ID: userid,
//           time_to_date: time
//         }
//       },
//       success: res => {
//         this.setData({
//           showOrder4: res.result.data
//         });
//         console.log("第四天", res.result.data)
//       }
//     })
//     //第五天
//     i++;
//     time = '_' + me.data.today_year + '_' + me.data.today_month + '_' + i;
//     console.log(time)
//     wx.cloud.callFunction({
//       name: 'runDB',
//       data: {
//         type: "get", //指定操作是get  
//         collection: "extra_need", //指定操作的集合
//         condition: { //指定where查找的要求字段
//           接单骑手stu_ID: userid,
//           time_to_date: time
//         }
//       },
//       success: res => {
//         this.setData({
//           showOrder5: res.result.data
//         });
//         console.log("第五天", res.result.data)
//       }
//     })



  },
  onShow() {

    this.setData({
      currentTab: 0
    })

  },
});

