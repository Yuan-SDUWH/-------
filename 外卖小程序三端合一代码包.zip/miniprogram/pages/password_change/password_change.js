const db = wx.cloud.database()
Page({
  data: {
    stu_ID: '',
    oldpwd_true:'',
    oldpwd_input: '',
    newpwd_one:'',
    password:''
  },

  onLoad:function(){
    //获取真正的旧密码
    var _customer = wx.getStorageSync('customer');
    console.log('真正的旧密码', _customer.密码);
    this.setData({
      oldpwd_true: _customer.密码
    })
  },

  // 获取输入的旧密码
  inputOldPsw(event) {
    console.log('获取输入的旧密码', event.detail.value)
    this.setData({
      oldpwd_input: event.detail.value
    }) 
  },

 //验证旧密码是否输入正确
isOldPswTrue(){
  let oldpwd_input = this.data.oldpwd_input
  let oldpwd_true = this.data.oldpwd_true
  
  if(oldpwd_input != oldpwd_true){
      wx.showToast({
        icon:'none',
        title: '密码输入错误，请重试',
      })
    }
  },

  //获取输入的新密码
  inputNewPsw(event) {
    console.log('获取输入的新密码', event.detail.value)
    this.setData({
      newpwd_one: event.detail.value
    })
  },

  getNewPwd(){
    let newpwd_one = this.data.newpwd_one
    console.log('获取输入的新密码',newpwd_one)
    if (newpwd_one.length < 6) {
      wx.showToast({
        icon: 'none',
        title: '新密码至少6位',
      })
      return
    }
  },

//获取确认的新密码
  inputNewPswAgain(event){
    console.log('获取确认的新密码', event.detail.value)   
    this.setData({
      newpwd_again: event.detail.value
    })
  },

  //验证两次新密码输入是否一致
  isNewPswTrue(){
    let newpwd_one = this.data.newpwd_one
    let newpwd_again = this.data.newpwd_again
    
    if(newpwd_one == newpwd_again){
      //修改本地
      var _customer = wx.getStorageSync('customer');
      let password=this.data.newpwd_again;
      _customer.密码 = password;
      wx.setStorageSync('customer', _customer);

      //修改云端
      var _id= _customer._id

      db.collection('customer').doc(_id).update({
     data:{
       密码:this.data.newpwd_again
     },
     success(res){
       console.log,
       wx.showToast({
       title: '修改成功',
       duration:2000
     }),
     setTimeout(function(){
      wx.navigateTo({
        url: '/pages/mine/mine',
     })
     },3000)
       
    },
    fail(res){
      console.error,
      wx.showToast({
        icon: 'none',
        title: '密码修改失败',
      })
    }
  })
} else {
        wx.showToast({
          icon:'none',
          title: '两次密码输入不一致',
        })
      }
    },

})