const db = wx.cloud.database()

Page({
  data: {
    ne: []
  },

  onLoad: function () {

    var _customer = wx.getStorageSync('customer');
    let target = _customer.stu_ID
    let _id=_customer._id
    this.setData({
      _id:_id
    })

    console.log('tar',target)

      db.collection('customer').where({
        stu_ID:target
        // _openid: 'orderInfo'
      })
        .get({
          success: res => {
            console.log(res.data)
            //success: console.log,
            this.setData({
              ne: res.data[0].coupon
            })

          }
        })


  },
  button() {
    wx.navigateTo({
      url: '/pages/homepage/homepage',
    })
  }
})

