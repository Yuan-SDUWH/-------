// miniprogram/pages/ShowFeedback_admin/ShowFeedback_admin.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  onShow: function(){
    var that=this;
    var i;
    wx.cloud.database().collection('feedback').get({
      /*
      name:'runDB',
      data:{
        type:"col_get",
        collection:"feedback",
        skip:0,
        limit:20,
      },
      */
      success: res =>{
        console.log('ESS',res)
        for (i = 0; i < res.data.length; i++) {//数组对key操作：中英字符转换-英文数据绑定wxml
          res.data[i].comment=res.data[i].反馈内容
          delete res.data[i].反馈内容
          res.data[i].commentTime=res.data[i].反馈时间
          delete res.data[i].反馈时间
          res.data[i].contact=res.data[i].联系方式
          delete res.data[i].联系方式
          console.log('SUC')
        }
        that.setData({
          feedback:res.data,
        })
        console.log(res.data);
      }
    })
  },
})