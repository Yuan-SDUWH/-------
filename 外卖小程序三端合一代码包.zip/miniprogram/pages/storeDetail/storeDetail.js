// miniprogram/pages/storeDetail/storeDetail.js

Page({

  /**
   * 页面的初始数据
   */
  data: {    
    goodsWrap: [],
    categorySelected: "",
    goodsToView: "",
    categoryToView: "",
    comment:[],
    allOrders:[],
    tabCur: 0, //默认选中
    tabs: [{
        name: '商品',
        id: 0
      },
      {
        name: '店家信息',
        id: 1
      },
      {
        name: '评价',
        id: 2
      },
    ]

  },
  //条件筛选导航栏
  tabSelect(e) {
    this.setData({
      tabCur: e.currentTarget.dataset.id,
      scrollLeft: (e.currentTarget.dataset.id - 2) * 200
    })
    var _this=this
    if(e.currentTarget.dataset.id==2){
      this.setData({allOrders:[]})
      wx.cloud.callFunction({ name: 'getDATA', data: { _DBName: 'order',store_id:this.data.store_id} })
      .then(res => {
        let allOrders = res.result.data;
       console.log('1',allOrders)
        for( var i=0;i<res.result.data.length;i++){//数组对key操作：中英字符转换-英文数据绑定wxml
          if(res.result.data[i].用户评价!=undefined){
            res.result.data[i].textComment=res.result.data[i].用户评价
            _this.data.allOrders.push(res.result.data[i])
            delete res.result.data[i].用户评价
          }
        }
        console.log(_this.data.allOrders)
        _this.setData({allOrders:_this.data.allOrders})
      })
    }
  },

  



  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      store_id:options.store_id
    });
      wx.cloud.callFunction({
        name: 'runDB',
        data: {
          type:"get", //指定操作是get  查找
          collection:"store", //指定操作的集合
          condition:{ //指定where查找的要求字段
            _id:this.data.store_id,
          }
        },
        success: res => {
                res.result.data[0].safetyScore=res.result.data[0].饮食卫生评分
                  delete res.result.data[0].饮食卫生评分
                  res.result.data[0].tasteScore=res.result.data[0].好吃程度评分
                  delete res.result.data[0].好吃程度评分
                  res.result.data[0].speedScore=res.result.data[0].出餐速度评分
                  delete res.result.data[0].出餐速度评分
                  res.result.data[0].totalScore=res.result.data[0].综合评分
                  delete res.result.data[0].综合评分
                  res.result.data[0].introduction=res.result.data[0].店铺介绍
                  delete res.result.data[0].店铺介绍
                  res.result.data[0].address=res.result.data[0].店铺地址
                  res.result.data[0].address.building=res.result.data[0].店铺地址.建筑
                  res.result.data[0].address.floor=res.result.data[0].店铺地址.楼层
                  delete res.result.data[0].店铺地址
                  delete res.result.data[0].address.楼层
                  delete res.result.data[0].address.建筑
                  this.data.tabs.push({name:res.result.data[0].店铺状态,id:3})
          this.setData({
            store: res.result.data[0],
            tabs:this.data.tabs
          })
          console.log(res.result.data[0])
          //合并商品类别
      //       for(var i=0;i<this.data.store.goods.length;i++){
      //         this.data.categories.push({})
      //   this.data.categories[i].name=this.data.store.goods[i][3].商品类别
      // }
      //去除重复元素
      // let arrs = [...new Set(this.data.categories)];
      // console.log(arrs,arrs instanceof Array);
      // this.setData({
      //   categories:this.data.categories,
      //   arrs:arrs
      // })
      // for(var i=0;i<arrs.length;i++){
      //   this.data.categories[i].scrollId=arrs[i].name
      // }
      var list=[]
      for(var i=0;i<this.data.store.goods.length;i++){
        list.push(this.data.store.goods[i][3].商品类别)
        list=[...new Set(list)]
      }
      for(var k=0;k<list.length;k++)
      {
        this.data.goodsWrap.push({goods:[],category:list[k],scrollId:'s'+list.indexOf(list[k])})
        for(var j=0;j<this.data.store.goods.length;j++){
          if(this.data.store.goods[j][3].商品类别==list[k]){
            this.data.goodsWrap[k].goods.push(this.data.store.goods[j])
          }
        }
        for(var m=0;m<this.data.goodsWrap[k].goods.length;m++){
                  // this.data.goodsWrap[k].goods[m][0].name=this.data.goodsWrap[k].goods[m][0].商品名称
                  // delete this.data.goodsWrap[k].goods[m][0].商品名称
                  // this.data.goodsWrap[k].goods[m][8].pic=this.data.goodsWrap[k].goods[m][8].商品图片
                  // delete this.data.goodsWrap[k].goods[m][8].商品图片
                  // this.data.goodsWrap[k].goods[m][1].price=this.data.goodsWrap[k].goods[m][1].商品单价_元
                  // delete this.data.goodsWrap[k].goods[m][1].商品单价_元
                  // console.log('ok',this.data.goodsWrap[k].goods[m])
                  // let obj = {}
                  // this.data.goodsWrap[k].goods[m].forEach(item=> {
                  //     obj[item.name] = item.ct
                  // })
                  // console.log('new goods is', JSON.stringify(obj, null, 2));
                  let newgoods={}
                    newgoods['name']=this.data.goodsWrap[k].goods[m][0].商品名称
                    newgoods['price']=this.data.goodsWrap[k].goods[m][1].商品单价_元
                    newgoods['包装费_元']=this.data.goodsWrap[k].goods[m][2].包装费_元
                    newgoods['商品类别']=this.data.goodsWrap[k].goods[m][3].商品类别
                    newgoods['商品食材']=this.data.goodsWrap[k].goods[m][4].商品食材
                    newgoods['商品口味']=this.data.goodsWrap[k].goods[m][5].商品口味
                    newgoods['公益抽成百分比']=this.data.goodsWrap[k].goods[m][6].公益抽成百分比
                    newgoods['平台抽成百分比']=this.data.goodsWrap[k].goods[m][7].平台抽成百分比
                    newgoods['pic']=this.data.goodsWrap[k].goods[m][8].商品图片
                    console.log('new goods is', JSON.stringify(newgoods, null, 2));
                    newgoods.num=0;
                    console.log(newgoods)
                    this.data.goodsWrap[k].goods[m]=newgoods
                    
        }
        this.setData({
          goodsWrap:this.data.goodsWrap
        })
        
      }

      // var _list=list
      // for(var l=0;l<list.length;l++){
      //   _list[l]={name:list[i],scrollId:list[i]}
      // }
      // this.setData({
      //   categories:_list,  
      // })
      // console.log(_list)
      console.log(list)
  }
});
      
      // for(var i=0;i<this.data.store.goods.length;i++){
      //   for(var j=0;j<goodsWrap.length;j++){
      //     goodsWrap[i].name=this.data.store.goods[i][3].商品类别
      //     goodsWrap[i].scrollId=this.data.store.goods[i][3].商品类别
      //   }
        
      //   for(var j=0;j<this.data.store.goods.length;)
      //   this.data.store.goods[i][3].商品类别
      // }
     
 
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
     
     
      

     
      
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  
addOrder:function(e){
  // 判断是否登陆
  var sign=wx.getStorageSync('isSignin')
  if(!sign){
    wx.showToast({
      title: '请先登录',
      icon: 'none',
      duration:2000
    })
    wx.navigateTo({
      url: '../signin/signin',
    })
  }
  else{
  let that=this
  let category = e.currentTarget.dataset.category;
  let index = e.currentTarget.dataset.goodsindex;
  let param = this.data.goodsWrap[category].goods[index]
  param.num+=1
  let subOrders = []; // 购物单列表存储数据
    param.active=true
     // 将已经确定的菜单添加到购物单列表
     for(var i=0;i<this.data.goodsWrap.length;i++){
       for(var j=0;j<this.data.goodsWrap[i].goods.length;j++){
         if(this.data.goodsWrap[i].goods[j].active)
         subOrders.push(this.data.goodsWrap[i].goods[j]);
       }
     }
     // 判断底部提交菜单显示隐藏
     if (subOrders.length == 0) {
       that.setData({
         bottomFlag: false
       });
     } else {
       that.setData({
         bottomFlag: true
       });
     }
     let money = 0;
     let num=0;
     for(var i=0;i<subOrders.length;i++){
       num+=subOrders[i].num
     }
     subOrders.forEach(item => {
       money += (item.price*item.num); // 总价格求和
     });
     let orderCount = {
       num,
       money
     }
     // 设置显示对应的总数和全部价钱
     this.setData({
       orderCount
     });
     // 将选中的商品存储在本地
     wx.setStorage({
       key: "orders",
       data: subOrders
     });
    }
  
},

 
reduceOrder:function(e){
  // 判断是否登陆
  var sign=wx.getStorageSync('isSignin')
  if(!sign){
    wx.showToast({
      title: '请先登录',
      icon: 'none',
      duration:2000
    })
    wx.navigateTo({
      url: '../signin/signin',
    })
  }
  else{
  let that=this
  let category = e.currentTarget.dataset.category;
  let index = e.currentTarget.dataset.goodsindex;
  let param = this.data.goodsWrap[category].goods[index]
  if(param.num<=0){
    wx.showToast({
      title: '不能再少啦',
      icon:'none'
    })
  }else{
  param.num-=1
  let subOrders = []; // 购物单列表存储数据
  if(param.num==0){
    param.active=false
  }
    
     // 将已经确定的菜单添加到购物单列表
     for(var i=0;i<this.data.goodsWrap.length;i++){
       for(var j=0;j<this.data.goodsWrap[i].goods.length;j++){
         if(this.data.goodsWrap[i].goods[j].active)
         subOrders.push(this.data.goodsWrap[i].goods[j]);
       }
     }
     // 判断底部提交菜单显示隐藏
     if (subOrders.length == 0) {
       that.setData({
         bottomFlag: false
       });
     } else {
       that.setData({
         bottomFlag: true
       });
     }
     let money = 0;
     let num=0;
     for(var i=0;i<subOrders.length;i++){
       num+=subOrders[i].num
     }
     subOrders.forEach(item => {
       money += (item.price*item.num); // 总价格求和
     });
     let orderCount = {
       num,
       money
     }
     // 设置显示对应的总数和全部价钱
     this.setData({
       orderCount
     });
     // 将选中的商品存储在本地
     wx.setStorage({
       key: "orders",
       data: subOrders
     });
    }
  }
  
},

order: function() {
  let that = this;
  if(that.data.store.店铺状态=='已打烊'){
    wx.showToast({
      title: '店家打烊不接单啦',
      icon: 'none',
      duration: 2000
    })
    console.log('打烊')
  }
  else{
    console.log('营业中')
    if (that.data.orderCount.num !== 0) {
      // wx.setStorage({
      //   data: data,
      //   key: 'store_id',
      // })
      // 跳转到生成订单
      wx.navigateTo({
        url: '../order/order?store_id='+this.data.store_id+'&store_name='+this.data.store.store_name+'&store_icon_url='+this.data.store.store_icon_url+'&prepareTime='+this.data.store.prepareTime,
      })
      
    } else {
      wx.showToast({
        title: '您未选中任何商品',
        icon: 'none',
        duration: 2000
      })
    }

  }
  

},

  toDetailsTap: function(e) {
    // wx.navigateTo({
    //   url: "/pages/goodDetail/goodDetail?name=" + e.currentTarget.dataset.name
    // })
  },
  onCategoryClick: function(e) {

    let id = e.currentTarget.dataset.id;
    this.categoryClick = true;
    this.setData({
      goodsToView: id,
      categorySelected: id,
    })

  },
  scroll: function(e) {

    if (this.categoryClick){
      this.categoryClick = false;
      return;
    }

    let scrollTop = e.detail.scrollTop;

    let that = this;

    let offset = 0;
    let isBreak = false;

    for (let g = 0; g < this.data.goodsWrap.length; g++) {

      let goodWrap = this.data.goodsWrap[g];

      offset += 30;

      if (scrollTop <= offset) {

        if (this.data.categoryToView != goodWrap.scrollId) {
          this.setData({
            categorySelected: goodWrap.scrollId,
            categoryToView: goodWrap.scrollId,
          })
        }

        break;
      }


      for (let i = 0; i < goodWrap.goods.length; i++) {

        offset += 91;

        if (scrollTop <= offset) {

          if (this.data.categoryToView != goodWrap.scrollId) {
            this.setData({
              categorySelected: goodWrap.scrollId,
              categoryToView: goodWrap.scrollId,
            })
          }

          isBreak = true;
          break;
        }
      }

      if (isBreak){
        break;
      }


    } 
  },

  favorites:function(){
    var customer=wx.getStorageSync('customer')
    var that=this
    var _id=customer._id
    var addFavor={'商家_id':this.data.store_id}
   wx.cloud.database().collection('customer').doc(_id).get({
      success(res){
        var favor=res.data.favorites
        var add=true
        console.log(favor)
        for(var i=0;i<favor.length;i++){
          if(favor[i].商家_id==that.data.store_id){
            add=false
            wx.showToast({
              title: '已经收藏过了哟',
              icon:'none'
            })
            return
          }
        }
       if(add==true){
        favor.push(addFavor)
        console.log(favor,'add is true')
        wx.showToast({
          title: '收藏成功',
          icon:'none'
        })
        wx.cloud.database().collection('customer').doc(_id).update({
          data:{
            favorites:favor
          },
          success:console.log
        })
       }
        
      }
    })
  }
})