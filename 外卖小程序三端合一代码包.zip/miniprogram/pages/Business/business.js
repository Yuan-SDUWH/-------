const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`

Page({
  data: {
    showsearch: false,   //显示搜索按钮
    searchtext: '',  //搜索文字
    filterdata: {},  //筛选条件数据
    showfilter: false, //是否显示下拉筛选
    showfilterindex: null, //显示哪个筛选类目
    sortindex: 0,  //一级分类索引
    sortid: null,  //一级分类id
    subsortindex: 0, //二级分类索引
    subsortid: null, //二级分类id
    cityindex: 0,  //一级城市索引
    cityid: null,  //一级城市id
    subcityindex: 0,  //二级城市索引
    subcityid: null, //二级城市id
    scrolltop: null, //滚动位置
    page: 0 , //分页
    business:[],
    today_month:'',
    today_year:''
  },
  onLoad: function (options) {   //返回customer集合的全部字段给customer集合（AppData中显示）
    this.fetchServiceData();
    this.getToday();
    var time = '_' + this.data.today_year+'_'+this.data.today_month;
    console.log(time);
    var donation='donation'+'.'+time
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "orderBy", //指定操作是get  
        collection: "store", //指定操作的集合
        condition: donation
      },
      success: res => {

        this.setData({
          business: res.result.data
        });
        console.log(res.result.data)
      }
    }
    )
  },
  fetchServiceData: function () {  //获取城市列表
    wx.showToast({
      title: '加载中',
      icon: 'loading'
    })
  },
  getToday: function () {
    var timestamp = Date.parse(new Date());
    var date = new Date(timestamp);
    //获取年份  
    var Y = date.getFullYear();
    //获取月份  
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    //获取当日日期 
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    // console.log("_" + Y + '_' + M + '_' + D);
    var todaydate = "_" + Y + '_' + M + '_' + D;
    var today = this;

    today.setData({
      today_month: M,
      today_year:Y,
    });
    //console.log(today.data.today_month);
  },
  setFilterPanel: function (e) { //展开筛选面板
    const d = this.data;
    const i = e.currentTarget.dataset.findex;
    if (d.showfilterindex == i) {
      this.setData({
        showfilter: false,
        showfilterindex: null
      })
    } else {
      this.setData({
        showfilter: true,
        showfilterindex: i,
      })
    }
    console.log(d.showfilterindex);
  },
  scrollHandle: function (e) { //滚动事件
    this.setData({
      scrolltop: e.detail.scrollTop
    })
  },
  goToTop: function () { //回到顶部
    this.setData({
      scrolltop: 0
    })
  },
  scrollLoading: function () { //滚动加载
    this.fetchServiceData();
  },
  onPullDownRefresh: function () { //下拉刷新
    this.setData({
      page: 0,
      servicelist: []
    })
    this.fetchServiceData();
    this.fetchFilterData();
    setTimeout(() => {
      wx.stopPullDownRefresh()
    }, 1000)
  }
})