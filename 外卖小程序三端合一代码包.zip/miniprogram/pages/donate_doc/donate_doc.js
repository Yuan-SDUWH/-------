const db = wx.cloud.database()

Page({
  data: {
    ne: []
  },

  onLoad: function () {
    var _customer = wx.getStorageSync('customer');
    let target = _customer.stu_ID

    console.log('tar',target)

  
    db.collection('customer').where({
      //done: false,
      //progress: 50,
      stu_ID: target
    }).get({
          success: res => {
            console.log(res.data)
            //success: console.log,
            this.setData({
              ne1: res.data[0].donation,
              ne2: res.data[0].ecology,
            })
            console.log('ne',this.data.ne1,this.data.ne2)
          }
        })
        },
        
  homeRank() {
    wx.navigateTo({
      url: '/pages/homeRank/homeRank',
    })
  },
  /**
 * 弹窗
 */
showDialogBtn: function() {
  this.setData({
      showModal: true
  })
},
/**
* 弹出框蒙层截断touchmove事件
*/
preventTouchMove: function() {},
/**
* 隐藏模态对话框
*/
hideModal: function() {
  this.setData({
      showModal: false
  });
},
/**
* 对话框取消按钮点击事件
*/
onCancel: function() {
  this.hideModal();
},
/**
* 对话框确认按钮点击事件
*/
onConfirm: function() {
  let olddonation = this.data.ne1._2020_03
  let more = parseFloat(this.data.money)
  let newdonation = olddonation + more
  console.log('新捐助额',newdonation)

  var _customer = wx.getStorageSync('customer');
  let stu_ID = _customer.stu_ID;
  console.log('学号',stu_ID)
  var _id= _customer._id

      db.collection('customer').doc(_id).update({
        data:{   //指定update的数据
          			 donation:{
                   _2020_03:newdonation
                 }
          		},

// wx.cloud.callFunction({
// 	name: 'runDB',
// 	data: {
// 		type:"update", //指定操作是update
//     collection:"customer", //指定操作的集合
// 		stu_ID:'201800820109',
// 		data:{   //指定update的数据
// 			 donation:{
//          _2020_03:newdonation
//        }
// 		}
// 	},
	success: res => {
    wx.showToast({
      title: '捐助成功',
      icon: 'success',
      duration: 2000
  })
  setTimeout(function(){
    wx.navigateTo({
      url: '/pages/donate_doc/donate_doc',
    }),2000

  })
  
	},
	fail: err => {
    wx.showToast({
      title: '捐助失败',
      icon: 'none',
      duration: 2000
  })
	}
})
  




 
},

inputChange:function(event){
  console.log('获取输入的金额', event.detail.value)
    this.setData({
      money: event.detail.value
    })
}
})