// 函数库
var Utils = require("../../utils/util.js");

// pages/setUp/setUp.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
  
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this
    wx.getStorage({
      key: 'customer',
      success: function (res) {
        that.setData({
         stu_ID: res.data.stu_ID,
         _id:res.data._id
        })
      }
    })
  },
  change_icon(){
    var that = this
    //让用户选择或拍摄一张照片
    wx.chooseImage({
      count: 1,	
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
      //选择完成会先返回一个临时地址保存备用
        const tempFilePaths = res.tempFilePaths
        //将照片上传至云端需要刚才存储的临时地址
        wx.cloud.uploadFile({
          cloudPath: 'customer/'+that.data.stu_ID+'/'+'icon.png',
          filePath: tempFilePaths[0],
          success(res) {
          //上传成功后会返回永久地址
             console.log(res.fileID) 
             that.setData({
              customer_icon_url:res.fileID
             })
             wx.cloud.callFunction({
              name: 'runDB',
              data: {
                type: "update", //指定操作是update
                collection: "customer", //指定操作的集合
                _id: that.data._id,
                data: { //指定update的数据
                  customer_icon_url:res.fileID
                }
              },
              success: res => {
                console.log('已经上传图片地址' + res.fileID)
                wx.showToast({
                  title: '修改成功，显示更改需要一定时间',
                  icon:'none'
                })
              },
              fail: err => {
                console.error('上传失败', err)
              }
            })
          wx.navigateBack({
             delta:1
          })
            console.log('能加载的')
            //  wx.cloud.database().collection('customer').doc(that.data._id).update({
            //    data:{
            //     customer_icon_url:res.fileID
            //    },
            //    success(res){
            //      console.log(res),
            //      wx.navigateTo({
            //     url: '../mine/mine',
            //   })
            // }
              
            //  })
             
          }
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  quitFn(){
    wx.removeStorage({
      key: 'isSignin',
      success: function (res) {
      wx.navigateTo({
        url: '/pages/me/me',
      })
  }
})
  }
    })