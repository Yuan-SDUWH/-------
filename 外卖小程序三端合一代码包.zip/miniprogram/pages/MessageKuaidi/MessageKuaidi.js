// miniprogram/pages/InitStore/InitStore.js
//购物、捎带物品、快递
var util = require('../../utils/util.js');
wx.cloud.init({
  env: 'bluetooth-fd3ok'
})

const db = wx.cloud.database({
  env: 'bluetooth-fd3ok' 
})

Page({

  /**
   * 页面的初始数据
   */
  data: {
    取货地址:'',
    店铺地址:'',
    货物价值_元:'',
    是否为贵重物品:'',
    取货码:'',
    送达地点:'',
    送达时间:'',
    跑腿费:'',
    是否加急:'',
    物品大小:'',
    需求种类:'快递',
    time_post_date:'',
    time_post_minutes: '',
    arry:'',
    color_rapid:'',
    color_norapid:'',
    color_bigsize:'',
    color_middlesize:'',
    color_smallsize:'',
    color_moneyyes:'',
    color_moneyno:''

  },
  onLoad: function () {
    var date = util.formatTime1(new Date());
    var minutes = util.formatTime2(new Date());
    // 再通过setData更改Page()里面的data，动态更新页面的数据
    this.setData({
      time_post_date: date,
      time_post_minutes :minutes
    });
    console.log(this.data.time_post_date)
  },
  //获取取货地址
  inputGetplace(event) {
    console.log('取货地址', event.detail.value)
    this.setData({
      取货地址: event.detail.value
    })
   // console.log(this.data.getplace)
  },
  
  //获取货物价值_元
  inputGoodsValue(event) {
    console.log('获取货物价值_元', event.detail.value)
    this.setData({
      货物价值_元: event.detail.value
    })
  },
  //获取取货码
  inputGetNumber(event) {
    console.log('获取输入的取货码', event.detail.value)
    this.setData({
      取货码: event.detail.value
    })
  },
  //获取送达地点
  inputToPlace(event) {
    console.log('获取输入的送达地点', event.detail.value)
    this.setData({
      送达地点: event.detail.value
    })
  },
  inputMoney(event) {
    console.log('获取输入的跑腿费', event.detail.value)
    this.setData({
      跑腿费: event.detail.value
    })
  },
  sendYes() {
    console.log('加急_是')
    this.setData({
      是否加急: "True",
      color_rapid:'orange',
      color_norapid:'black'
    })
  },
  sendNo() {
    console.log('加急_否')
    this.setData({
      是否加急: "False",
      color_rapid: 'black',
      color_norapid: 'orange'
    })
   
  },
  sendBig() {
    console.log('物品大小_大')
    this.setData({
      物品大小: "大",
      color_bigsize: 'orange',
      color_middlesize: 'black',
      color_smallsize: 'black'
    })
  },
  sendNoMoney() {
    console.log('是否为贵重物品_否')
    this.setData({
      是否为贵重物品: "False",
      color_moneyyes: 'black',
      color_moneyno: 'orange'
    })
  },
  sendYesMoney() {
    console.log('是否为贵重物品_是')
    this.setData({
      是否为贵重物品: "True",
      color_moneyyes: 'orange',
      color_moneyno: 'black'
    })
  },
  sendMiddle() {
    console.log('物品大小_中')
    this.setData({
      物品大小: "中",
      color_bigsize: 'black',
      color_middlesize: 'orange',
      color_smallsize: 'black'
    })
  },
  sendSmall() {
    console.log('物品大小_小')
    this.setData({
      物品大小: "小",
      color_bigsize: 'black',
      color_middlesize: 'black',
      color_smallsize: 'orange'
    })
  },

  CommitAll(){
    //判断用户是否登陆

    var sign = wx.getStorageSync('isSignin')
    if (!sign) {
      wx.showToast({
        title: '请先登录',
        icon: 'none',
        duration: 2000
      })
      wx.navigateTo({
        url: '../signin/signin',
      })
    }
    else {
    let 取货地址 = this.data.取货地址;
    let 货物价值_元=this.data.货物价值_元;
    let 是否为贵重物品=this.data.是否为贵重物品;
    let 取货码=this.data.取货码;
    let 送达地点 = this.data.送达地点;
    let 送达时间 = this.data.送达时间;
    let 跑腿费 = this.data.跑腿费;
    let 是否加急 = this.data.是否加急;
    let 物品大小 = this.data.物品大小;
    let 需求种类 = this.data.需求种类;
    let arry=this.data.arry;
    let time_post_date = this.data.time_post_date;
    let time_post_minutes = this.data.time_post_minutes;
    // console.log("getplace", 取货地址);
    var userid=wx.getStorageSync('_id');
    arry=[];
    console.log(userid);
    arry.push(取货地址);
    arry.push(货物价值_元);
    arry.push(取货码);
    arry.push(送达地点);
    arry.push(跑腿费);
    arry.push(是否加急);
    arry.push(物品大小);
    arry.push(是否为贵重物品);
    var i;
    var index=0;
for(i=0;i<8;i++){
    if(arry[i]==''){
      wx.showToast({
        icon: 'none',
        title: '请完善发布信息',

      })
      index=1;
    }
}
    if(index==0){
      db.collection('extra_need').add({
        data: {
          取货地址: 取货地址,
          下单用户id: userid,
          货物价值_元: 货物价值_元,
          是否为贵重物品: 是否为贵重物品,
          取货码: 取货码,
          送达地点: 送达地点,
          送达时间: 送达时间,
          跑腿费: 跑腿费,
          是否加急: 是否加急,
          物品大小: 物品大小,
          需求种类: 需求种类,
          当前状态:'待接单',
          time_post_date: time_post_date,
          time_post_minutes: time_post_minutes,
        },
        success: res => {
          console.log('提交成功')
        },
        fail: err => {
          console.error('提交失败')
        }
      })

      wx.navigateTo({
        url: '../rider_order/rider_order',
      })
    }

  }

  },
  
})