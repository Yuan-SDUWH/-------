// miniprogram/pages/homepage/homepage.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      tabbars1:[
        {id:0,name:'汤煲快餐',imgUrl:'../../images/homepage/米饭-填充.png'},
        {id:1,name:'炸鸡薯条',imgUrl:'../../images/homepage/汉堡.png'},
        {id:2,name:'奶茶甜品',imgUrl:'../../images/homepage/布丁奶茶.png'},
        {id:3,name:'烧烤小吃',imgUrl:'../../images/homepage/串串.png'},
        {id:4,name:'面点简餐',imgUrl:'../../images/homepage/拉面.png'},
              ],
      tabbars2:[
         {id:0,name:'超市水果',imgUrl:'../../images/homepage/猕猴桃.png'},
         {id:1,name:'雀园',imgUrl:'../../images/homepage/巨嘴鸟.png'},
         {id:2,name:'馨园',imgUrl:'../../images/homepage/康乃馨.png'},
         {id:3,name:'荟园',imgUrl:'../../images/homepage/芦荟.png'},
         {id:4,name:'泰园',imgUrl:'../../images/homepage/老虎.png'},
                      ], 
      stores:[],
      storesScore:[],
      storesDonation:[],
      goods:[],   
      hasMoreData: true,
      isRefreshing: false,
      isLoadingMoreData: false,
      count:1,
      tabCur: 0, //默认选中
      tabs: [{
          name: '校内商家',
          id: 0
        },
        {
          name: '综合评分',
          id: 1
        },
        {
          name: '公益商家',
          id: 2
        },
        {
          name: '更多板块',
          id: 3
        },
        {
          name: '敬请期待',
          id: 4
        },
      ],
      blockid:0,
    bgcolor:'#ffffff',
    color:"#989898",
    selectedColor:'#FF6802',
    showborder:false,
    bordercolor:"",
    tabbar:[
      {
        pagePath: "../homepage/homepage",
        selectedIconPath: '../../images/homepage/home_icon_press.png',
        iconPath: '../../images/homepage/home_icon_nor.png',
        text: '首页',
     //   isdot: false,
    //    number: 0
      }, {
        pagePath: "../homeRank/homeRank",
        selectedIconPath: '../../images/homepage/cate_icon_press.png',
        iconPath: '../../images/homepage/cate_icon_nor.png',
        text: '百宝箱',
     //   isdot: true,
      //  number: 0
      }, {
        pagePath: "../my_order/my_order",
        selectedIconPath: '../../images/homepage/find_icon_press.png',
        iconPath: '../../images/homepage/find_icon_nor.png',
        text: '订单',
     //   isdot: false,
      //  number: 5
      }, {
        pagePath: "../mine/mine",
        selectedIconPath: '../../images/homepage/mine_icon_press.png',
        iconPath: '../../images/homepage/mine_icon_nor.png',
        text: '我的',
     //   isdot: false,
     //   number: 0
      }
    ]

  },

  // event.detail 的值为当前选中项的索引
  tabbarChange(e) {
   
    var index = parseInt(e.detail);
   
    if(index!=0){
      wx.navigateTo({
        url: this.data.tabbar[index].pagePath,
      })
    }
     this.setData({
      blockid:index
    })
  },


  //条件筛选导航栏
  tabSelect(e) {
    this.setData({
      tabCur: e.currentTarget.dataset.id,
      scrollLeft: (e.currentTarget.dataset.id - 2) * 200
    })
    var _this=this
    if(e.currentTarget.dataset.id==1){
      wx.cloud.callFunction({ name: 'getDATA', data: { _DBName: 'store'} })
      .then(res => {
        let allStores = res.result.data;
        console.log("allStores: ", allStores);
        for( var i=0;i<res.result.data.length;i++){//数组对key操作：中英字符转换-英文数据绑定wxml
          res.result.data[i].safetyScore=res.result.data[i].饮食卫生评分
          delete res.result.data[i].饮食卫生评分
          res.result.data[i].tasteScore=res.result.data[i].好吃程度评分
          delete res.result.data[i].好吃程度评分
          res.result.data[i].speedScore=res.result.data[i].出餐速度评分
          delete res.result.data[i].出餐速度评分
          res.result.data[i].totalScore=res.result.data[i].综合评分
          delete res.result.data[i].综合评分
        }
        var compare = function (prop) {
          return function (obj1, obj2) {
              var val1 = obj1[prop];
              var val2 = obj2[prop];if (val1 > val2) {
                  return -1;
              } else if (val1 < val2) {
                  return 1;
              } else {
                  return 0;
              }            
          } 
      }
      res.result.data.sort(compare("totalScore"))
        _this.setData({storesScore:res.result.data})
      })
    }
    if(e.currentTarget.dataset.id==2){
      wx.cloud.callFunction({ name: 'getDATA', data: { _DBName: 'store'} })
      .then(res => {
        let allStores = res.result.data;
        let storesDonation=[]
        console.log("allStores: ", allStores);
        for( var i=0;i<res.result.data.length;i++){//数组对key操作：中英字符转换-英文数据绑定wxml
          if(res.result.data[i].donation!=undefined){
            res.result.data[i].safetyScore=res.result.data[i].饮食卫生评分
            delete res.result.data[i].饮食卫生评分
            res.result.data[i].tasteScore=res.result.data[i].好吃程度评分
            delete res.result.data[i].好吃程度评分
            res.result.data[i].speedScore=res.result.data[i].出餐速度评分
            delete res.result.data[i].出餐速度评分
            res.result.data[i].totalScore=res.result.data[i].综合评分
            delete res.result.data[i].综合评分
            storesDonation.push(res.result.data[i])
          }
        }
        var compare = function (prop,month) {
          return function (obj1, obj2) {
              var val1 = obj1[prop][month];
              var val2 = obj2[prop][month];if (val1 > val2) {
                  return -1;
              } else if (val1 < val2) {
                  return 1;
              } else {
                  return 0;
              }            
          } 
      }
      storesDonation.sort(compare("donation","03"))
        _this.setData({storesDonation:storesDonation})
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this=this
    // 轮播图获取
      wx.cloud.callFunction({
        name:'GetDoc',
        success: res => {
          var sldUrl=res.result.data[0].home_ad.sld
          var i=0
              var new_array=[]
              // this.data.banner
              for(i=0;i<sldUrl.length;i++)
              {
                new_array.push(sldUrl[i])
            }
        //   console.log(this.data.banner)
            this.setData({banner : new_array})
            console.log(this.data.banner)
            }
            })
    //店铺信息加载

    wx.cloud.callFunction({ name: 'getDATA', data: { _DBName: 'store'} })
    .then(res => {
      let allStores = res.result.data;
      console.log("allStores: ", allStores);
      for( var i=0;i<res.result.data.length;i++){//数组对key操作：中英字符转换-英文数据绑定wxml
        res.result.data[i].safetyScore=res.result.data[i].饮食卫生评分
        delete res.result.data[i].饮食卫生评分
        res.result.data[i].tasteScore=res.result.data[i].好吃程度评分
        delete res.result.data[i].好吃程度评分
        res.result.data[i].speedScore=res.result.data[i].出餐速度评分
        delete res.result.data[i].出餐速度评分
        res.result.data[i].totalScore=res.result.data[i].综合评分
        delete res.result.data[i].综合评分
      }
      _this.setData({stores:res.result.data})
    })

            // wx.cloud.callFunction({
            //   name: 'runDB',
            //   data: {
            //     type:"col_get", //指定操作是collection get直接获取数据
            //     collection:"store", //指定操作的集合
            //     skip:0,
            //     limit:20
            //   },
            //   success: res => {
            //     for( var i=0;i<res.result.data.length;i++){//数组对key操作：中英字符转换-英文数据绑定wxml
            //       res.result.data[i].safetyScore=res.result.data[i].饮食卫生评分
            //       delete res.result.data[i].饮食卫生评分
            //       res.result.data[i].tasteScore=res.result.data[i].好吃程度评分
            //       delete res.result.data[i].好吃程度评分
            //       res.result.data[i].speedScore=res.result.data[i].出餐速度评分
            //       delete res.result.data[i].出餐速度评分
            //       res.result.data[i].totalScore=res.result.data[i].综合评分
            //       delete res.result.data[i].综合评分
            //     }
            //     this.setData({
            //       stores:res.result.data,
            //     })
            //     console.log(res.result.data)
            //   }
            // })

  

  },

  //顶部tabbar点击响应事件
  itemclick:function(event){
    console.log(event.detail);//detail==>myEventDetail
    let index=event.detail.index;
    let name=event.detail.name;
    //todo界面跳转等 根据传过去的name值
    wx.navigateTo({
      url: '../tabDetail/tabDetail?name='+name,
    })
  },

  toDetailStore:function(event){
    wx.navigateTo({
      url: '../storeDetail/storeDetail?store_id='+event.currentTarget.dataset.id,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },


  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.setData({
      isLoadingMoreData:false,
      hasMoreData:false
     })
    if (this.data.isRefreshing || this.data.isLoadingMoreData || !this.data.hasMoreData) {
      return
    }
    
    // this.setData({
    //   isLoadingMoreData: true
    // })

    // wx.cloud.callFunction({
    //         name: 'runDB',
    //         data: {
    //           type:"col_get", //指定操作是collection get直接获取数据
    //           collection:"store", //指定操作的集合
    //           skip:this.data.count,
    //           limit:20
    //         },
    //         success: res => {
    //           console.log(that)
    //           this.setData({
    //             count:that.data.count+1
    //           })
    //           if(res.result.data.length==0){
    //             this.setData({
    //               hasMoreData:false,
    //               isLoadingMoreData:false
    //             })
    //           }
    //           else{
    //             var new_store=res.result.data
    //             this.data.stores=this.data.stores.concat(new_store)
    //             this.setData({
    //               stores: this.data.stores,
    //               isLoadingMoreData:false,
    //               hasMoreData:true

    //             })
    //             console.log(res.result.data)
    //             console.log(this.data.stores)
    //           }
              
    //         }
    //       })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})