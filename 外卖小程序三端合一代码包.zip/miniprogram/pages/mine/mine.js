const db = wx.cloud.database()

  Page({
    data: {
      ne:[],
      isSignin:false
    },

    onShow: function (){
      var _isSignin = wx.getStorageSync('isSignin');
      this.setData({
        isSignin: _isSignin
      })
    var _customer = wx.getStorageSync('customer');
    let target = _customer.stu_ID
    let _id=_customer._id
    this.setData({
      _id:_id
    })
    console.log('tar',target)
    this.Get_icon()

    if(typeof(target) == "undefined"){
      console.log('undefined')
      this.setData({
        isSignin:false
      })
    } else {

    db.collection('customer').where({
      //done: false,
      //progress: 50,
      stu_ID: target
    })
      .get({
        success: res => {
          console.log(res.data)

          for(var i=0;i<res.data.length;i++){
            res.data[i].grade=res.data[i].年级
            delete res.data[i].年级
            res.data[i].college=res.data[i].学院
            delete res.data[i].学院
          }
        this.setData({
          ne: res.data,
          coupon_total:res.data[0].coupon
        })
console.log('necoupon',this.data.ne,this.data.coupon_total)
        var couple_total_num = 0

        for(var i=0;i<res.data[0].coupon.length;i++){     
          couple_total_num += res.data[0].coupon[i].coupon_num
          }
          this.setData({
            _number:couple_total_num
          })

        var credit_total_num = 0

          for(var i=0;i<res.data[0].credit.length;i++){     
            credit_total_num += res.data[0].credit[i].credit_change
            }
            this.setData({
              _number2:credit_total_num
            })
            
            
          this.setData({
            _number3:res.data[0].favorites.length
          })
          console.log('number3',this.data._number3)
      
    }
      })
    }
    },
    Get_icon:function(){
      var _id=this.data._id;
      wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type:"get", //指定操作是get  查找
        collection:"customer", //指定操作的集合
        condition:{ //指定where查找的要求字段
          _id:_id,
        }
      },
      complete: res => {
        this.setData({
          myInfo: res.result.data,
          customer_icon_url: res.result.data[0].customer_icon_url
        })
        console.log('customer_icon_url为', this.data.customer_icon_url)
      }
    })
},

  //进入积分界面
  credit(){
    wx.navigateTo({
      url: '/pages/credit/credit',
    })
  },

  //进入红包界面
    packet() {
      wx.navigateTo({
        url: '/pages/packet/packet',
      })
    },

  //进入收藏界面
    collect() {
      wx.navigateTo({
        url: '/pages/collect/collect',
      })
    },

    //进入主页
    home() {
      wx.navigateTo({
        url: '/pages/homepage/homepage',
      })
    },

    //进入公益排行
    donate_doc() {
      wx.navigateTo({
        url: '/pages/donate_doc/donate_doc',
      })
    },

    //进入设置
    setting() {
      wx.navigateTo({
        url: '/pages/setting/setting',
      })
    },

    //进入我的订单
    my_menu() {
      wx.navigateTo({
        url: '/pages/my_order/my_order',
      })
    },


    //进入朋友论坛
    gosign() {
      wx.navigateTo({
        url: '/pages/signin/signin',
      })
    },

    //进入我的地址
    adress() {
      wx.navigateTo({
        url: '/pages/adress/adress',
      })
    },

   

})

