//时间转换（未调试完）
// var time = require('../../utils/util.js');
// var sjc = 1582434478785;
// console.log(time.formatTime(sjc, 'Y/M/D h:m:s'));
// console.log(time.formatTime(sjc, 'h:m'));

const db = wx.cloud.database()

Page({
  data: {
    ne: []
  },

  onLoad: function () {
    var _customer = wx.getStorageSync('customer');
    let target = _customer.stu_ID
    let _id=_customer._id
    this.setData({
      _id:_id
    })

    console.log('tar',target)
      db.collection('customer').where({
        stu_ID:target,
        // _openid: 'orderInfo'
      })
        .get({
          success: res => {
            console.log(res.data)
            //success: console.log,
            this.setData({
              ne: res.data[0].credit
            })
            var credit_total_num = 0

            for(var i=0;i<res.data[0].credit.length;i++){     
              credit_total_num += res.data[0].credit[i].credit_change
              }
              this.setData({
                _number:credit_total_num
              })
              console.log(this.data._number)

          }
        })
       


    // var _customer = wx.getStorageSync('customer');

    // var _time1 = _customer.credit.credit_operation1.time;
    // var _time2 = _customer.credit.credit_operation2.time;
    // var _time3 = _customer.credit.credit_operation3.time;

    // var that = this;

    // wx.getStorage({
    //   key: 'customer',
    //   success: function (res) {
    //     that.setData({
    //       orderInfo: res.data._openid
    //     })
    //   }
    // }),
    
    //   db.collection('customer').where({
    //     _openid: 'orderInfo'
    //   })
    //     .get({
    //       success: res => {
    //         console.log(res.data)
    //         //success: console.log,
    //         this.setData({
    //           ne: res.data
    //         })
            
    //       }
    //     }),

    // this.setData({
    //   Time: [{ time1:_time1 , time2:_time2, time3:_time3 }]
    // })
     
    
  }
})

