// miniprogram/pages/signup/signup.js
Page({
  data: {
    账号: '',
    密码: ''
  },
  //获取账号
  inputName(event) {
    console.log('获取输入的账号', event.detail.value)
    this.setData({
      账号: event.detail.value
    })
  },
  // 获取密码
  inputPassword(event) {
    console.log('获取输入的密码', event.detail.value)
    this.setData({
      密码: event.detail.value
    })
  },

  //注册
  signup() {
    let 账号 = this.data.账号
    let 密码 = this.data.密码
    console.log("点击了注册")
    console.log("账号", 账号)
    console.log("密码", 密码)
    //校验用户名
    if (账号.length < 2) {
      wx.showToast({
        icon: 'none',
        title: '账号至少6位',
      })
      return
    }
    if (账号.length > 20) {
      wx.showToast({
        icon: 'none',
        title: '账号最多20位',
      })
      return
    }
    //校验密码
    if (密码.length < 6) {
      wx.showToast({
        icon: 'none',
        title: '密码至少6位',
      })
      return
    }
    wx.cloud.database().collection('store').where({
      账号: 账号,
    }).get({
      success(res) {
        console.log("获取现有账号数据成功", res)
        let store = res.data
        if(store.length>=1)
        {
          console.log("存在重复账号");
          wx.showToast({
            icon: 'none',
            title: '该账号已被注册',
          })
          return
        }
        else if(store.length==0)
        {
          wx.cloud.database().collection('store').add({
            data: {
              账号: 账号,
              密码: 密码
            },
            success(res) {
              console.log('注册成功', res)
              wx.showToast({
                title: '注册成功',
              })
              //把id存起来
              var storeid = res._id;
              wx.setStorageSync('id', storeid)
              wx.navigateTo({
                url: '../InitStore/InitStore',
              })
            },
            fail(res) {
              console.log('注册失败', res)
            }
          })
        }
      },
      fail(res) {
        console.log("获取数据失败", res)
      }
    })
    
    
  }
})