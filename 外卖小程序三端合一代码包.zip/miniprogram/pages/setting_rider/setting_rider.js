const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`
Page({

  /**
   * 页面的初始数据
   */
  data: {
    _id:'',
    rider_icon_url:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  //获取骑手登陆的_id
  onLoad: function (options) {
    var that = this
    wx.getStorage({
      key: 'rider',
      success: function (res) {
        console.log(res.data._id)
        that.setData({
          _id: res.data._id
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },
  Change_icon:function() {
    var that = this;
    var _id=that.data._id;//获取rider中的id号
    console.log("骑手id为",_id)
    //让用户选择或拍摄一张照片
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        //选择完成会先返回一个临时地址保存备用
        const tempFilePaths = res.tempFilePaths

        wx.cloud.uploadFile({
          cloudPath: 'rider/' + _id + '/' + 'ridericon.png',
          filePath: tempFilePaths[0],
          success(res) {
            //上传成功后会返回永久地址
            console.log('tempFilePaths[0]为', tempFilePaths[0])
            console.log('res.fileID为', res.fileID)
            that.setData({
              rider_icon_url: res.fileID
            })
            wx.cloud.callFunction({
              name: 'runDB',
              data: {
                type: "update", //指定操作是update
                collection: "rider", //指定操作的集合
                _id: _id,
                data: { //指定update的数据
                  rider_icon_url: res.fileID,
                }
              },
              success: res => {
                console.log('已经上传图片地址' + res.fileID)
      
              },
              fail: err => {
                console.error('上传失败', err)
              }
            })
          wx.navigateTo({
            url: '../mine_rider/mine_rider',
          })
            console.log('能加载的')
          }
        })







        //将照片上传至云端需要刚才存储的临时地址
        // wx.cloud.uploadFile({
        //   cloudPath: 'rider/' + that.data._id + '/' + 'icon.png',
        //   filePath: tempFilePaths[0],
        //   success(res) {
        //     //上传成功后会返回永久地址
        //     //console.log(res.fileID)
        //     that.setData({
        //       rider_icon_url: res.fileID
        //     }),
        //       console.log('要存入的数据库的rider_id为', that.data.rider_icon_url)
        //     //  wx.cloud.database().collection('rider').doc(that.data._id).update({
        //     //   data: {
        //     //     rider_icon_url: res.fileID
        //     //   },
        //     //   success: console.log

        //     // })
        //   }
        // })
      }
    })
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  quitFn(){
    wx.removeStorage({
      key: 'isSignin_rider',
      success: function (res) {
      wx.navigateTo({
        url: '/pages/signin_rider/signin_rider',
      })
  }
})
  },
  change_icon(){
    var that = this
    //让用户选择或拍摄一张照片
    wx.chooseImage({
      count: 1,	
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
      //选择完成会先返回一个临时地址保存备用
        const tempFilePaths = res.tempFilePaths
        //将照片上传至云端需要刚才存储的临时地址
        wx.cloud.uploadFile({
          cloudPath: 'rider/'+that.data.stu_ID+'/'+'icon.png',
          filePath: tempFilePaths[0],
          success(res) {
          //上传成功后会返回永久地址
             console.log(res.fileID) 
             that.setData({
              rider_icon_url:res.fileID
             })
             wx.cloud.database().collection('rider').doc(that.data.stu_ID).update({
               data:{
                rider_icon_url:res.fileID
               },
               success:console.log
              
             })
          }
        })
      }
    })
  },
})