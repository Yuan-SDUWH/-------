// miniprogram/pages/InitOver/InitOver.js
const db = wx.cloud.database({
  env: 'bluetooth-fd3ok'
})
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  NextPage: function(){
    var storeid=wx.getStorageSync('id');
    console.log('AOOO');
    wx.navigateTo({
      url: '../Signin_store/Signin_store',
    })
  }
})