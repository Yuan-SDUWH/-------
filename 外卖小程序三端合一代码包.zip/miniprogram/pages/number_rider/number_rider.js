const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`

Page({
  data: {
    today_year: '',
    today_month: '',
    today_day: '',
    todaydate:'',
    arryseven:[],
    myriderInfo:'',
    income_today:'',
    sales_number_today:'',
    sales_number_seven:'',
    income_seven:'',
  },
  //获取近7天的日期存入一个数组 先判断所处日（>7  月份：本月月份 日：由今日向前递推     <7  月份：上月月份  日：    由上月月份向前递推）
  GetSevenday:function(){
      //获取今日月份和日期
    var today_year=this.data.today_year;
    var today_month=this.data.today_month;
    var today_day = this.data.today_day;
    var arryseven=[];
    // today_day='06';
    // today_month='03';
    // today_year=2019;
    //对日期判断
    if(today_day>7){
        var last_seven_day=today_day-8;
        var day;
        var i;
        //获取近7日的完整年、月、日 存入数组arryseven
          //判断日是否为2位数，是：直接用；否：字符串拼接
        for(i=0;i<7;i++){
          last_seven_day = last_seven_day + 1;
          if(last_seven_day<10){        
            day='_'+today_year+'_'+today_month+'_'+'0'+last_seven_day;
            arryseven[i]=day;
          }
          else{
            day='_'+today_year+'_'+today_month+'_'+last_seven_day;
            arryseven[i] = day;
          }
        }
    }
    //today_day<=7时，即过去7天有日期在上个月
    else{
      console.log('today_day<=7')
        //计算在上个月的天数  lastmonth_day
        var lastmonth_day=7-today_day+1;
        //上个月为31天的月份：
      if ((today_month == '02')||(today_month == '04')||(today_month == '06')||(today_month == '08')||(today_month == '09')||(today_month == '11')|| (today_month =='01')){
          //计算上个月份
          console.log('月份或条件没问题')
            var last_month;
            if(today_month=='01'){
              last_month=12;
            }
            else if ((today_month == '02') || (today_month == '04') || (today_month == '06') || (today_month == '08') || (today_month == '09')){
              last_month=today_month-1;
              last_month='0'+last_month;
            }
            else{
              last_month=today_month-1;
            }
            console.log('lastmonth_day', lastmonth_day);
            //计算在上个月的那些日期
            //在上个月的第一天为30-lastmonth_day+1;
            var m = lastmonth_day;
            for(i=0;i<m;i++){
              lastmonth_day = 31 - m + 1+i;
              day='_'+today_year+'_'+last_month+'_'+lastmonth_day;
              arryseven[i]=day;
              console.log('本次循环的i为',i)
              console.log('本次循环的lastmonth_day为', lastmonth_day)
            };
            //将本月的几天的日期存入arryseven数组的后面  存的下标为i到6，共存了（6-i+1）天;对应的日期为
            var todaymonth_day=6-i+1;//7天在本月的天数
            console.log('i',i)
            console.log('在本月的天数为',todaymonth_day)
            var j = 1;;
            for (i;i<7;i++){
              console.log('添加本月的几天日期')           
              day='_'+today_year+'_'+today_month+'_'+'0'+j;
              arryseven[i]=day;
              j++;
              }
          }    
          //上个月为30天的月份
        else if ((today_month == '05') || (today_month == '07') || (today_month == '10') || (today_month == '12')) {
          //计算上个月份
          console.log('月份或条件没问题')
          var last_month;//计算上个月
          if ((today_month == '05') || (today_month == '07') || (today_month == '10')) {
            last_month = today_month - 1;
            last_month = '0' + last_month;
          }
          else {
            last_month = today_month - 1;
          }
          console.log('lastmonth_day', lastmonth_day)
            //计算在上个月的那些日期
            //在上个月的第一天为31-lastmonth_day+1;
            var m = lastmonth_day;
          for (i = 0; i < m; i++) {
            lastmonth_day = 30 - m + 1 + i;
            day = '_' + today_year + '_' + last_month + '_' + lastmonth_day;
            arryseven[i] = day;
            console.log('本次循环的i为', i)
            console.log('本次循环的lastmonth_day为', lastmonth_day)
          };
          //将本月的几天的日期存入arryseven数组的后面  存的下标为i到6，共存了（6-i+1）天;对应的日期为
          var todaymonth_day = 6 - i + 1;//7天在本月的天数
          console.log('i', i)
          console.log('在本月的天数为', todaymonth_day)
          var j = 1;;
          for (i; i < 7; i++) {
            console.log('添加本月的几天日期')
            day = '_' + today_year + '_' + today_month + '_' + '0' + j;
            arryseven[i] = day;
            j++;
          }
      }  
      //上个月是2月份
      else{
        //计算上个月份
        console.log('上个月是2月份')
        var last_month;//计算上个月
          last_month = '02';
          console.log('lastmonth_day', lastmonth_day)
        //计算在上个月的那些日期
        //在上个月的第一天为29-lastmonth_day+1;
        var m = lastmonth_day;
        for (i = 0; i < m; i++) {
          if (((today_year % 4 == 0) && (today_yearr % 100 == !0)) || (today_year % 400 == 0)){
            lastmonth_day = 29 - m + 1 + i;
          }
          else{
            lastmonth_day = 28 - m + 1 + i;
          }
          day = '_' + today_year + '_' + last_month + '_' + lastmonth_day;
          arryseven[i] = day;
          console.log('本次循环的i为', i)
          console.log('本次循环的lastmonth_day为', lastmonth_day)
        };
        //将本月的几天的日期存入arryseven数组的后面  存的下标为i到6，共存了（6-i+1）天;对应的日期为
        var todaymonth_day = 6 - i + 1;//7天在本月的天数
        console.log('i', i)
        console.log('在本月的天数为', todaymonth_day)
        var j = 1;;
        for (i; i < 7; i++) {
          console.log('添加本月的几天日期')
          day = '_' + today_year + '_' + today_month + '_' + '0' + j;
          arryseven[i] = day;
          j++;
        }
      }  


    }
    this.setData({
      arryseven:arryseven
    });
    console.log('近7天为',this.data.arryseven)
  },
  //获取今日日期 存入today_year，today_month,today_day
  getToday: function () {
      var timestamp = Date.parse(new Date());
      var date = new Date(timestamp);
      //获取年份  
      var Y = date.getFullYear();
      //获取月份  
      var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
      //获取当日日期 
      var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
      var todaydate = "_" + Y + '_' + M + '_' + D;
      var today = this;

      today.setData({
        today_year: Y,
        today_month: M,
        today_day: D,
        todaydate:todaydate,
      });
   },
  onLoad: function () {
      this.getToday();
      this.GetSevenday();    
      this.GetNumber();
  },
  GetNumber:function(){
    var _customer = wx.getStorageSync('customer');
    //console.log('customer', _customer)
    var userid = _customer.stu_ID;

    console.log('userid', userid);
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "rider", //指定操作的集合
        condition: { //指定where查找的要求字段
          stu_ID: userid
        }
      },
      success: res => {
        this.setData({
          myriderInfo: res.result.data[0],
        });
        var myriderInfo = res.result.data[0];
        var income=myriderInfo.income;
        var sales_number=myriderInfo.sales_number;
        console.log('income为',income);
        console.log('sales_number为',sales_number);
        var arryseven=this.data.arryseven;
        var todaydate=this.data.todaydate;
        console.log('今日收入为',income[arryseven[5]])
        //获取今日订单数和收入，存入sales_number_today和income_today
        if(income[todaydate]==undefined){
          this.setData({
            income_today:0,
            });
         }
        else { 
          this.setData({ 
            income_today:income[todaydate]
            });
        }
        if (sales_number[todaydate] == undefined) {
          this.setData({
            sales_number_today: 0,
          });
        }
        else {
          this.setData({
            sales_number_today: income[todaydate]
          });
        }
        //计算近7天的收入和订数之和存入sales_number_seven 和income_seven
        var i;
        var sales_number_seven = 0;
        for(i=0;i<7;i++){      
          if(sales_number[arryseven[i]]==undefined){
  
          }
          else{
            sales_number_seven += sales_number[arryseven[i]]
          }
        }
        console.log('近7天订单量为', sales_number_seven)
        var income_seven=0;
        for (i = 0; i < 7; i++) {
          if (income[arryseven[i]] == undefined) {

          }
          else {
            income_seven += income[arryseven[i]]
          }
        }
        this.setData({
          sales_number_seven: sales_number_seven,
          income_seven: income_seven
        })
        console.log('近7天订单收入为', income_seven)
      }
    })
  },
})

