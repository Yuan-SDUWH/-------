const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`
var util = require('../../utils/util.js');
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    currtab: 0,
    swipertab: [{ name: '进行中', index: 0 }, { name: '加急送', index: 1 },{ name: '已完成', index: 2 }],
    id:'',
    success_order_url:'',
    todaydate :'',
    sign:false
    
  },
 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var sign=wx.getStorageSync('isSignin_rider')
    this.setData({
      sign:sign
    })
   this.getToday();
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // 页面渲染完成
    this.getDeviceInfo()
    this.orderShow()
  },
  //订单完成后点击  实现改变订单状态+上传图片
  SuccessOrder:function(e){
     //先上传图片
    //获取点击的订单id为$_id
    var $_id = e.currentTarget.dataset.id; //打印可以看到，此处已获取到了对应的id
    console.log($_id)
    var that = this;
    var date = util.formatTime1(new Date());
    var minutes = util.formatTime2(new Date());
    //让用户选择或拍摄一张照片
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        //照片拍摄或选择成功之后
          //选择完成会先返回一个临时地址保存备用
        const tempFilePaths = res.tempFilePaths
        console.log('tempFilePaths为', tempFilePaths)
        //将照片上传至云端需要刚才存储的临时地址
        wx.cloud.uploadFile({
          cloudPath: 'order/' + $_id + '/' + 'successOrder.png',
          filePath: tempFilePaths[0],        
          success(res) {
            //返回图片路径成功之后
              //上传成功后会返回永久地址
            console.log('tempFilePaths[0]为', tempFilePaths[0])
            console.log('res.fileID为',res.fileID)
            that.setData({
              success_order_url: res.fileID
            })
              //更新该$_id对应_id的订单：成功图片、当前状态、送达时间（日期和分秒）
            wx.cloud.callFunction({
                name: 'runDB',
                data: {
                  type:"update", //指定操作是update
                  collection:"extra_need", //指定操作的集合
                  _id: $_id,
                  data:{ //指定update的数据
                    success_order_url: res.fileID,
                    当前状态:'已完成',
                    'time_to_date': date,
                    'time_to_minutes':minutes
                  }
                },
                success: res => {
                  console.log('已经上传图片地址' + res.fileID)
                  //订单状态修改完成之后，获取该订单的跑腿费
                      wx.cloud.callFunction({
                        name: 'runDB',
                        data: {
                          type:"get", //指定操作是get  查找
                          collection:"extra_need", //指定操作的集合
                          condition:{ //指定where查找的要求字段
                            _id: $_id,
                          }
                        },
                        complete: res => {
                          var run_income = res.result.data[0].跑腿费
                            //将跑腿费 run_income存入  rider集合    今日的income（累加）和今日的sales_number(累加)
                            //获取今日日期，判断rider中当前用户的今日income和sales_number是否存在（若不存在，直接update一个新的 【怎么在对象里update】；若存在，则获取今日的income和sales_number，进行累加，重新update上去）
                          //获取今日日期
                          var todaydate =that.data.todaydate;
                          //获取骑手的_id
                          var _rider = wx.getStorageSync('rider');                     
                          var _id = _rider._id;
                          //获取当前骑手的所有信息
                          wx.cloud.callFunction({
                            name: 'runDB',
                            data: {
                              type: "get", //指定操作是get  查找
                              collection: "rider", //指定操作的集合
                              condition: { //指定where查找的要求字段
                                _id: _id,
                              }
                            },
                            complete: res => {
                              //获取当前骑手的详细信息存入 rider_detail
                              var rider_detail = res.result.data[0];
                              var income=rider_detail.income;
                              var sales_number=rider_detail.sales_number;
                              //更新rider的sales_number和income   income  sales_number
                              var key;
                              var value;
                              var incomeTMPvalue;
                              var numberTMPvalue;
                              if (income[todaydate] == undefined) {
                                key = todaydate;
                                value = run_income;
                                income[key] = value;
                              }
                              else if (income[todaydate] != undefined) {
                                incomeTMPvalue = income[todaydate];
                                incomeTMPvalue += run_income;
                                income[todaydate] = incomeTMPvalue;
                              }
                              if (sales_number[todaydate] == undefined) {
                                key = todaydate;
                                value = 1;
                                sales_number[key] = value;
                              }
                              else if (sales_number[todaydate] != undefined) {
                                numberTMPvalue = sales_number[todaydate];
                                numberTMPvalue += 1;
                                sales_number[todaydate] = numberTMPvalue;
                              }
                              //更新rider的内容
                              wx.cloud.callFunction({
                                name: 'runDB',
                                data: {
                                  type: "update",
                                  collection: "rider",
                                  _id: _id,
                                  data: {
                                    sales_number: sales_number,
                                    income: income,
                                  },
                                },
                                success: res => {
                                  console.log('rider更新成功',res);
                                
                                },
                              })
                        




                             }
                           })



                        }
                      })





                },
                fail: err => {
                  console.error('上传失败', err)
                }
              })




            that.onReady();
            console.log('能加载的')



          }
        })
      }
    })
  },

  
  //获取今日日期
  getToday: function () {

    var timestamp = Date.parse(new Date());
    var date = new Date(timestamp);
    //获取年份  
    var Y = date.getFullYear();
    //获取月份  
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    //获取当日日期 
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    var todaydate = "_" + Y + '_' + M + '_' + D;
    var today = this;

    today.setData({
      todaydate: todaydate 
    });
  },
  getDeviceInfo: function () {
    let that = this
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          deviceW: res.windowWidth,
          deviceH: res.windowHeight
        })
      }
    })
  },
 
  /**
  * @Explain：选项卡点击切换
  */
  tabSwitch: function (e) {
    var that = this
    if (this.data.currtab === e.target.dataset.current) {
      return false
    } else {
      that.setData({
        currtab: e.target.dataset.current
      })
    }
  },
 
  tabChange: function (e) {
    this.setData({ currtab: e.detail.current })
    this.orderShow()
  },
 
  orderShow: function () {
    let that = this
    switch (this.data.currtab) {
      case 0:
        that.alreadyShow()
        break
      case 1:
        that.waitPayShow()
        break
      case 2:
        that.lostShow()
        break
    }
  },

  //进行中（不要被英文迷惑！）
 alreadyShow:function(){
   //获取stu_ID
   var _rider = wx.getStorageSync('rider');
   var stu_ID = _rider.stu_ID

  wx.cloud.callFunction({
    name: 'runDB',
    data: {
      type:"get", //指定操作是get  查找
      collection:"extra_need", //指定操作的集合
      condition:{ //指定where查找的要求字段
         //rider: '201800820109',
        rider_ID: stu_ID,
         当前状态:'已接单'
      }
    },
    complete: res => {
      console.log('ridermenu',res.result.data)
      for(var i=0;i<res.result.data.length;i++){
        res.result.data[i].qh=res.result.data[i].取货地址
        delete res.result.data[i].取货地址
        res.result.data[i].sd=res.result.data[i].送达地点
        delete res.result.data[i].送达地点
        res.result.data[i].state=res.result.data[i].当前状态
        delete res.result.data[i].当前状态
        res.result.data[i].rapid=res.result.data[i].是否加急
        delete res.result.data[i].是否加急
        res.result.data[i].goods_money=res.result.data[i].货物价值_元
        delete res.result.data[i].货物价值_元
        res.result.data[i].rider_money=res.result.data[i].跑腿费
        delete res.result.data[i].跑腿费
        res.result.data[i].goods_num=res.result.data[i].取货码
        delete res.result.data[i].取货码
      }
      this.setData({
        ne1:res.result.data,
  })

      }

    })
 },

 
  waitPayShow:function(){
    var _customer = wx.getStorageSync('customer');
    var rider_stuID = _customer.stu_ID;
    console.log('riderstuID',rider_stuID)
  
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type:"get", //指定操作是get  查找
        collection:"extra_need", //指定操作的集合
        condition:{ //指定where查找的要求字段
          // 接单骑手stu_ID: rider_stuID,
          rider_ID: rider_stuID,
          当前状态:'已接单',
          是否加急:'Yes'
        }
      },
      complete: res => {
        console.log('ridermenu',res.result.data)
        for(var i=0;i<res.result.data.length;i++){
          res.result.data[i].qh=res.result.data[i].取货地址
          delete res.result.data[i].取货地址
          res.result.data[i].sd=res.result.data[i].送达地点
          delete res.result.data[i].送达地点
          res.result.data[i].state=res.result.data[i].当前状态
          delete res.result.data[i].当前状态
          res.result.data[i].rapid=res.result.data[i].是否加急
          delete res.result.data[i].是否加急
          res.result.data[i].goods_money=res.result.data[i].货物价值_元
          delete res.result.data[i].货物价值_元
          res.result.data[i].rider_money=res.result.data[i].跑腿费
          delete res.result.data[i].跑腿费
          res.result.data[i].goods_num=res.result.data[i].取货码
          delete res.result.data[i].取货码
        }
        this.setData({
          ne2:res.result.data,
    })
  
        }
  
      })
  },

 
  lostShow: function (){
    var _customer = wx.getStorageSync('customer');
    var rider_stuID = _customer.stu_ID;
    console.log('riderstuID',rider_stuID)
  
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type:"get", //指定操作是get  查找
        collection:"extra_need", //指定操作的集合
        condition:{ //指定where查找的要求字段
           //接单骑手stu_ID: rider_stuID,
           rider_ID: rider_stuID,
           当前状态:'已完成',
        }
      },
      complete: res => {
        console.log('ridermenu',res.result.data)
        for(var i=0;i<res.result.data.length;i++){
          res.result.data[i].qh=res.result.data[i].取货地址
          delete res.result.data[i].取货地址
          res.result.data[i].sd=res.result.data[i].送达地点
          delete res.result.data[i].送达地点
          res.result.data[i].state=res.result.data[i].当前状态
          delete res.result.data[i].当前状态
          res.result.data[i].rapid=res.result.data[i].是否加急
          delete res.result.data[i].是否加急
          res.result.data[i].goods_money=res.result.data[i].货物价值_元
          delete res.result.data[i].货物价值_元
          res.result.data[i].rider_money=res.result.data[i].跑腿费
          delete res.result.data[i].跑腿费
          res.result.data[i].goods_num=res.result.data[i].取货码
          delete res.result.data[i].取货码
          res.result.data[i].rider_point=res.result.data[i].服务评分
          delete res.result.data[i].服务评分
        }
        this.setData({
          ne3:res.result.data,
    })
  
        }
  
      })
  },
})
 
