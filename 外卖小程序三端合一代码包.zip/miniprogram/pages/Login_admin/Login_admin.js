// miniprogram/pages/Login_admin/Login_admin.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  //输入秘钥
  miyao(event) {
    console.log('获取输入的秘钥', event.detail.value)
    this.setData({
      secretkey: event.detail.value
    })
  },

  Commit: function(){
    var secretkey=this.data.secretkey;
    console.log(secretkey)
    if(secretkey=='XIAOZHU')
    {
      wx.showToast({
        title: '输入正确！',
      })
      wx.navigateTo({
        url: '../ShowFeedback_admin/ShowFeedback_admin',
      })
    }
    else{
      wx.showToast({
        icon: 'none',
        title: '秘钥输入错误！',
      })
    }
  }

})