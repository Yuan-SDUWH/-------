// pages/addFunction/addFunction.js

// let app1 = getApp();
//拿到小程序app.js的对象
var util = require('../../utils/util.js');
const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`
Page({
  data: {
    time: '',
    today: '',
    time_get: {}
  },
  readDetail: function (e) {
    var date = util.formatTime1(new Date());
    var minutes = util.formatTime2(new Date());
    var $_id = e.currentTarget.dataset.id; //打印可以看到，此处已获取到了对应的id
    console.log($_id);
    var _rider = wx.getStorageSync('rider');
    var userid = _rider.stu_ID
    console.log(userid);
    wx.cloud.callFunction({
	name: 'runDB',
	data: {
		type:"update", //指定操作是update
    collection:"extra_need", //指定操作的集合
    _id: $_id,
		data:{ //指定update的数据
      "当前状态": "已接单",
       time_get: { 'date': date, 'minutes': minutes },
       rider_ID: userid
		}
	},
	success: res => {
    console.log('[云函数] [updateDB] 已更改当前状态信息' + $_id)
	},
	fail: err => {
		console.error('[云函数] [updateDB]更改当前状态失败', err)
	}
}),
this.onLoad();
  },
  onLoad: function () {
    // var userid = wx.getStorageSync('id');
   // console.log(userid);
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "extra_need", //指定操作的集合
        condition: { //指定where查找的要求字段
          需求种类:"快递",
          当前状态:"待接单"
        }
      },
      success: res => {
        this.setData({
          showKuaidi: res.result.data,
        });
        console.log(this.data.showKuaidi)
      }
    })
  },
  onShow: function () {

  },
});

