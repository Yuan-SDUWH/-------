// miniprogram/pages/InitStore/InitStore.js
//
wx.cloud.init({
  env: 'bluetooth-fd3ok'
})

const db = wx.cloud.database({
  env: 'bluetooth-fd3ok' 
})

Page({

  /**
   * 页面的初始数据
   */
  data: {
    store_name:'',
    店铺地址:'',
    add1:'',
    add2:'',
    店铺介绍:'',
    优惠设置:'',
    discount1: '',
    discount2: '',
    discount3: '',
    discount4: '',
    discount5: '',
    discount6: '',
    discount7: '',
    discount8: '',
    会员专享:'',
    RoyalDiscount1: '',
    RoyalDiscount2: '',
    RoyalDiscount3: '',
    出餐速度评分:'',
    好吃程度评分:'',
    拒单次数:'',
    综合评分:'',
    被投诉情况:'',
    goods:[],
  },

  //获取店铺名
  inputStorename(event) {
    console.log('获取输入的店铺名', event.detail.value)
    this.setData({
      store_name: event.detail.value
    })
  },
  
  //获取店铺地址1
  inputStoreAddress1(event) {
    console.log('获取输入的店铺地址（建筑）', event.detail.value)
    this.setData({
      add1: event.detail.value
    })
  },

  //获取店铺地址2
  inputStoreAddress2(event) {
    console.log('获取输入的店铺地址（楼层）', event.detail.value)
    this.setData({
      add2: event.detail.value
    })
  },

  //获取店铺介绍
  inputStoreText(event) {
    console.log('获取输入的店铺介绍', event.detail.value)
    this.setData({
      店铺介绍: event.detail.value
    })
  },

  //获取优惠1
  inputDiscount1(event) {
    console.log('获取输入的优惠1', event.detail.value)
    this.setData({
      discount1: event.detail.value
    })
  },

  //获取优惠2
  inputDiscount2(event) {
    console.log('获取输入的优惠2', event.detail.value)
    this.setData({
      discount2: event.detail.value
    })
  },

  //获取优惠3
  inputDiscount3(event) {
    console.log('获取输入的优惠3', event.detail.value)
    this.setData({
      discount3: event.detail.value
    })
  },

  //获取优惠4
  inputDiscount4(event) {
    console.log('获取输入的优惠4', event.detail.value)
    this.setData({
      discount4: event.detail.value
    })
  },

  //获取优惠5
  inputDiscount5(event) {
    console.log('获取输入的优惠5', event.detail.value)
    this.setData({
      discount5: event.detail.value
    })
  },

  //获取优惠6
  inputDiscount6(event) {
    console.log('获取输入的优惠6', event.detail.value)
    this.setData({
      discount6: event.detail.value
    })
  },

  //获取优惠7
  inputDiscount7(event) {
    console.log('获取输入的优惠7', event.detail.value)
    this.setData({
      discount7: event.detail.value
    })
  },

  //获取优惠8
  inputDiscount8(event) {
    console.log('获取输入的优惠8', event.detail.value)
    this.setData({
      discount8: event.detail.value
    })
  },

  //获取会员优惠1
  inputRoyalDiscount1(event) {
    console.log('获取输入的会员优惠1', event.detail.value)
    this.setData({
      RoyalDiscount1: event.detail.value
    })
  },

  //获取会员优惠2
  inputRoyalDiscount2(event) {
    console.log('获取输入的会员优惠2', event.detail.value)
    this.setData({
      RoyalDiscount2: event.detail.value
    })
  },

  //获取会员优惠3
  inputRoyalDiscount3(event) {
    console.log('获取输入的会员优惠3', event.detail.value)
    this.setData({
      RoyalDiscount3: event.detail.value
    })
  },

  //获取公益捐助额
  inputStoreDonate(event) {
    console.log('获取输入的每单公益捐助额', event.detail.value)
    this.setData({
      公益捐助额_元: event.detail.value
    })
  },

  //获取出餐时间
  inputPrepareTime(event) {
    console.log('获取输入的出餐时间', event.detail.value)
    this.setData({
      出餐时间: event.detail.value
    })
  },

  CommitAll(){
    let store_name = this.data.store_name;
    let add1=this.data.add1;
    let add2=this.data.add2;
    let 店铺介绍=this.data.店铺介绍;
    let discount1 = this.data.discount1;
    let discount2 = this.data.discount2;
    let discount3 = this.data.discount3;
    let discount4 = this.data.discount4;
    let discount5 = this.data.discount5;
    let discount6 = this.data.discount6;
    let discount7 = this.data.discount7;
    let discount8 = this.data.discount8;
    let RoyalDiscount1 = this.data.RoyalDiscount1;
    let RoyalDiscount2 = this.data.RoyalDiscount2;
    let RoyalDiscount3 = this.data.RoyalDiscount3;
    let 公益捐助额_元 = this.data.公益捐助额_元;
    let ImageID = this.data.fileIDs;
    let 出餐时间=this.data.出餐时间;
    //console.log("store_name", store_name);
    var storeid=wx.getStorageSync('id');
    console.log(storeid);
    db.collection('store').doc(storeid).update({
      data:{
        store_name: store_name,
        donation: {'_1999_12':12},
        sales_number: {'_1999_09_23':12},
        sales: {'_1999_12_01':169},
        store_icon_url: ImageID,
        "店铺地址":{'建筑':add1,'楼层':add2},
        "店铺介绍":店铺介绍,
        "优惠设置":{
          "优惠_1":discount1,
          "优惠_2":discount2,
          "优惠_3":discount3,
          "优惠_4":discount4,
          "优惠_5":discount5,
          "优惠_6":discount6,
          "优惠_7":discount7,
          "优惠_8":discount8,
        },
        "会员专享":{
          "活动_1":RoyalDiscount1,
          "活动_2":RoyalDiscount2,
          "活动_3":RoyalDiscount3,
        },
        
        出餐速度评分: 0,
        好吃程度评分: 0,
        饮食卫生评分:0,
        拒单次数: 0,
        综合评分: 0,

        "被投诉情况":{
          '':{

        },
          '':{

          }
        
        },
        goods:[],
        comment:[],
        comment_speed:[],
        comment_health:[],
        comment_taste:[],
        prepareTime:出餐时间,
        店铺状态:"营业中"
      },
      success: res=>{
        console.log('提交成功')
      },
      fail: err=>{
        console.error('提交失败')
      }
    })
    wx.navigateTo({
      url: '../InitGoods/InitGoods',
    })
  },
  
  takePhoto: function () { //拍照
    let _this = this
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      success(res) {
        // tempFilePath可以作为img标签的src属性显示图片
        const tempFilePaths = res.tempFilePaths
        _this.setData({
          tmpImg: tempFilePaths,
        })
        _this.saveImg();
      }
    })
  },

  saveImg: function () {  //保存图片
    let filePath = this.data.tmpImg[0];
    let suffix = /\.[^\.]+$/.exec(filePath)[0];  //正则表达式
    wx.cloud.uploadFile({    //上传文件到云空间
      cloudPath: "Camera/" + new Date().getTime() + suffix,
      filePath: filePath,//临时的图片路径
      config: { env: 'bluetooth-fd3ok' }
    }).then(res => {
      console.log(res);
      this.setData({
        fileIDs: res.fileID,
      });
      wx.showToast({
        title: '保存成功',
      })
      console.log('fileID：', this.data.fileIDs)
    })
  },

  Test(){
    console.log('111');
    db.collection('store').doc("d68532785e4125580d5703391f10e4d3").get({
      complete: function (res) {
        console.log('success!')
        console.log(res)
      }
    })
  }
  
})