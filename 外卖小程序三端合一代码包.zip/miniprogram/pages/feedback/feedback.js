// const url = require('../../utils/requireurl.js').url;
var util = require('../../utils/util.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    loading: false,
    contact: '',
    contant: ''
  },
 
  formSubmit: function (e) {
    var date = util.formatTime1(new Date());
    var minutes = util.formatTime2(new Date());
    console.log('DATE',date);
    console.log('MIN',minutes);
    var TIME=date+'  '+minutes;
    console.log(TIME);
    let _that = this;
    let content = e.detail.value.opinion;
    let contact = e.detail.value.contact;
    let regPhone = /^1[3578]\d{9}$/;
    let regEmail = /^[a-z\d_\-\.]+@[a-z\d_\-]+\.[a-z\d_\-]+$/i;
    if (content == "") {
      wx.showModal({
        title: '提示',
        content: '反馈内容不能为空!',
      })
      return false
    }
    if (contact == "") {
      wx.showModal({
        title: '提示',
        content: '手机号或者邮箱不能为空!',
      })
      return false
    }
    if (contact == "" && content == "") {
      wx.showModal({
        title: '提示',
        content: '反馈内容,手机号或者邮箱不能为空!',
      })
      return false
    }
    if ((!regPhone.test(contact) && !regEmail.test(contact)) || (regPhone.test(contact) && regEmail.test(contact))) { //验证手机号或者邮箱的其中一个对
      wx.showModal({
        title: '提示',
        content: '您输入的手机号或者邮箱有误!',
      })
      return false
    } else {
      wx.showToast({
        title: '提交成功',
        success: res => {
          wx.cloud.database().collection('feedback').add({
            data:{
              反馈内容: content,
              联系方式: contact,
              反馈时间: TIME,
            },
            success: res => {
              wx.navigateTo({
                url: '/pages/setting/setting',
              })
            }
          })
        }
      })
      
      
      // this.setData({
      //   loading: true
      // })
      // let model, system, platform;
      // wx.getSystemInfo({
      //   success: function (res) {
      //     model = res.model;
      //     system = res.system;
      //     platform = res.platform;
      //   }
      // })
      // wx.request({
      //   url: url + '/util/feedback',
      //   header: {
      //     'content-type': 'application/x-www-form-urlencoded'
      //   },
      //   data: {
      //     'content': content,
      //     'contact': contact,
      //     'device_model': model, //手机型号
      //     'device_system ': system, //操作系统版本
      //     'app_version': platform  //客户端平台
      //   },
      //   method: 'POST',
      //   success: function (res) {
      //     let status = res.data.status;
      //     if (status == 1) {
      //       _that.setData({
      //         loading: false,
      //         contact: '',
      //         contant: ''
      //       })
      //       wx.showToast({
      //         title: '成功',
      //         icon: 'success',
      //         duration: 1500
      //       })
      //     }
      //   },
      //   fail: function () {
      //     console.log("意见反馈接口调用失败")
      //   }
      // })
    }
  },
})