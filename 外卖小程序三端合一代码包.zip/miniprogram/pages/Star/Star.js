const app = getApp()
var util = require('../../utils/util.js');
const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`

Page({
  data: {
      star:0,
    success_order_url:''
  },

//获取这个订单的成功图片路径success_order_url(按照_id获取)
GetsuccessPicture:function(){
  var Star_ID = wx.getStorageSync('Star_ID');
          wx.cloud.callFunction({
            name: 'runDB',
            data: {
              type:"get", //指定操作是get  查找
              collection:"extra_need", //指定操作的集合
              condition:{ //指定where查找的要求字段
                _id: Star_ID,
              }
            },
            complete: res => {
              
              this.setData({
                success_order_url: res.result.data[0].success_order_url
              })
              console.log('订单完成图片地址', this.data.success_order_url)
            }
          })



},

  onLoad: function (options) { 
    this.GetsuccessPicture();
   },
 select:function(event) {
   this.setData({
     star: event.detail
   })
    console.log("传递成功啦",this.data.star)
  },
  star_ratings: function (e) {
    wx.showToast({

      title: '感谢您的评价',

    })
    var Star_ID = wx.getStorageSync('Star_ID') ;
    console.log(Star_ID)
    var star=this.data.star;
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "update", //指定操作是update
        collection: "extra_need", //指定操作的集合
        _id: Star_ID,
        data: { //指定update的数据
          
          服务评分:star
        }
      },
      success: res => {
        console.log('[云函数] [updateDB] 已更改当前状态信息' + star)
      },
      fail: err => {
        console.error('[云函数] [updateDB]更改当前状态失败', err)
      }
    })
 
    wx.navigateTo({
      url: '../rider_order/rider_order',
    })
  }


})
 
// Component({
//   /**
//    * 组件的属性列表
//    */
//   properties: {

//   },

//   /**
//    * 组件的初始数据
//    */
//   data: {
//     imgs: [{
//       id: 1
//     }, {
//       id: 2
//     }, {
//       id: 3
//     }, {
//       id: 4
//     }, {
//       id: 5
//     }],
//     starId: 0,
//     src1: '../../images/Star/Yellow.png',
//     src2: '../../images/Star/white.png',
//   },
  
//   /**
//    * 组件的方法列表
//    */
//   methods: {
//     select(e) {
//       console.log(e)
//       this.data.starId = e.currentTarget.dataset.index;
//       this.setData({
//         starId: this.data.starId
//       });

//     }
//   },

// })
