// pages/order/order.js
//var util = require('../../utils/util.js');
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    hiddenmodalput_reject:true,
    hiddenmodalput_cancelAccept:true,
    hiddenmodalput_cancelReject:true,
    hiddenmodalput_compensateAccept: true,
    hiddenmodalput_compensateReject: true,
    hiddenmodalput_refundAccept: true,
    hiddenmodalput_refundReject: true,
    space: '  ',
    tabCur: 0, //默认选中
    tabs: [{
      name: '未接单',
      id: 0
    },
    {
      name: '正常进行',
      id: 1
    },
    {
      name: '已完成',
      id: 2
    },
    {
      name: '待取消',
      id: 3
    },
    {
      name: '已取消',
      id: 4
    },
    {
      name: '待赔付',
      id: 5
    },
    {
      name: '已赔付',
      id: 6
    },
    {
      name: '待退款',
      id: 7
    },
    {
      name: '已退款',
      id: 8
    },
    {
      name: '预订单',
      id: 9
    },
    {
      name: '催单',
      id: 10
    },
    {
      name: '已拒单',
      id: 11
    },
    ]

  },
  //条件筛选导航栏
  tabSelect(e) {
    console.log('点到了！', e.currentTarget.dataset.id)
    this.setData({
      tabCur: e.currentTarget.dataset.id,
      scrollLeft: (e.currentTarget.dataset.id - 2) * 200
    })
    this.onReady()
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // 页面渲染完成
    this.getDeviceInfo()
    this.orderShow()
  },

  getDeviceInfo: function () {
    let that = this
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          deviceW: res.windowWidth,
          deviceH: res.windowHeight
        })
      }
    })
  },

  /**
  * @Explain：选项卡点击切换
  */
  /*
  tabSwitch: function (e) {
    var that = this
    if (this.data.currtab === e.target.dataset.current) {
      return false
    } else {
      that.setData({
        currtab: e.target.dataset.current
      })
    }
  },
  */
  /*
   tabChange: function (e) {
     this.setData({ currtab: e.detail.current })
     this.orderShow()
   },
   */

  orderShow: function () {
    let that = this
    switch (this.data.tabCur) {
      case 0:
        that.waitPayShow()
        break
      case 1:
        that.ongoingShow()
        break
      case 2:
        that.alreadyShow()
        break
      case 3:
        that.prelostShow()
        break
      case 4:
        that.lostShow()
        break
      case 5:
        that.precompensateShow()
        break
      case 6:
        that.compensateShow()
        break
      case 7:
        that.prerefundShow()
        break
      case 8:
        that.refundShow()
        break
      case 9:
        that.futureShow()
        break
      case 10:
        that.hurryShow()
        break
      case 11:
        that.rejectShow()
        break
    }
  },


  waitPayShow: function () {
    var _store = wx.getStorageSync('MyStore');
    var orderInfo = _store._id;
    console.log(orderInfo)

    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          接单商家id: orderInfo,
          订单状态: '未接单'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          //delete res.result.data[i].date_order
          //delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
        }
        console.log('调试', res.result.data);

        var arr=res.result.data;
        var max=arr.length-1;
//下面这一堆是时间排序
        for (var j = 0; j < max; j++) {
            var done = true;//标志位变量
            for (var i = 0; i < max - j; i++) {
              //这里我们给时间赋权重，hour*60，min*1
              //日赋权10000,月赋权10000*100，年赋权10000*10000
              //arr[i].time_order是"21:59"
              //arr[i].date_order是"2020-03-04"
              //这段代码保证了时间靠前的订单会先被显示
              var comparei = (((arr[i].time_order[0] + arr[i].time_order[1]) % 10000) * 60 + ((arr[i].time_order[3] + arr[i].time_order[4]) % 10000) + ((arr[i].date_order[8] + arr[i].date_order[9]) % 10000) * 10000 + ((arr[i].date_order[5] + arr[i].date_order[6]) % 10000) * 10000 * 100 + ((arr[i].date_order[0] + arr[i].date_order[1] + arr[i].date_order[2] + arr[i].date_order[3]) % 10000) * 10000 * 10000);
              var comparei1 = (((arr[i + 1].time_order[0] + arr[i + 1].time_order[1]) % 10000) * 60 + ((arr[i + 1].time_order[3] + arr[i + 1].time_order[4]) % 10000) + ((arr[i + 1].date_order[8] + arr[i + 1].date_order[9]) % 10000) * 10000 + ((arr[i + 1].date_order[5] + arr[i + 1].date_order[6]) % 10000) * 10000 * 100 + ((arr[i + 1].date_order[0] + arr[i + 1].date_order[1] + arr[i + 1].date_order[2] + arr[i + 1].date_order[3]) % 10000) * 10000 * 10000)
              /*
              console.log('不等号左边', comparei);
              console.log('不等号右边', comparei1);
              */
              if (comparei > comparei1) {
                var temp = arr[i];
                arr[i] = arr[i + 1];
                arr[i + 1] = temp;
                done = false;
              }
            }
            if (done) {
              break;
            }
          }
          console.log('ARR',arr)

          this.setData({
            ne1: arr,
          })
      }
    })
  },


  ongoingShow: function () {
    var _store = wx.getStorageSync('MyStore');
    var orderInfo = _store._id;
    console.log(orderInfo)

    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          接单商家id: orderInfo,
          订单状态: '正常进行'
        }
      },
      complete: res => {
        console.log('正常进行订单信息', res)
        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          //delete res.result.data[i].date_order
          //delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
          if (res.result.data[i].拒绝取消原因==undefined)
          {
            res.result.data[i].cancelRejectReason='!@#'
          }
          else if (res.result.data[i].拒绝取消原因 != undefined)
          {
            res.result.data[i].cancelRejectReason = res.result.data[i].拒绝取消原因
            delete res.result.data[i].拒绝取消原因
          }

        }
        console.log('调试', res.result.data);
        var arr = res.result.data;
        var max = arr.length - 1;
        //下面这一堆是时间排序
        for (var j = 0; j < max; j++) {
          var done = true;//标志位变量
          for (var i = 0; i < max - j; i++) {
            //这里我们给时间赋权重，hour*60，min*1
            //日赋权10000,月赋权10000*100，年赋权10000*10000
            //arr[i].time_order是"21:59"
            //arr[i].date_order是"2020-03-04"
            //这段代码保证了时间靠前的订单会先被显示
            var comparei = (((arr[i].time_order[0] + arr[i].time_order[1]) % 10000) * 60 + ((arr[i].time_order[3] + arr[i].time_order[4]) % 10000) + ((arr[i].date_order[8] + arr[i].date_order[9]) % 10000) * 10000 + ((arr[i].date_order[5] + arr[i].date_order[6]) % 10000) * 10000 * 100 + ((arr[i].date_order[0] + arr[i].date_order[1] + arr[i].date_order[2] + arr[i].date_order[3]) % 10000) * 10000 * 10000);
            var comparei1 = (((arr[i + 1].time_order[0] + arr[i + 1].time_order[1]) % 10000) * 60 + ((arr[i + 1].time_order[3] + arr[i + 1].time_order[4]) % 10000) + ((arr[i + 1].date_order[8] + arr[i + 1].date_order[9]) % 10000) * 10000 + ((arr[i + 1].date_order[5] + arr[i + 1].date_order[6]) % 10000) * 10000 * 100 + ((arr[i + 1].date_order[0] + arr[i + 1].date_order[1] + arr[i + 1].date_order[2] + arr[i + 1].date_order[3]) % 10000) * 10000 * 10000)
            /*
            console.log('不等号左边', comparei);
            console.log('不等号右边', comparei1);
            */
            if (comparei > comparei1) {
              var temp = arr[i];
              arr[i] = arr[i + 1];
              arr[i + 1] = temp;
              done = false;
            }
          }
          if (done) {
            break;
          }
        }

          this.setData({
            ne2: arr,
          })
      }
    })
  },

  //已完成
  alreadyShow: function () {
    var _store = wx.getStorageSync('MyStore');
    var orderInfo = _store._id;
    console.log(orderInfo)

    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          接单商家id: orderInfo,
          订单状态: '已完成'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          //delete res.result.data[i].date_order
          //delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
          if (res.result.data[i].拒绝赔付原因 == undefined) {
            res.result.data[i].compensateRejectReason = '!@#'
          }
          else if (res.result.data[i].拒绝赔付原因 != undefined) {
            res.result.data[i].compensateRejectReason = res.result.data[i].拒绝赔付原因
            delete res.result.data[i].拒绝赔付原因
          }
          if (res.result.data[i].拒绝退款原因 == undefined) {
            res.result.data[i].refundRejectReason = '!@#'
          }
          else if (res.result.data[i].拒绝退款原因 != undefined) {
            res.result.data[i].refundRejectReason = res.result.data[i].拒绝退款原因
            delete res.result.data[i].拒绝退款原因
          }
          
        }
        console.log('调试', res.result.data);
        
        //下面这一堆是时间排序
        var arr = res.result.data;
        var max = arr.length - 1;
        for (var j = 0; j < max; j++) {
          var done = true;//标志位变量
          for (var i = 0; i < max - j; i++) {
            //这里我们给时间赋权重，hour*60，min*1
            //日赋权10000,月赋权10000*100，年赋权10000*10000
            //arr[i].time_order是"21:59"
            //arr[i].date_order是"2020-03-04"
            //这段代码保证了时间靠前的订单会先被显示
            var comparei = (((arr[i].time_order[0] + arr[i].time_order[1]) % 10000) * 60 + ((arr[i].time_order[3] + arr[i].time_order[4]) % 10000) + ((arr[i].date_order[8] + arr[i].date_order[9]) % 10000) * 10000 + ((arr[i].date_order[5] + arr[i].date_order[6]) % 10000) * 10000 * 100 + ((arr[i].date_order[0] + arr[i].date_order[1] + arr[i].date_order[2] + arr[i].date_order[3]) % 10000) * 10000 * 10000);
            var comparei1 = (((arr[i + 1].time_order[0] + arr[i + 1].time_order[1]) % 10000) * 60 + ((arr[i + 1].time_order[3] + arr[i + 1].time_order[4]) % 10000) + ((arr[i + 1].date_order[8] + arr[i + 1].date_order[9]) % 10000) * 10000 + ((arr[i + 1].date_order[5] + arr[i + 1].date_order[6]) % 10000) * 10000 * 100 + ((arr[i + 1].date_order[0] + arr[i + 1].date_order[1] + arr[i + 1].date_order[2] + arr[i + 1].date_order[3]) % 10000) * 10000 * 10000)
            /*
            console.log('不等号左边', comparei);
            console.log('不等号右边', comparei1);
            */
            if (comparei < comparei1) {
              var temp = arr[i];
              arr[i] = arr[i + 1];
              arr[i + 1] = temp;
              done = false;
            }
          }
          if (done) {
            break;
          }
        }
          this.setData({
            ne3: arr,
          })
      }
    })
  },


  //待取消
  prelostShow: function () {
    var _store = wx.getStorageSync('MyStore');
    var orderInfo = _store._id;
    console.log(orderInfo)

    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          接单商家id: orderInfo,
          订单状态: '待取消'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          //delete res.result.data[i].date_order
          //delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
          res.result.data[i].cancelReason = res.result.data[i].申请取消原因
          delete res.result.data[i].申请取消原因
        }
        console.log('调试', res.result.data);
//下面这一堆是时间排序
        var arr = res.result.data;
        var max = arr.length - 1;
        for (var j = 0; j < max; j++) {
          var done = true;//标志位变量
          for (var i = 0; i < max - j; i++) {
            //这里我们给时间赋权重，hour*60，min*1
            //日赋权10000,月赋权10000*100，年赋权10000*10000
            //arr[i].time_order是"21:59"
            //arr[i].date_order是"2020-03-04"
            //这段代码保证了时间靠前的订单会先被显示
            var comparei = (((arr[i].time_order[0] + arr[i].time_order[1]) % 10000) * 60 + ((arr[i].time_order[3] + arr[i].time_order[4]) % 10000) + ((arr[i].date_order[8] + arr[i].date_order[9]) % 10000) * 10000 + ((arr[i].date_order[5] + arr[i].date_order[6]) % 10000) * 10000 * 100 + ((arr[i].date_order[0] + arr[i].date_order[1] + arr[i].date_order[2] + arr[i].date_order[3]) % 10000) * 10000 * 10000);
            var comparei1 = (((arr[i + 1].time_order[0] + arr[i + 1].time_order[1]) % 10000) * 60 + ((arr[i + 1].time_order[3] + arr[i + 1].time_order[4]) % 10000) + ((arr[i + 1].date_order[8] + arr[i + 1].date_order[9]) % 10000) * 10000 + ((arr[i + 1].date_order[5] + arr[i + 1].date_order[6]) % 10000) * 10000 * 100 + ((arr[i + 1].date_order[0] + arr[i + 1].date_order[1] + arr[i + 1].date_order[2] + arr[i + 1].date_order[3]) % 10000) * 10000 * 10000)
            /*
            console.log('不等号左边', comparei);
            console.log('不等号右边', comparei1);
            */
            if (comparei > comparei1) {
              var temp = arr[i];
              arr[i] = arr[i + 1];
              arr[i + 1] = temp;
              done = false;
            }
          }
          if (done) {
            break;
          }
        }
          this.setData({
            ne4: arr,
          })
      }
    })
  },

  //已取消
  lostShow: function () {
    var _store = wx.getStorageSync('MyStore');
    var orderInfo = _store._id;
    console.log(orderInfo)

    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          接单商家id: orderInfo,
          订单状态: '已取消'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          //delete res.result.data[i].date_order
          //delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
          res.result.data[i].cancelReason = res.result.data[i].申请取消原因
          delete res.result.data[i].申请取消原因
        }
        console.log('调试', res.result.data);
        //下面这一堆是时间排序
        var arr = res.result.data;
        var max = arr.length - 1;
        for (var j = 0; j < max; j++) {
          var done = true;//标志位变量
          for (var i = 0; i < max - j; i++) {
            //这里我们给时间赋权重，hour*60，min*1
            //日赋权10000,月赋权10000*100，年赋权10000*10000
            //arr[i].time_order是"21:59"
            //arr[i].date_order是"2020-03-04"
            //这段代码保证了时间靠前的订单会先被显示
            var comparei = (((arr[i].time_order[0] + arr[i].time_order[1]) % 10000) * 60 + ((arr[i].time_order[3] + arr[i].time_order[4]) % 10000) + ((arr[i].date_order[8] + arr[i].date_order[9]) % 10000) * 10000 + ((arr[i].date_order[5] + arr[i].date_order[6]) % 10000) * 10000 * 100 + ((arr[i].date_order[0] + arr[i].date_order[1] + arr[i].date_order[2] + arr[i].date_order[3]) % 10000) * 10000 * 10000);
            var comparei1 = (((arr[i + 1].time_order[0] + arr[i + 1].time_order[1]) % 10000) * 60 + ((arr[i + 1].time_order[3] + arr[i + 1].time_order[4]) % 10000) + ((arr[i + 1].date_order[8] + arr[i + 1].date_order[9]) % 10000) * 10000 + ((arr[i + 1].date_order[5] + arr[i + 1].date_order[6]) % 10000) * 10000 * 100 + ((arr[i + 1].date_order[0] + arr[i + 1].date_order[1] + arr[i + 1].date_order[2] + arr[i + 1].date_order[3]) % 10000) * 10000 * 10000)
            /*
            console.log('不等号左边', comparei);
            console.log('不等号右边', comparei1);
            */
            if (comparei < comparei1) {
              var temp = arr[i];
              arr[i] = arr[i + 1];
              arr[i + 1] = temp;
              done = false;
            }
          }
          if (done) {
            break;
          }
        }
          this.setData({
            ne5: arr,
          })
      }
    })
  },

  //待赔付
  precompensateShow: function () {
    var _store = wx.getStorageSync('MyStore');
    var orderInfo = _store._id;
    console.log(orderInfo)

    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          接单商家id: orderInfo,
          订单状态: '待赔付'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          //delete res.result.data[i].date_order
          //delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
          res.result.data[i].compensateReason = res.result.data[i].申请赔付原因
          delete res.result.data[i].申请赔付原因
        }
        console.log('调试', res.result.data);
        //下面这一堆是时间排序
        var arr = res.result.data;
        var max = arr.length - 1;
        for (var j = 0; j < max; j++) {
          var done = true;//标志位变量
          for (var i = 0; i < max - j; i++) {
            //这里我们给时间赋权重，hour*60，min*1
            //日赋权10000,月赋权10000*100，年赋权10000*10000
            //arr[i].time_order是"21:59"
            //arr[i].date_order是"2020-03-04"
            //这段代码保证了时间靠前的订单会先被显示
            var comparei = (((arr[i].time_order[0] + arr[i].time_order[1]) % 10000) * 60 + ((arr[i].time_order[3] + arr[i].time_order[4]) % 10000) + ((arr[i].date_order[8] + arr[i].date_order[9]) % 10000) * 10000 + ((arr[i].date_order[5] + arr[i].date_order[6]) % 10000) * 10000 * 100 + ((arr[i].date_order[0] + arr[i].date_order[1] + arr[i].date_order[2] + arr[i].date_order[3]) % 10000) * 10000 * 10000);
            var comparei1 = (((arr[i + 1].time_order[0] + arr[i + 1].time_order[1]) % 10000) * 60 + ((arr[i + 1].time_order[3] + arr[i + 1].time_order[4]) % 10000) + ((arr[i + 1].date_order[8] + arr[i + 1].date_order[9]) % 10000) * 10000 + ((arr[i + 1].date_order[5] + arr[i + 1].date_order[6]) % 10000) * 10000 * 100 + ((arr[i + 1].date_order[0] + arr[i + 1].date_order[1] + arr[i + 1].date_order[2] + arr[i + 1].date_order[3]) % 10000) * 10000 * 10000)
            /*
            console.log('不等号左边', comparei);
            console.log('不等号右边', comparei1);
            */
            if (comparei > comparei1) {
              var temp = arr[i];
              arr[i] = arr[i + 1];
              arr[i + 1] = temp;
              done = false;
            }
          }
          if (done) {
            break;
          }
        }
          this.setData({
            ne6: arr,
          })
      }
    })
  },

  //已赔付
  compensateShow: function () {
    var _store = wx.getStorageSync('MyStore');
    var orderInfo = _store._id;
    console.log(orderInfo)

    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          接单商家id: orderInfo,
          订单状态: '已赔付'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          //delete res.result.data[i].date_order
          //delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
          res.result.data[i].compensateReason = res.result.data[i].申请赔付原因
          delete res.result.data[i].申请赔付原因
        }
        console.log('调试', res.result.data);
        //下面这一堆是时间排序
        var arr = res.result.data;
        var max = arr.length - 1;
        for (var j = 0; j < max; j++) {
          var done = true;//标志位变量
          for (var i = 0; i < max - j; i++) {
            //这里我们给时间赋权重，hour*60，min*1
            //日赋权10000,月赋权10000*100，年赋权10000*10000
            //arr[i].time_order是"21:59"
            //arr[i].date_order是"2020-03-04"
            //这段代码保证了时间靠前的订单会先被显示
            var comparei = (((arr[i].time_order[0] + arr[i].time_order[1]) % 10000) * 60 + ((arr[i].time_order[3] + arr[i].time_order[4]) % 10000) + ((arr[i].date_order[8] + arr[i].date_order[9]) % 10000) * 10000 + ((arr[i].date_order[5] + arr[i].date_order[6]) % 10000) * 10000 * 100 + ((arr[i].date_order[0] + arr[i].date_order[1] + arr[i].date_order[2] + arr[i].date_order[3]) % 10000) * 10000 * 10000);
            var comparei1 = (((arr[i + 1].time_order[0] + arr[i + 1].time_order[1]) % 10000) * 60 + ((arr[i + 1].time_order[3] + arr[i + 1].time_order[4]) % 10000) + ((arr[i + 1].date_order[8] + arr[i + 1].date_order[9]) % 10000) * 10000 + ((arr[i + 1].date_order[5] + arr[i + 1].date_order[6]) % 10000) * 10000 * 100 + ((arr[i + 1].date_order[0] + arr[i + 1].date_order[1] + arr[i + 1].date_order[2] + arr[i + 1].date_order[3]) % 10000) * 10000 * 10000)
            /*
            console.log('不等号左边', comparei);
            console.log('不等号右边', comparei1);
            */
            if (comparei < comparei1) {
              var temp = arr[i];
              arr[i] = arr[i + 1];
              arr[i + 1] = temp;
              done = false;
            }
          }
          if (done) {
            break;
          }
        }
          this.setData({
            ne7: arr,
          })
      }
    })
  },

  //待退款
  prerefundShow: function () {
    var _store = wx.getStorageSync('MyStore');
    var orderInfo = _store._id;
    console.log(orderInfo)

    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          接单商家id: orderInfo,
          订单状态: '待退款'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          //delete res.result.data[i].date_order
          //delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
          res.result.data[i].refundReason = res.result.data[i].申请退款原因
          delete res.result.data[i].申请退款原因
        }
        console.log('调试', res.result.data);
        //下面这一堆是时间排序
        var arr = res.result.data;
        var max = arr.length - 1;
        for (var j = 0; j < max; j++) {
          var done = true;//标志位变量
          for (var i = 0; i < max - j; i++) {
            //这里我们给时间赋权重，hour*60，min*1
            //日赋权10000,月赋权10000*100，年赋权10000*10000
            //arr[i].time_order是"21:59"
            //arr[i].date_order是"2020-03-04"
            //这段代码保证了时间靠前的订单会先被显示
            var comparei = (((arr[i].time_order[0] + arr[i].time_order[1]) % 10000) * 60 + ((arr[i].time_order[3] + arr[i].time_order[4]) % 10000) + ((arr[i].date_order[8] + arr[i].date_order[9]) % 10000) * 10000 + ((arr[i].date_order[5] + arr[i].date_order[6]) % 10000) * 10000 * 100 + ((arr[i].date_order[0] + arr[i].date_order[1] + arr[i].date_order[2] + arr[i].date_order[3]) % 10000) * 10000 * 10000);
            var comparei1 = (((arr[i + 1].time_order[0] + arr[i + 1].time_order[1]) % 10000) * 60 + ((arr[i + 1].time_order[3] + arr[i + 1].time_order[4]) % 10000) + ((arr[i + 1].date_order[8] + arr[i + 1].date_order[9]) % 10000) * 10000 + ((arr[i + 1].date_order[5] + arr[i + 1].date_order[6]) % 10000) * 10000 * 100 + ((arr[i + 1].date_order[0] + arr[i + 1].date_order[1] + arr[i + 1].date_order[2] + arr[i + 1].date_order[3]) % 10000) * 10000 * 10000)
            /*
            console.log('不等号左边', comparei);
            console.log('不等号右边', comparei1);
            */
            if (comparei > comparei1) {
              var temp = arr[i];
              arr[i] = arr[i + 1];
              arr[i + 1] = temp;
              done = false;
            }
          }
          if (done) {
            break;
          }
        }
          this.setData({
            ne8: arr,
          })
      }
    })
  },

  //退款
  refundShow: function () {
    var _store = wx.getStorageSync('MyStore');
    var orderInfo = _store._id;
    console.log(orderInfo)

    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          接单商家id: orderInfo,
          订单状态: '已退款'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          //delete res.result.data[i].date_order
          //delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
          res.result.data[i].refundReason = res.result.data[i].申请退款原因
          delete res.result.data[i].申请退款原因
        }
        console.log('调试', res.result.data);
        //下面这一堆是时间排序
        var arr = res.result.data;
        var max = arr.length - 1;
        for (var j = 0; j < max; j++) {
          var done = true;//标志位变量
          for (var i = 0; i < max - j; i++) {
            //这里我们给时间赋权重，hour*60，min*1
            //日赋权10000,月赋权10000*100，年赋权10000*10000
            //arr[i].time_order是"21:59"
            //arr[i].date_order是"2020-03-04"
            //这段代码保证了时间靠前的订单会先被显示
            var comparei = (((arr[i].time_order[0] + arr[i].time_order[1]) % 10000) * 60 + ((arr[i].time_order[3] + arr[i].time_order[4]) % 10000) + ((arr[i].date_order[8] + arr[i].date_order[9]) % 10000) * 10000 + ((arr[i].date_order[5] + arr[i].date_order[6]) % 10000) * 10000 * 100 + ((arr[i].date_order[0] + arr[i].date_order[1] + arr[i].date_order[2] + arr[i].date_order[3]) % 10000) * 10000 * 10000);
            var comparei1 = (((arr[i + 1].time_order[0] + arr[i + 1].time_order[1]) % 10000) * 60 + ((arr[i + 1].time_order[3] + arr[i + 1].time_order[4]) % 10000) + ((arr[i + 1].date_order[8] + arr[i + 1].date_order[9]) % 10000) * 10000 + ((arr[i + 1].date_order[5] + arr[i + 1].date_order[6]) % 10000) * 10000 * 100 + ((arr[i + 1].date_order[0] + arr[i + 1].date_order[1] + arr[i + 1].date_order[2] + arr[i + 1].date_order[3]) % 10000) * 10000 * 10000)
            /*
            console.log('不等号左边', comparei);
            console.log('不等号右边', comparei1);
            */
            if (comparei < comparei1) {
              var temp = arr[i];
              arr[i] = arr[i + 1];
              arr[i + 1] = temp;
              done = false;
            }
          }
          if (done) {
            break;
          }
        }
          this.setData({
            ne9: arr,
          })
      }
    })
  },

  //预订单
  futureShow: function () {
    var _store = wx.getStorageSync('MyStore');
    var orderInfo = _store._id;
    console.log(orderInfo)

    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          接单商家id: orderInfo,
          订单状态: '预订单'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          //delete res.result.data[i].date_order
          //delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
        }
        console.log('调试', res.result.data);
        //下面这一堆是时间排序
        var arr = res.result.data;
        var max = arr.length - 1;
        for (var j = 0; j < max; j++) {
          var done = true;//标志位变量
          for (var i = 0; i < max - j; i++) {
            //这里我们给时间赋权重，hour*60，min*1
            //日赋权10000,月赋权10000*100，年赋权10000*10000
            //arr[i].time_order是"21:59"
            //arr[i].date_order是"2020-03-04"
            //这段代码保证了时间靠前的订单会先被显示
            var comparei = (((arr[i].time_order[0] + arr[i].time_order[1]) % 10000) * 60 + ((arr[i].time_order[3] + arr[i].time_order[4]) % 10000) + ((arr[i].date_order[8] + arr[i].date_order[9]) % 10000) * 10000 + ((arr[i].date_order[5] + arr[i].date_order[6]) % 10000) * 10000 * 100 + ((arr[i].date_order[0] + arr[i].date_order[1] + arr[i].date_order[2] + arr[i].date_order[3]) % 10000) * 10000 * 10000);
            var comparei1 = (((arr[i + 1].time_order[0] + arr[i + 1].time_order[1]) % 10000) * 60 + ((arr[i + 1].time_order[3] + arr[i + 1].time_order[4]) % 10000) + ((arr[i + 1].date_order[8] + arr[i + 1].date_order[9]) % 10000) * 10000 + ((arr[i + 1].date_order[5] + arr[i + 1].date_order[6]) % 10000) * 10000 * 100 + ((arr[i + 1].date_order[0] + arr[i + 1].date_order[1] + arr[i + 1].date_order[2] + arr[i + 1].date_order[3]) % 10000) * 10000 * 10000)
            /*
            console.log('不等号左边', comparei);
            console.log('不等号右边', comparei1);
            */
            if (comparei > comparei1) {
              var temp = arr[i];
              arr[i] = arr[i + 1];
              arr[i + 1] = temp;
              done = false;
            }
          }
          if (done) {
            break;
          }
        }
          this.setData({
            ne10: arr,
          })
      }
    })
  },


  //催单
  hurryShow: function () {
    var _store = wx.getStorageSync('MyStore');
    var orderInfo = _store._id;
    console.log(orderInfo)

    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          接单商家id: orderInfo,
          订单状态: '催单'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          //delete res.result.data[i].date_order
          //delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
        }
        console.log('调试', res.result.data);
        //下面这一堆是时间排序
        var arr = res.result.data;
        var max = arr.length - 1;
        for (var j = 0; j < max; j++) {
          var done = true;//标志位变量
          for (var i = 0; i < max - j; i++) {
            //这里我们给时间赋权重，hour*60，min*1
            //日赋权10000,月赋权10000*100，年赋权10000*10000
            //arr[i].time_order是"21:59"
            //arr[i].date_order是"2020-03-04"
            //这段代码保证了时间靠前的订单会先被显示
            var comparei = (((arr[i].time_order[0] + arr[i].time_order[1]) % 10000) * 60 + ((arr[i].time_order[3] + arr[i].time_order[4]) % 10000) + ((arr[i].date_order[8] + arr[i].date_order[9]) % 10000) * 10000 + ((arr[i].date_order[5] + arr[i].date_order[6]) % 10000) * 10000 * 100 + ((arr[i].date_order[0] + arr[i].date_order[1] + arr[i].date_order[2] + arr[i].date_order[3]) % 10000) * 10000 * 10000);
            var comparei1 = (((arr[i + 1].time_order[0] + arr[i + 1].time_order[1]) % 10000) * 60 + ((arr[i + 1].time_order[3] + arr[i + 1].time_order[4]) % 10000) + ((arr[i + 1].date_order[8] + arr[i + 1].date_order[9]) % 10000) * 10000 + ((arr[i + 1].date_order[5] + arr[i + 1].date_order[6]) % 10000) * 10000 * 100 + ((arr[i + 1].date_order[0] + arr[i + 1].date_order[1] + arr[i + 1].date_order[2] + arr[i + 1].date_order[3]) % 10000) * 10000 * 10000)
            /*
            console.log('不等号左边', comparei);
            console.log('不等号右边', comparei1);
            */
            if (comparei > comparei1) {
              var temp = arr[i];
              arr[i] = arr[i + 1];
              arr[i + 1] = temp;
              done = false;
            }
          }
          if (done) {
            break;
          }
        }
          this.setData({
            ne11: arr,
          })
      }
    })
  },



  //拒单
  rejectShow: function () {
    var _store = wx.getStorageSync('MyStore');
    var orderInfo = _store._id;
    console.log(orderInfo)

    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  查找
        collection: "order", //指定操作的集合
        condition: { //指定where查找的要求字段
          接单商家id: orderInfo,
          订单状态: '已拒单'
        }
      },
      complete: res => {

        for (var i = 0; i < res.result.data.length; i++) {
          res.result.data[i].money = res.result.data[i].应付金额_元
          delete res.result.data[i].应付金额_元
          res.result.data[i].time = res.result.data[i].date_order + '  ' + res.result.data[i].time_order
          //delete res.result.data[i].date_order
          //delete res.result.data[i].time_order
          res.result.data[i].state = res.result.data[i].订单状态
          delete res.result.data[i].订单状态
          res.result.data[i].name = res.result.data[i].store_name
          delete res.result.data[i].store_name
          res.result.data[i].url = res.result.data[i].store_icon_url
          delete res.result.data[i].store_icon_url
          res.result.data[i].goods = res.result.data[i].goodsList
          delete res.result.data[i].goodsList
          res.result.data[i].rejectReason = res.result.data[i].拒单原因
          delete res.result.data[i].拒单原因
        }
        console.log('调试', res.result.data);
        //下面这一堆是时间排序
        var arr = res.result.data;
        var max = arr.length - 1;
        for (var j = 0; j < max; j++) {
          var done = true;//标志位变量
          for (var i = 0; i < max - j; i++) {
            //这里我们给时间赋权重，hour*60，min*1
            //日赋权10000,月赋权10000*100，年赋权10000*10000
            //arr[i].time_order是"21:59"
            //arr[i].date_order是"2020-03-04"
            //这段代码保证了时间靠前的订单会先被显示
            var comparei = (((arr[i].time_order[0] + arr[i].time_order[1]) % 10000) * 60 + ((arr[i].time_order[3] + arr[i].time_order[4]) % 10000) + ((arr[i].date_order[8] + arr[i].date_order[9]) % 10000) * 10000 + ((arr[i].date_order[5] + arr[i].date_order[6]) % 10000) * 10000 * 100 + ((arr[i].date_order[0] + arr[i].date_order[1] + arr[i].date_order[2] + arr[i].date_order[3]) % 10000) * 10000 * 10000);
            var comparei1 = (((arr[i + 1].time_order[0] + arr[i + 1].time_order[1]) % 10000) * 60 + ((arr[i + 1].time_order[3] + arr[i + 1].time_order[4]) % 10000) + ((arr[i + 1].date_order[8] + arr[i + 1].date_order[9]) % 10000) * 10000 + ((arr[i + 1].date_order[5] + arr[i + 1].date_order[6]) % 10000) * 10000 * 100 + ((arr[i + 1].date_order[0] + arr[i + 1].date_order[1] + arr[i + 1].date_order[2] + arr[i + 1].date_order[3]) % 10000) * 10000 * 10000)
            /*
            console.log('不等号左边', comparei);
            console.log('不等号右边', comparei1);
            */
            if (comparei > comparei1) {
              var temp = arr[i];
              arr[i] = arr[i + 1];
              arr[i + 1] = temp;
              done = false;
            }
          }
          if (done) {
            break;
          }
        }
        this.setData({
          ne12: arr,
        })
      }
    })
  },





  //正常进行订单ne2
  /*****拒单的几个函数******/
  rejectOG: function (e) {
    var index = e.currentTarget.dataset.index;
    this.setData({
      hiddenmodalput_reject: !this.data.hiddenmodalput_reject,
      rejectIndex: index,
    })
  },

  cancel_reject: function () {
    this.setData({
      hiddenmodalput_reject: true,
    });
  },

  confirm_reject: function () {
    var that = this;
    var index = this.data.rejectIndex;
    let ongoingOrders = that.data.ne1;
    var _id = ongoingOrders[index]._id;
    var storeid = wx.getStorageSync('id');
    var rejectNum;
    console.log('IDDDDDD', _id)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "update",
        collection: "order",
        _id: _id,
        data: {
          订单状态: '已拒单',
          拒单原因: that.data.rejectReason,
        }
      },
      success: res => {
        console.log('成功了！');
        
        wx.cloud.callFunction({
          name: 'runDB',
          data: {
            type: "get",
            collection: "store",
            condition:{
              _id: storeid,
            },
          },
          success: res => {
            console.log('拒单次数1223123',res.result.data[0]);
            rejectNum = res.result.data[0].拒单次数;
            rejectNum+=1;
            wx.cloud.callFunction({
              name: 'runDB',
              data:{
                type:"update",
                collection:"store",
                _id:storeid,
                data:{
                  拒单次数:rejectNum,
                }
              },
              success:res=>{
                console.log('三层嵌套大功告成')
              }
            })
          }
        })
      }
    })

    /*
    var MyStore = wx.getStorageSync('MyStore');
    MyStore.拒单次数 += 1;
    console.log(MyStore.拒单次数);
    wx.setStorageSync('MyStore', MyStore);
    */
    this.setData({
      hiddenmodalput_reject: true
    })


    that.onReady()
  },



  inputRejectReason: function (e) {
    console.log(e.detail.value)
    var reason = e.detail.value
    this.setData({
      rejectReason: reason,
    })
  },




  /**********接单***********/
  acceptOG: function (e) {
    var that = this;
    var index = e.currentTarget.dataset.index;
    console.log('IDX', index);
    let ongoingOrders = that.data.ne1;
    var _id = ongoingOrders[index]._id;
    console.log('IDDDD',_id)
    var whether;
    wx.showModal({
      title: "接单",
      content: "确定要接单吗？",
      showCancel: true,
      cancelText: "取消",
      cancelColor: "#000",
      confirmText: "确定",
      confirmColor: "#0a0",
      success: function (res) {
        console.log(res)
        if (res.confirm) {
          wx.cloud.callFunction({
            name: 'runDB',
            data: {
              type: "get",
              collection: "order",
              condition:{
                _id: _id,
              }
            },
            success: res => {
              console.log(res.result.data[0]);
              whether=res.result.data[0].是否预订单
              console.log('WHE', whether);
              if (whether == false) {
                wx.cloud.callFunction({
                  name: 'runDB',
                  data: {
                    type: "update",
                    collection: "order",
                    _id: _id,
                    data: {
                      订单状态: '正常进行',
                    }
                  },
                  success: res => {
                    console.log('正常进行接单成功了！');
                    that.onReady()
                  }
                })
              }
              else if (whether == true) {
                wx.cloud.callFunction({
                  name: 'runDB',
                  data: {
                    type: "update",
                    collection: "order",
                    _id: _id,
                    data: {
                      订单状态: '预订单',
                    }
                  },
                  success: res => {
                    console.log('预订单接单成功了！');
                    that.onReady()
                  }
                })
              }
            }
          })

          
        }
      }
    })
  },



  //待取消ne4
  /*******以下几个是拒绝取消函数**********/
  cancelRejectOG: function (e) {
    var index = e.currentTarget.dataset.index;
    this.setData({
      hiddenmodalput_cancelReject: !this.data.hiddenmodalput_cancelReject,
      cancelRejectIndex: index,
    })
  },

  cancel_cancelReject: function () {
    this.setData({
      hiddenmodalput_cancelReject: true
    });
  },

  confirm_cancelReject: function () {
    var that = this;
    var index = this.data.cancelRejectIndex;
    let ongoingOrders = that.data.ne4;
    var _id = ongoingOrders[index]._id;
    console.log('IDDDDDD', _id)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "update",
        collection: "order",
        _id: _id,
        data: {
          订单状态: '正常进行',
          拒绝取消原因: that.data.cancelRejectReason,
        }
      },
      success: res => {
        console.log('成功了！');
      }
    })
    this.setData({
      hiddenmodalput_cancelReject: true
    })
    that.onReady()
  },

  inputCancelRejectReason: function (e) {
    console.log(e.detail.value)
    var reason = e.detail.value
    this.setData({
      cancelRejectReason: reason,
    })
  },
  /*****接受取消**********/
  cancelAcceptOG: function (e) {
    var index = e.currentTarget.dataset.index;
    this.setData({
      hiddenmodalput_cancelAccept: !this.data.hiddenmodalput_cancelAccept,
      cancelAcceptIndex: index,
    })
  },

  cancel_cancelAccept: function () {
    this.setData({
      hiddenmodalput_cancelAccept: true
    });
  },

  confirm_cancelAccept: function () {
    var that = this;
    var index = this.data.cancelAcceptIndex;
    let ongoingOrders = that.data.ne4;
    var _id = ongoingOrders[index]._id;
    console.log('IDDDDDD', _id)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "update",
        collection: "order",
        _id: _id,
        data: {
          订单状态: '已取消',
        }
      },
      success: res => {
        console.log('成功了！');
      }
    })
    this.setData({
      hiddenmodalput_cancelAccept: true
    })
    that.onReady()
  },


  //待赔付ne6
  /*******以下几个是拒绝赔付函数**********/
  compensateRejectOG: function (e) {
    var index = e.currentTarget.dataset.index;
    this.setData({
      hiddenmodalput_compensateReject: !this.data.hiddenmodalput_compensateReject,
      compensateRejectIndex: index,
    })
  },

  cancel_compensateReject: function () {
    this.setData({
      hiddenmodalput_compensateReject: true
    });
  },

  confirm_compensateReject: function () {
    var that = this;
    var index = this.data.compensateRejectIndex;
    let ongoingOrders = that.data.ne6;
    var _id = ongoingOrders[index]._id;
    console.log('IDDDDDD', _id)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "update",
        collection: "order",
        _id: _id,
        data: {
          订单状态: '已完成',
          拒绝赔付原因: that.data.compensateRejectReason,
        }
      },
      success: res => {
        console.log('成功了！');
      }
    })
    this.setData({
      hiddenmodalput_compensateReject: true
    })
    that.onReady()
  },

  inputCompensateRejectReason: function (e) {
    console.log(e.detail.value)
    var reason = e.detail.value
    this.setData({
      compensateRejectReason: reason,
    })
  },
  /*****接受赔付**********/
  compensateAcceptOG: function (e) {
    var index = e.currentTarget.dataset.index;
    this.setData({
      hiddenmodalput_compensateAccept: !this.data.hiddenmodalput_compensateAccept,
      compensateAcceptIndex: index,
    })
  },

  cancel_compensateAccept: function () {
    this.setData({
      hiddenmodalput_compensateAccept: true
    });
  },

  confirm_compensateAccept: function () {
    var that = this;
    var index = this.data.compensateAcceptIndex;
    let ongoingOrders = that.data.ne6;
    var _id = ongoingOrders[index]._id;
    console.log('IDDDDDD', _id)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "update",
        collection: "order",
        _id: _id,
        data: {
          订单状态: '已赔付',
        }
      },
      success: res => {
        console.log('成功了！');
      }
    })
    this.setData({
      hiddenmodalput_compensateAccept: true
    })
    that.onReady()
  },


  //待退款ne8
  /*******以下几个是拒绝退款函数**********/
  refundRejectOG: function (e) {
    var index = e.currentTarget.dataset.index;
    this.setData({
      hiddenmodalput_refundReject: !this.data.hiddenmodalput_refundReject,
      refundRejectIndex: index,
    })
  },

  cancel_refundReject: function () {
    this.setData({
      hiddenmodalput_refundReject: true
    });
  },

  confirm_refundReject: function () {
    var that = this;
    var index = this.data.refundRejectIndex;
    let ongoingOrders = that.data.ne8;
    var _id = ongoingOrders[index]._id;
    console.log('IDDDDDD', _id)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "update",
        collection: "order",
        _id: _id,
        data: {
          订单状态: '已完成',
          拒绝退款原因: that.data.refundRejectReason,
        }
      },
      success: res => {
        console.log('成功了！');
      }
    })
    this.setData({
      hiddenmodalput_refundReject: true
    })
    that.onReady()
  },

  inputRefundRejectReason: function (e) {
    console.log(e.detail.value)
    var reason = e.detail.value
    this.setData({
      refundRejectReason: reason,
    })
  },
  /*****接受退款**********/
  refundAcceptOG: function (e) {
    var index = e.currentTarget.dataset.index;
    this.setData({
      hiddenmodalput_refundAccept: !this.data.hiddenmodalput_refundAccept,
      refundAcceptIndex: index,
    })
  },

  cancel_refundAccept: function () {
    this.setData({
      hiddenmodalput_refundAccept: true
    });
  },

  confirm_refundAccept: function () {
    var that = this;
    var index = this.data.refundAcceptIndex;
    let ongoingOrders = that.data.ne8;
    var _id = ongoingOrders[index]._id;
    console.log('IDDDDDD', _id)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "update",
        collection: "order",
        _id: _id,
        data: {
          订单状态: '已退款',
        }
      },
      success: res => {
        console.log('成功了！');
      }
    })
    this.setData({
      hiddenmodalput_refundAccept: true
    })
    that.onReady()
  },

  
})