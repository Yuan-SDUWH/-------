// pages/addFunction/addFunction.js

// const _ = db.command
// db.collection('todos')


var util = require('../../utils/util.js');
const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`
Page({
  data: {
    time: '',
    today: '',
    showOrder_today:[],
    today_year: '',
    today_month: '',
    today_day: '',
    todaydate: '',
    arryseven: [],
    showOrder1: [],
    showOrder2: [],
    showOrder3: [],
    showOrder4: [],
    showOrder5: [],
    showOrder6: [],
    showOrder7:[],
  },
  getToday: function () {
    var timestamp = Date.parse(new Date());
    var date = new Date(timestamp);
    //获取年份  
    var Y = date.getFullYear();
    //获取月份  
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    //获取当日日期 
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    // console.log("_" + Y + '_' + M + '_' + D);
    var todaydate = "_" + Y + '_' + M + '_' + D;
    var today = this;
    today.setData({
      today_year: Y,
      today_month: M,
      today_day: D,
      todaydate: todaydate,
    });
  },
  onLoad: function () {
    this.getToday();
    this.GetSevenday();    
    var _customer = wx.getStorageSync('customer');
    var userid = _customer.stu_ID;
    var me = this;
    var time;
    var today_day = me.data.today_day;
    var today_month = me.data.today_month;
    var i=0;
    var arryseven=me.data.arryseven;

 //第一天
    time = arryseven[0];
    console.log('第一天为',time)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "extra_need", //指定操作的集合
        condition: { //指定where查找的要求字段
          rider_ID: userid,
          time_to_date: time       
        }
      },
      success: res => {
        this.setData({
          showOrder1: res.result.data
        });
      console.log("第一天",res.result.data)
      }
    })
//     //第二天
    time = arryseven[1];
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "extra_need", //指定操作的集合
        condition: { //指定where查找的要求字段
          rider_ID: userid,
          time_to_date: time
        }
      },
      success: res => {
        this.setData({
          showOrder2: res.result.data
        });
        console.log("第2天", res.result.data)
      }
    })
//     //第三天
    time = arryseven[2];
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "extra_need", //指定操作的集合
        condition: { //指定where查找的要求字段
          rider_ID: userid,
          time_to_date: time
        }
      },
      success: res => {
        this.setData({
          showOrder3: res.result.data
        });
        console.log("第3天", res.result.data)
      }
    })
//     //第四天
    time = arryseven[3];
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "extra_need", //指定操作的集合
        condition: { //指定where查找的要求字段
          rider_ID: userid,
          time_to_date: time
        }
      },
      success: res => {
        this.setData({
          showOrder4: res.result.data
        });
        console.log("第4天", res.result.data)
      }
    })
//     //第五天
    time = arryseven[4];

    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "extra_need", //指定操作的集合
        condition: { //指定where查找的要求字段
          rider_ID: userid,
          time_to_date: time
        }
      },
      success: res => {
        this.setData({
          showOrder5: res.result.data
        });
        console.log("第5天", res.result.data)
      }
    })
    //     //第6天
    time = arryseven[5];

    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "extra_need", //指定操作的集合
        condition: { //指定where查找的要求字段
          rider_ID: userid,
          time_to_date: time
        }
      },
      success: res => {
        this.setData({
          showOrder6: res.result.data
        });
        console.log("第6天", res.result.data)
      }
    })
    //     //第7天
    time = arryseven[6];
  
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "extra_need", //指定操作的集合
        condition: { //指定where查找的要求字段
          rider_ID: userid,
          time_to_date: time
        }
      },
      success: res => {
        this.setData({
          showOrder7: res.result.data
        });
        console.log("第7天", res.result.data)
      }
    })



  },

//获取近7日日期
  GetSevenday: function () {
    //获取今日月份和日期
    var today_year = this.data.today_year;
    var today_month = this.data.today_month;
    var today_day = this.data.today_day;
    var arryseven = [];
    //对日期判断
    if (today_day > 7) {
      var last_seven_day = today_day - 8;
      var day;
      var i;
      //获取近7日的完整年、月、日 存入数组arryseven
      //判断日是否为2位数，是：直接用；否：字符串拼接
      for (i = 0; i < 7; i++) {
        last_seven_day = last_seven_day + 1;
        if (last_seven_day < 10) {
          day = '_' + today_year + '_' + today_month + '_' + '0' + last_seven_day;
          arryseven[i] = day;
        }
        else {
          day = '_' + today_year + '_' + today_month + '_' + last_seven_day;
          arryseven[i] = day;
        }
      }
    }
    //today_day<=7时，即过去7天有日期在上个月
    else {
      console.log('today_day<=7')
      //计算在上个月的天数  lastmonth_day
      var lastmonth_day = 7 - today_day + 1;
      //上个月为31天的月份：
      if ((today_month == '02') || (today_month == '04') || (today_month == '06') || (today_month == '08') || (today_month == '09') || (today_month == '11') || (today_month == '01')) {
        //计算上个月份
        console.log('月份或条件没问题')
        var last_month;
        if (today_month == '01') {
          last_month = 12;
        }
        else if ((today_month == '02') || (today_month == '04') || (today_month == '06') || (today_month == '08') || (today_month == '09')) {
          last_month = today_month - 1;
          last_month = '0' + last_month;
        }
        else {
          last_month = today_month - 1;
        }
        console.log('lastmonth_day', lastmonth_day);
        //计算在上个月的那些日期
        //在上个月的第一天为30-lastmonth_day+1;
        var m = lastmonth_day;
        for (i = 0; i < m; i++) {
          lastmonth_day = 31 - m + 1 + i;
          day = '_' + today_year + '_' + last_month + '_' + lastmonth_day;
          arryseven[i] = day;
          console.log('本次循环的i为', i)
          console.log('本次循环的lastmonth_day为', lastmonth_day)
        };
        //将本月的几天的日期存入arryseven数组的后面  存的下标为i到6，共存了（6-i+1）天;对应的日期为
        var todaymonth_day = 6 - i + 1;//7天在本月的天数
        console.log('i', i)
        console.log('在本月的天数为', todaymonth_day)
        var j = 1;;
        for (i; i < 7; i++) {
          console.log('添加本月的几天日期')
          day = '_' + today_year + '_' + today_month + '_' + '0' + j;
          arryseven[i] = day;
          j++;
        }
      }
      //上个月为30天的月份
      else if ((today_month == '05') || (today_month == '07') || (today_month == '10') || (today_month == '12')) {
        //计算上个月份
        console.log('月份或条件没问题')
        var last_month;//计算上个月
        if ((today_month == '05') || (today_month == '07') || (today_month == '10')) {
          last_month = today_month - 1;
          last_month = '0' + last_month;
        }
        else {
          last_month = today_month - 1;
        }
        console.log('lastmonth_day', lastmonth_day)
        //计算在上个月的那些日期
        //在上个月的第一天为31-lastmonth_day+1;
        var m = lastmonth_day;
        for (i = 0; i < m; i++) {
          lastmonth_day = 30 - m + 1 + i;
          day = '_' + today_year + '_' + last_month + '_' + lastmonth_day;
          arryseven[i] = day;
          console.log('本次循环的i为', i)
          console.log('本次循环的lastmonth_day为', lastmonth_day)
        };
        //将本月的几天的日期存入arryseven数组的后面  存的下标为i到6，共存了（6-i+1）天;对应的日期为
        var todaymonth_day = 6 - i + 1;//7天在本月的天数
        console.log('i', i)
        console.log('在本月的天数为', todaymonth_day)
        var j = 1;;
        for (i; i < 7; i++) {
          console.log('添加本月的几天日期')
          day = '_' + today_year + '_' + today_month + '_' + '0' + j;
          arryseven[i] = day;
          j++;
        }
      }
      //上个月是2月份
      else {
        //计算上个月份
        console.log('上个月是2月份')
        var last_month;//计算上个月
        last_month = '02';
        console.log('lastmonth_day', lastmonth_day)
        //计算在上个月的那些日期
        //在上个月的第一天为29-lastmonth_day+1;
        var m = lastmonth_day;
        for (i = 0; i < m; i++) {
          if (((today_year % 4 == 0) && (today_year % 100 == !0)) || (today_year % 400 == 0)) {
            lastmonth_day = 29 - m + 1 + i;
          }
          else {
            lastmonth_day = 28 - m + 1 + i;
          }
          day = '_' + today_year + '_' + last_month + '_' + lastmonth_day;
          arryseven[i] = day;
          console.log('本次循环的i为', i)
          console.log('本次循环的lastmonth_day为', lastmonth_day)
        };
        //将本月的几天的日期存入arryseven数组的后面  存的下标为i到6，共存了（6-i+1）天;对应的日期为
        var todaymonth_day = 6 - i + 1;//7天在本月的天数
        console.log('i', i)
        console.log('在本月的天数为', todaymonth_day)
        var j = 1;;
        for (i; i < 7; i++) {
          console.log('添加本月的几天日期')
          day = '_' + today_year + '_' + today_month + '_' + '0' + j;
          arryseven[i] = day;
          j++;
        }
      }


    }
    this.setData({
      arryseven: arryseven
    });
     console.log(this.data.arryseven)
  },

  onShow() {

    // this.setData({
    //   currentTab: 0
    // })

  },
});

