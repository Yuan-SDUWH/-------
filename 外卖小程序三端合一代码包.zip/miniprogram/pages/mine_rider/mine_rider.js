const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`
Page({
  data: {
    ne: [],
    isSignin_rider: false,
    _id:'',
    myInfo:'',
    my_icon_url:''
  },
  onLoad: function (options) { 
    var that = this
    wx.getStorage({
      key: 'rider',
      success: function (res) {
        that.setData({
          _id: res.data._id
        })
        console.log('onload获取的id为', that.data._id)
        that.Get_icon();
      }
    })
  },
  onShow: function () {
    var _isSignin = wx.getStorageSync('isSignin_rider');
    this.setData({
      isSignin_rider: _isSignin
    })

    var _customer = wx.getStorageSync('customer');
    let target = _customer.stu_ID

    console.log('tar',target)
    if(typeof(target) == "undefined"){
      console.log('undefined')
      this.setData({
        isSignin_rider:false
      })
    } else {
      db.collection('customer').where({
        // _openid: this.data.orderInfo
        stu_ID: target
      })
        .get({
          success: res => {
            console.log(res.data)
            for (var i = 0; i < res.data.length; i++) {
              res.data[i].grade = res.data[i].年级
              delete res.data[i].年级
              res.data[i].college = res.data[i].学院
              delete res.data[i].学院
            }
            this.setData({
              ne: res.data,
            })
          }
        })
      }

      var _customer = wx.getStorageSync('customer');
      var target0 = _customer.stu_ID
  
        console.log('tar',target0)

        db.collection('rider').where({
          stu_ID:target0
      })
        .get({
          success: res => {
            console.log('chenggong',res.data[0].rider_name)
          if(typeof(res.data[0].rider_name) !== "undefined"){
            this.setData({
              nen: res.data[0].rider_name
            })
          } else {
            db.collection('customer').where({
              stu_ID: target0
          })
            .get({
              success: res => {
                console.log(res.data[0].username)
              this.setData({
                nen: res.data[0].username
              })
            }
            })



          }         
        }
        })
  },

  Changeicon:function(){
    wx.navigateTo({
      url: '/pages/homepage_rider/homepage_rider',
    })
  },
Get_icon:function(){
        var _id=this.data._id;
        console.log('骑手端id为',_id);
        wx.cloud.callFunction({
        name: 'runDB',
        data: {
          type:"get", //指定操作是get  查找
          collection:"rider", //指定操作的集合
          condition:{ //指定where查找的要求字段
            _id:_id,
          }
        },
        complete: res => {
          this.setData({
            myInfo: res.result.data,
            my_icon_url: res.result.data[0].rider_icon_url
          })
          console.log('骑手端my_icon_url为', this.data.my_icon_url)
        }
      })
},
  //进入主页
  home() {
    wx.switchTab({
      url: '/pages/homepage_rider/homepage_rider',
    })
  },


  //进入账号管理
  setting() {
    wx.navigateTo({
      url: '/pages/setting_rider/setting_rider',
    })
  },

  //初次进入点击登录注册跳转
  signinorup() {
    wx.navigateTo({
      url: '/pages/signin_rider/signin_rider',
    })
  },

  //进入意见反馈
  feedback() {
    wx.navigateTo({
      url: '/pages/feedback/feedback',
    })
  },

  //进入评价情况
  evaluation() {
    wx.navigateTo({
      url: '/pages/evaluation/evaluation',
    })
  },

  //收入统计
  my_menu() {
    wx.navigateTo({
      url: '/pages/riderFinancial/riderFinancial',
    })
  }




})

