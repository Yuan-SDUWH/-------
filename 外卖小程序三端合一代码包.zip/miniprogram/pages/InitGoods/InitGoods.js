// miniprogram/pages/InitGoods/InitGoods.js
wx.cloud.init({
  env: 'bluetooth-fd3ok'
})
const db = wx.cloud.database({
  env: 'bluetooth-fd3ok'
})

/*删除键的两个功能：
**保存后flag置1，上传后flag置0
**
*/

Page({

  /**
   * 页面的初始数据
   */
  data: {
    array: [0],//默认显示一个
    inputName: [],//所有input的内容
    inputPrice: [],//单价
    inputPackage: [],//包装费
    inputDonatePercent: [],//公益抽成百分比
    inputAppPercent: [],//平台抽成百分比
    inputCategory: [],//商品类别
    inputMaterial: [],//商品食材  
    inputTaste: [],//商品口味
    CurrentData: [],
    tmpURL: [],//图片临时URL
    cloudURL:[],//云URL
  },
  //获取各个input的值
  //名称
  getInputName: function (e) {
    var nowIdx = e.currentTarget.dataset.idx;//获取当前索引
    var val = e.detail.value;//获取输入的值
    var oldName = this.data.inputName;
    oldName[nowIdx] = val;//修改对应索引值的内容
    this.setData({
      inputName: oldName
    })
    console.log(this.data.inputName);
  },
  //价格
  getInputPrice: function (e) {
    var nowIdx = e.currentTarget.dataset.idx;//获取当前索引
    var val = e.detail.value;//获取输入的值
    var oldPrice = this.data.inputPrice;
    oldPrice[nowIdx] = val;//修改对应索引值的内容
    this.setData({
      inputPrice: oldPrice
    })
    console.log(this.data.inputPrice);
  },
  //包装费
  getInputPackage: function (e) {
    var nowIdx = e.currentTarget.dataset.idx;//获取当前索引
    var val = e.detail.value;//获取输入的值
    var oldPackage = this.data.inputPackage;
    oldPackage[nowIdx] = val;//修改对应索引值的内容
    this.setData({
      inputPackage: oldPackage
    })
    console.log(this.data.inputPackage);
  },
  //公益捐助百分比
  getInputDonatePercent: function (e) {
    var nowIdx = e.currentTarget.dataset.idx;//获取当前索引
    var val = e.detail.value;//获取输入的值
    var oldDonatePercent = this.data.inputDonatePercent;
    oldDonatePercent[nowIdx] = val;//修改对应索引值的内容
    this.setData({
      inputDonatePercent: oldDonatePercent
    })
    console.log(this.data.inputDonatePercent);
  },
  //平台抽成百分比
  getInputAppPercent: function (e) {
    var nowIdx = e.currentTarget.dataset.idx;//获取当前索引
    var val = e.detail.value;//获取输入的值
    var oldAppPercent = this.data.inputAppPercent;
    oldAppPercent[nowIdx] = val;//修改对应索引值的内容
    this.setData({
      inputAppPercent: oldAppPercent
    })
    console.log(this.data.inputAppPercent);
  },
  //类别
  getInputCategory: function (e) {
    var nowIdx = e.currentTarget.dataset.idx;//获取当前索引
    var val = e.detail.value;//获取输入的值
    var oldCategory = this.data.inputCategory;
    oldCategory[nowIdx] = val;//修改对应索引值的内容
    this.setData({
      inputCategory: oldCategory
    })
    console.log(this.data.inputCategory);
  },
  //食材
  getInputMaterial: function (e) {
    var nowIdx = e.currentTarget.dataset.idx;//获取当前索引
    var val = e.detail.value;//获取输入的值
    var oldMaterial = this.data.inputMaterial;
    oldMaterial[nowIdx] = val;//修改对应索引值的内容
    this.setData({
      inputMaterial: oldMaterial
    })
    console.log(this.data.inputMaterial);
  },
  //口味
  getInputTaste: function (e) {
    var nowIdx = e.currentTarget.dataset.idx;//获取当前索引
    var val = e.detail.value;//获取输入的值
    var oldTaste = this.data.inputTaste;
    oldTaste[nowIdx] = val;//修改对应索引值的内容
    this.setData({
      inputTaste: oldTaste
    })
    console.log(this.data.inputTaste);
  },


  //添加input菜品框
  addInput: function () {
    var old = this.data.array;
    old.push(1);//这里不管push什么，只要数组长度增加1就行
    this.setData({
      array: old,
    })
    /*
    var storeid = wx.getStorageSync('id');
    */
  },


  //删除input
  delInput: function (e) {
      var i=0;//循环变量
      var that = this;
      //以下一部分代码负责删除view标签，勿动
      var nowidx = e.currentTarget.dataset.idx;//
      console.log(nowidx);
      var oldarr = that.data.array;//循环内容
      oldarr.splice(nowidx, 1);    //删除当前索引的内容，这样就能删除view了
      if (oldarr.length < 1) {
        oldarr = [0]  //如果循环内容长度为0即删完了，必须要留一个默认的。这里oldarr只要是数组并且长度为1，里面的值随便是什么
      }
      var oldInputName = that.data.inputName;//所有输入的Name
      console.log("删除前的名称数组：",oldInputName);
      oldInputName.splice(nowidx, 1);//view删除了之后，数组中对应的Name值也要删掉

      var oldInputPrice = that.data.inputPrice;//所有输入的Price
      console.log("删除前的价格数组",oldInputPrice);
      oldInputPrice.splice(nowidx,1);

      var oldInputPackage = that.data.inputPackage;//所有输入的Package
      console.log("删除前的包装费数组", oldInputPackage);
      oldInputPackage.splice(nowidx, 1);

      var oldInputDonatePercent = that.data.inputDonatePercent;//所有输入的DonatePercent
      console.log("删除前的公益抽成数组", oldInputDonatePercent);
      oldInputDonatePercent.splice(nowidx, 1);

      var oldInputAppPercent = that.data.inputAppPercent;//所有输入的AppPercent
      console.log("删除前的平台抽成数组", oldInputAppPercent);
      oldInputAppPercent.splice(nowidx, 1);

      var oldInputCategory = that.data.inputCategory;//所有输入的Category
      console.log("删除前的商品类别数组", oldInputCategory);
      oldInputCategory.splice(nowidx, 1);

      var oldInputMaterial = that.data.inputMaterial;//所有输入的Material
      console.log("删除前的商品食材数组", oldInputMaterial);
      oldInputMaterial.splice(nowidx, 1);

      var oldInputTaste = that.data.inputTaste;//所有输入的Taste
      console.log("删除前的商品口味数组", oldInputTaste);
      oldInputTaste.splice(nowidx, 1);

      var oldImg = that.data.cloudURL;//所有菜品图片URL构成的数组
      var oldTmp = that.data.tmpURL;//这里删除的意义：为了使view显示正常
      console.log("删除前的图片URL数组", oldImg);
      oldImg.splice(nowidx,1);
      oldTmp.splice(nowidx,1);

      that.setData({
        array: oldarr,
        inputName: oldInputName,
        inputPrice: oldInputPrice,
        inputDonatePercent: oldInputDonatePercent,
        inputAppPercent: oldInputAppPercent,
        inputCategory: oldInputCategory,
        inputMaterial: oldInputMaterial,
        inputTaste: oldInputTaste,
        cloudURL: oldImg,
        tmpURL: oldTmp,
      })
      console.log("删除完毕后的名称数组：",that.data.inputName);
      console.log("删除完毕后的价格数组：",that.data.inputPrice);
      console.log("删除完毕后的包装费数组：", that.data.inputPackage);
      console.log("删除完毕后的公益抽成数组：", that.data.inputDonatePercent);
      console.log("删除完毕后的平台抽成数组：", that.data.inputAppPercent);
      console.log("删除完毕后的商品类别数组：", that.data.inputCategory);
      console.log("删除完毕后的商品食材数组：", that.data.inputMaterial);
      console.log("删除完毕后的商品口味数组：", that.data.inputTaste);
      console.log("删除完毕后的图片云URL数组：", that.data.cloudURL);
      
      var aim=[];
      aim.length=that.data.inputName.length;//保证长度一致
      for(i=0;i<that.data.inputName.length;i++)
      {
        aim[i]=[{"商品名称":that.data.inputName[i]},{"商品单价_元":that.data.inputPrice[i]},{"包装费_元":that.data.inputPackage[i]},{"商品类别":that.data.inputCategory[i]},{"商品食材":that.data.inputMaterial[i]},{"商品口味":that.data.inputTaste[i]},{"公益抽成百分比":that.data.inputDonatePercent[i]},{"平台抽成百分比":that.data.inputAppPercent[i]},{"商品图片":that.data.cloudURL[i]}];
        //console.log("aim[i]=",aim[i])
      }
      console.log("aim（经过删除后的商品清单）",aim)
      //以下和数据库对接(aim是存放删除后所有商品信息的最新数组)
      var storeid = wx.getStorageSync('id');
      //测试id:"1acf1de95e4125a40d5819105fd99f4a"
      db.collection('store').doc(storeid).update({
        data: {
          goods: aim,
        },
        complete: function (res) {
          console.log('删除成功')
        }
      })
  },


  Save(){
    /*************************以下勿动**********************/
    var that = this;
    let NameUp = that.data.inputName[that.data.inputName.length-1];
    //console.log("NameUp:（要保存的是数组的最新一项）",NameUp[NameUp.length-1])
    let PriceUp = that.data.inputPrice[that.data.inputPrice.length-1];
    let PackageUp = that.data.inputPackage[that.data.inputPackage.length - 1];
    let DonatePercentUp = that.data.inputDonatePercent[that.data.inputDonatePercent.length - 1];
    let AppPercentUp = that.data.inputAppPercent[that.data.inputAppPercent.length - 1];
    let CategoryUp = that.data.inputCategory[that.data.inputCategory.length - 1];
    let MaterialUp = that.data.inputMaterial[that.data.inputMaterial.length - 1];
    let TasteUp = that.data.inputTaste[that.data.inputTaste.length - 1];
    let Imageup = that.data.fileIDs;
    PriceUp=parseFloat(PriceUp);
    PackageUp=parseFloat(PackageUp);
    DonatePercentUp = parseFloat(DonatePercentUp);
    AppPercentUp = parseFloat(AppPercentUp);
    var storeid = wx.getStorageSync('id');
    //取出数据库现有的数据
    db.collection('store').doc(storeid).get({
      success: function(res) {
        that.setData({
          CurrentData: res.data
        })
        //增加新的数据(数据库中goods是一个二维数组)
        that.data.CurrentData.goods.push([{"商品名称": NameUp},{"商品单价_元": PriceUp},{"包装费_元": PackageUp},{"商品类别": CategoryUp},{"商品食材": MaterialUp},{"商品口味": TasteUp},{"公益抽成百分比": DonatePercentUp},{"平台抽成百分比": AppPercentUp},{"商品图片": Imageup}])
        console.log(that.data.CurrentData.goods);
        db.collection('store').doc(storeid).update({
          data: {
            goods: that.data.CurrentData.goods,
          },
          complete: function (res) {
            console.log('上传成功');
            wx.showToast({
              title: '上传成功！',
            })
          }
        })
        },
        
    })
    /*
    wx.showToast({
      title: '保存成功！',
    })*/
  },
/*
  upLoad(){
    var that = this;
    var storeid = wx.getStorageSync('id');
    db.collection('store').doc(storeid).update({
      data: {
        goods: that.data.CurrentData.goods,
      },
      complete: function (res) {
        console.log('上传成功')
      }
    })
    wx.showToast({
      title: '上传成功！',
    })
  },
*/

  NextPage: function(){
    wx.navigateTo({
      url: '../InitOver/InitOver',
    })
  },

  takePhoto: function () { //拍照
    let _this = this
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      success(res) {
        // tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths
        let URL = _this.data.tmpURL
        URL.push(tempFilePaths);
        _this.setData({
          tmpImg: tempFilePaths,
          tmpURL: URL,
        })
        _this.saveImg();
      }
    })
  },

  saveImg: function () {  //保存图片
    var that = this;
    let filePath = that.data.tmpImg[that.data.tmpImg.length-1];
    let suffix = /\.[^\.]+$/.exec(filePath)[0];  //正则表达式
    wx.cloud.uploadFile({    //上传文件到云空间
      cloudPath: "Camera/" + new Date().getTime() + suffix,
      filePath: filePath,//临时的图片路径
      config: { env: 'bluetooth-fd3ok' }
    }).then(res => {
      console.log(res);
      var cloudy = that.data.cloudURL//已有的云URL数组
      var imgID = res.fileID;
      cloudy.push(imgID)
      that.setData({
        fileIDs: res.fileID,
        //tmpImg: null,
        cloudURL: cloudy 
      });
      wx.showToast({
        title: '图片已确认',
      })
      console.log('fileID：', this.data.fileIDs)
    })
  },
})


