// miniprogram/pages/Signin.js
Page({
  data: {
    账号: '',
    密码: ''
  },
  //获取用户账号
  inputAccount(event) {
    //   console.log('获取输入的账号', event.detail.value)
    this.setData({
      账号: event.detail.value
    })
  },
  // 获取密码
  inputPassword(event) {
    console.log('获取输入的密码', event.detail.value)
    this.setData({
      密码: event.detail.value
    })
  },

  //登陆
  signin() {
    let 账号 = this.data.账号
    let 密码 = this.data.密码
    console.log('账号', 账号, '密码', 密码)
    //登陆
    wx.cloud.database().collection('store').where({
      账号: 账号
    }).get({
      success(res) {
        console.log("获取数据成功", res)
        let store = res.data[0]
        console.log("store", store)
        if (密码 == store.密码) {
          console.log('登陆成功')
          wx.showToast({
            title: '登陆成功',
          })
          wx.reLaunch({
            url: '../index/index'
          })
          //保存登陆状态
          wx.setStorageSync('MyStore', store)
          wx.setStorageSync('id',store._id)
        } else {
          console.log('登陆失败')
          wx.showToast({
            icon: 'none',
            title: '账号或密码不正确',
          })
        }
      },
      fail(res) {
        console.log("获取数据失败", res)
      }
    })
  },
})