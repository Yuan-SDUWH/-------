//index.js
const app = getApp()
var util = require('../../utils/util.js');
const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`

Page({
  // 捎带物品没有取货码，而是物品内容，填上未接单这一状态
  data: {
    currentTab: 0,
  
  },
  onLoad(){
 
  },
  Tochart() {
    wx.navigateTo({
      url: '../income_chart/income_chart'
    })
  },
  ToOrder() {
    wx.navigateTo({
      url: '../ShowOrder_1/ShowOrder_1'
    })
  },
  ToSeeNumber() {
    wx.navigateTo({
      url: '../number_rider/number_rider'
    })
  },
  onShow() {
   
    this.setData({
      currentTab: 0
    })
  
  },
  

})