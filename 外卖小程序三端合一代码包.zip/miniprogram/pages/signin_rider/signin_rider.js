// miniprogram/pages/signin/signin.js
//登录
Page({
  data: {
    stu_ID: '',
    密码: ''
  },
  //获取学工号 存入stu_ID
  inputAccount(event) {
 //   console.log('获取学工号', event.detail.value)
    this.setData({
      stu_ID: event.detail.value
    })
  },
  // 获取密码  存入密码
  inputPassword(event) {
    console.log('获取输入的密码', event.detail.value)
    this.setData({
      密码: event.detail.value
    })
  },
  //去注册
  signup() {
    wx.navigateTo({
      url: '/pages/signup_rider/signup_rider',
    })
  },

  //登陆
  signin() {
    //获取输入的学工号和密码 存入stu_ID，密码
    let stu_ID = this.data.stu_ID
    let 密码 = this.data.密码
    console.log('学工号',stu_ID, '密码', 密码)
    //校验学工号，不合格禁止
    if (stu_ID.length < 8) {
      wx.showToast({
        icon: 'none',
        title: '学工号至少8位',
      })
      return
    }
    //学工号合格后检验密码 不合格禁止
    if (密码.length < 6) {
      wx.showToast({
        icon: 'none',
        title: '密码至少6位',
      })
      return
    }
  //密码和学工号格式都合格
  //登陆  先在customer里判断，如果没有，就去注册界面     如果有，就去判断rider里有吗   若rider里有，直接登录；若没有，则初始化rider里的记录然后再登录
  wx.cloud.database().collection('customer').where({
    stu_ID: stu_ID
  }).get({
    success(res) {
      console.log("访问customer判断是否有这个学工号  访问成功", res)
      //获取这个学工号的customer的所有信息存入customer
      let customer = res.data[0]
      //获取不到  提示不操作
      if(res.data.length==0){
        wx.showToast({
          icon:'none',
          title: '学工号未注册',
        })
      }
      console.log("customer集合里按照学号获取到的记录", customer)
      //判断密码对吗
      if (密码 == customer.密码) {
        console.log('登陆成功')
        wx.showToast({
          title: '登陆成功',
        })
        wx.setStorage({
          data: true,
          key: 'isSignin_rider',//查询本地缓存isSignin字段为true则代表用户已经登陆过 可以直接跳转功能页面
          
        }),
        //缓存存入rider的学号成功
          wx.setStorage({
          data: {'stu_ID':stu_ID},
          key: 'rider',//查询本地缓存isSignin字段为true则代表用户已经登陆过 可以直接跳转功能页面
          }),
        //customer里有这个学号之后，判断rider里有吗  并将rider的这个用户的信息存入rider变量
          wx.cloud.database().collection('rider').where({
            stu_ID: stu_ID
          }).get({
            success(res) {
              let rider = res.data[0]
              if (res.data.length == 0) {
              //rider里还没有这条信息，表示该customer未注册过骑手  向rider里增加基本信息
                wx.cloud.database().collection('rider').add({
                  data: {
                    stu_ID: stu_ID,
                    sales_number: {},
                    income: {},
                    rider_icon_url:''
                  },
                  success(res) {
                  //新添加rider记录成功获取其所有信息，存入缓存
                    wx.cloud.database().collection('rider').where({
                      stu_ID: stu_ID
                    }).get({
                      success(res) {
                        console.log("访问customer判断是否有这个学工号  访问成功", res)
                        //获取这个学工号的customer的所有信息存入customer
                        let rider = res.data[0]
                        wx.setStorageSync('rider', rider)
                          }
                        })
                    
                   console.log('rider集合添加记录成功', res)
                    wx.showToast({
                      title: '登录成功',
                    })

                  },
                  fail(res) {
                    console.log('登录失败', res)
                  }
                })

              }
              else{
                wx.cloud.database().collection('rider').where({
                  stu_ID: stu_ID
                }).get({
                  success(res) {
                    console.log("获取rider信息成功", res)
                    //获取这个学工号的customer的所有信息存入customer
                    let rider = res.data[0]

                  }
                })
                wx.setStorageSync('rider', rider)
              }
              wx.navigateTo({
                url: '../homepage_rider/homepage_rider',
              })


            } 
            }),
        wx.navigateTo({
          url: '../homepage_rider/homepage_rider',
        })
   //     wx.navigateTo({
    //       url: '../me/me?name=' + user.name,
    //     })//跳转到主页
        //保存用户登陆状态
        wx.setStorageSync('customer', customer)
        
      } else {
        console.log('登陆失败')
        wx.showToast({
          icon: 'none',
          title: '账号或密码不正确',
        })
      }
    },
    fail(res) {
      console.log("获取数据失败", res)
    }
  })

 }
})