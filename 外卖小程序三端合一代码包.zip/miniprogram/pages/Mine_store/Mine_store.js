const db = wx.cloud.database()

Page({
  data: {

  },
  onShow: function(){
    var mystore=wx.getStorageSync('MyStore');
    var img=mystore.store_icon_url;
    var name=mystore.store_name;
    this.setData({
      store_name:name,
      store_icon_url:img,
    })
  },
  navigateOrder:function(){
    wx.switchTab({
      url: '../Order_store/Order_store',
    })
  },
  myStore: function () {
    wx.navigateTo({
      url: '../MyStore/MyStore',
    })
  },
  goFeedback: function(){
    wx.navigateTo({
      url: '../feedback/feedback',
    })
  },
  logout:function(){
    wx.setStorageSync('MyStore',{});
    wx.showModal({
      title: '退出登录',
      content: '要退出登录吗？',
      showCancel:true,
      cancelText: "取消",
      cancelColor: "#000",
      confirmText: "确定",
      confirmColor: "#0a0",
      success: function (res) {
        if(res.confirm){
          wx.navigateTo({
            url: '../Login/Login',
          })
        }
      }
    })
  },
  changePasswd: function () {
    wx.navigateTo({
      url: '../ChangePasswd/ChangePasswd',
    })
  },
  pushCourse: function(){
    wx.navigateTo({
      url: '../out/out',
    })
  },
  finance: function(){
    wx.switchTab({
      url: '../financialManagement/financialManagement',
    })
  },
  aboutUs: function(){
    wx.navigateTo({
      url: '../AboutUs/AboutUs',
    })
  },
  openFile:function(){
    wx.navigateTo({
      url: '../Files/Files',
    })
  }

})