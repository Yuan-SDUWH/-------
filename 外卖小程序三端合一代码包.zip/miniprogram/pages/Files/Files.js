// miniprogram/pages/Files/Files.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  file1:function(){
    wx.showModal({
      title: '链接将为您复制到剪贴板',
      content: "https://atta.szlcsc.com/upload/public/pdf/source/20160103/1457707674891.pdf",
      success: function (res){
        if(res.confirm){
          wx.setClipboardData({
            data: "https://atta.szlcsc.com/upload/public/pdf/source/20160103/1457707674891.pdf",
            success: function (res) {
              console.log("复制成功");
            }
          });
        }
      }
    })
  },

  file2: function () {
    wx.showModal({
      title: '链接将为您复制到剪贴板',
      content: "https://atta.szlcsc.com/upload/public/pdf/source/20170428/1493376821608.pdf",
      success: function (res) {
        if(res.confirm)
        {
          wx.setClipboardData({
            data: "https://atta.szlcsc.com/upload/public/pdf/source/20170428/1493376821608.pdf",
            success: function (res) {
              console.log("复制成功");
            }
          });
        }
      }
    })
  },

  file3: function () {
    wx.showModal({
      title: '链接将为您复制到剪贴板',
      content: "https://atta.szlcsc.com/upload/public/pdf/source/20170920/C25624_1505901467893983212.pdf",
      success: function (res) {
        if(res.confirm)
        {
          wx.setClipboardData({
            data: "https://atta.szlcsc.com/upload/public/pdf/source/20170920/C25624_1505901467893983212.pdf",
            success: function (res) {
              console.log("复制成功");
            }
          });
        }   
      }
    })
  },

  file4: function () {
    wx.showModal({
      title: '链接将为您复制到剪贴板',
      content: "https://atta.szlcsc.com/upload/public/pdf/source/20191219/C84263_29D7A2D9C914CF835E4668C888CF5347.pdf",
      success: function (res) {
        if(res.confirm)
        {
          wx.setClipboardData({
            data: "https://atta.szlcsc.com/upload/public/pdf/source/20191219/C84263_29D7A2D9C914CF835E4668C888CF5347.pdf",
            success: function (res) {
              console.log("复制成功");
            }
          });
        }
        
      }
    })
  },

  file5: function () {
    wx.showModal({
      title: '链接将为您复制到剪贴板',
      content: "https://atta.szlcsc.com/upload/public/pdf/source/20160516/1463363924063.pdf",
      success: function (res) {
        if(res.confirm)
        {
          wx.setClipboardData({
            data: "https://atta.szlcsc.com/upload/public/pdf/source/20160516/1463363924063.pdf",
            success: function (res) {
              console.log("复制成功");
            }
          });
        }
        
      }
    })
  },

  file6: function () {
    wx.showModal({
      title: '链接将为您复制到剪贴板',
      content: "https://atta.szlcsc.com/upload/public/pdf/source/20170418/1492506316853.pdf",
      success: function (res) {
        if(res.confirm)
        {
          wx.setClipboardData({
            data: "https://atta.szlcsc.com/upload/public/pdf/source/20170418/1492506316853.pdf",
            success: function (res) {
              console.log("复制成功");
            }
          });
        }    
      }
    })
  },
  file7: function () {
    wx.showModal({
      title: '链接将为您复制到剪贴板',
      content: "https://atta.szlcsc.com/upload/public/pdf/source/20190422/C360607_488BF412150F6260D2FED34B70FF873E.pdf",
      success: function (res) {
        if(res.confirm)
        {
          wx.setClipboardData({
            data: "https://atta.szlcsc.com/upload/public/pdf/source/20190422/C360607_488BF412150F6260D2FED34B70FF873E.pdf",
            success: function (res) {
              console.log("复制成功");
            }
          });
        }
        
      }
    })
  },
  file8: function () {
    wx.showModal({
      title: '链接将为您复制到剪贴板',
      content: "https://atta.szlcsc.com/upload/public/pdf/source/20170914/C94598_1505374148208969226.pdf",
      success: function (res) {
        if(res.confirm)
        {
          wx.setClipboardData({
            data: "https://atta.szlcsc.com/upload/public/pdf/source/20170914/C94598_1505374148208969226.pdf",
            success: function (res) {
              console.log("复制成功");
            }
          });
        }
        
      }
    })
  },
  file9: function () {
    wx.showModal({
      title: '链接将为您复制到剪贴板',
      content: "https://atta.szlcsc.com/upload/public/pdf/source/20170522/1495448326861.pdf",
      success: function (res) {
        if(res.confirm)
        {
          wx.setClipboardData({
            data: "https://atta.szlcsc.com/upload/public/pdf/source/20170522/1495448326861.pdf",
            success: function (res) {
              console.log("复制成功");
            }
          });
        }
        
      }
    })
  },
})