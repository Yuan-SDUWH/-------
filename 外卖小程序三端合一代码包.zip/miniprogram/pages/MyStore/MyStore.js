// miniprogram/pages/MyStore/MyStore.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },




  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var MyStore=wx.getStorageSync('MyStore');
    var _id=MyStore._id;
    var store_name=MyStore.store_name;
    var prepareTime=MyStore.prepareTime;
    var invite=MyStore.店铺介绍
    var rejectNum=MyStore.拒单次数
    var successNum=MyStore.订单成功交易量_笔
    this.setData({
      _id:_id,
      store_name:store_name,
      prepareTime:_id,
      invite:invite,
      rejectNum:rejectNum,
      successNum:successNum,
    })
  },

  
})