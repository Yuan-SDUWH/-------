Page({
  Signin: function(){
    wx.navigateTo({
      url: '../Signin_store/Signin_store',
    })
  },

  Signup: function () {
    wx.navigateTo({
      url: '../Signup_store/Signup_store',
    })
  },

})