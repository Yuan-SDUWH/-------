//index.js
const app = getApp()
var util = require('../../utils/util.js');
const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`

Page({
  // 捎带物品没有取货码，而是物品内容，填上未接单这一状态
  data: {
    navbar: ['快递', '购物','捎带物品'],
    currentTab: 0,
    time: '',
    today: '',
    time_get: {},
    需求种类:'', 
    blockid:0,
    bgcolor:'#ffffff',
    color:"#989898",
    selectedColor:'#FF6802',
    showborder:false,
    bordercolor:"",
    tabbar:[
      {
        pagePath: "../homepage_rider/homepage_rider",
        selectedIconPath: '../../images/homepage/home_icon_press.png',
        iconPath: '../../images/homepage/home_icon_nor.png',
        text: '首页',
     //   isdot: false,
    //    number: 0
      }, {
        pagePath: "../my_menu/my_menu",
        selectedIconPath: '../../images/homepage/find_icon_press.png',
        iconPath: '../../images/homepage/find_icon_nor.png',
        text: '订单',
     //   isdot: true,
      //  number: 0
      }, {
        pagePath: "../mine_rider/mine_rider",
        selectedIconPath: '../../images/homepage/mine_icon_press.png',
        iconPath: '../../images/homepage/mine_icon_nor.png',
        text: '我的',
     //   isdot: false,
      //  number: 5
      }
    ]
  },
   // event.detail 的值为当前选中项的索引
   tabbarChange(e) {
   
    var index = parseInt(e.detail);
   
    if(index!=0){
      wx.navigateTo({
        url: this.data.tabbar[index].pagePath,
      })
    }
     this.setData({
      blockid:index
    })
  },
  onLoad(){
    this.getOrder();
  },
  getOrder: function (e) {



    // var userid = wx.getStorageSync('id');
    // console.log(userid);
    if(this.data.currentTab==0)
    {
      this.setData({
        需求种类:"快递"
      })
    }
    else if (this.data.currentTab == 1){
      this.setData({
        需求种类: "购物"
      })
    }
    else {
      this.setData({
        需求种类: "捎带物品"
      })}
      let 需求种类=this.data.需求种类
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "extra_need", //指定操作的集合
        condition: { //指定where查找的要求字段
          需求种类: 需求种类,
          当前状态: "待接单"
        }
      },
      success: res => {
        this.setData({
          showKuaidi: res.result.data,
        });
        console.log(this.data.showKuaidi)
      }
    })  
  },


  readDetail: function (e) {
    var date = util.formatTime1(new Date());
    var minutes = util.formatTime2(new Date());
    var $_id = e.currentTarget.dataset.id; //打印可以看到，此处已获取到了对应的id
    console.log($_id);

    //获取当前的stu_ID
//获取
     var _rider = wx.getStorageSync('rider');
     var userid = _rider.stu_ID
  var sign = wx.getStorageSync('isSignin_rider');
  if(!sign){
    wx.showToast({
      title: '请先登录',
      icon: 'none',
      duration:2000
    })
    wx.navigateTo({
      url: '../signin_rider/signin_rider',
    })
  }
else{
  console.log(userid);
  wx.cloud.callFunction({
    name: 'runDB',
    data: {
      type: "update", //指定操作是update
      collection: "extra_need", //指定操作的集合
      _id: $_id,
      data: { //指定update的数据
        "当前状态": "已接单",
        time_get: { 'date': date, 'minutes': minutes },
        rider_ID: userid
      }
    },
    success: res => {
      console.log('[云函数] [updateDB] 已更改当前状态信息' + $_id)
      wx.showToast({
        title: '接单成功',
      })
    },
    fail: err => {
      console.error('[云函数] [updateDB]更改当前状态失败', err)
    }
  }),
    this.getOrder();
    this.onLoad();
}
   
  },
  //切换bar
  navbarTap: function (e) {
    this.setData({
      currentTab: e.currentTarget.dataset.idx   
    })
    //全局变量
    // app.globalData.currentTab = e.currentTarget.dataset.idx;
    console.log(e.currentTarget.dataset.idx)
    this.getOrder()
    
  },
  onShow() {
   
    this.setData({
      currentTab: 0
    })
  
  },
  

})