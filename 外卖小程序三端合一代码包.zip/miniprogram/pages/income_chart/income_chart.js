// pages/addFunction/addFunction.js

// let app1 = getApp();
//拿到小程序app.js的对象

const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`

var wxCharts = require('../../utils/wxCharts.js');
var app = getApp();
var daylineChart = null;
var yuelineChart = null;


Page({

  /**
   * 页面的初始数据
   */
  data: {
    result: '',
    canIUseClipboard: wx.canIUse('setClipboardData'),
    // todaydate:'_2020_02_01'
    mysale1: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    mysale2: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    sales:[],
    today_year: '',
    today_month: '',
    today_day: ''
  },






  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    //console.log(app1.globalData)


    this.getToday();
   // this.testFunction(); 


  //  this.yueTouchHandler();
    this.getMothElectro();
     //console.log(mysale.test);
    
  },


  testFunction: function () {
    var _customer = wx.getStorageSync('customer');
    console.log('customer',_customer)
    var userid = _customer.stu_ID;

    console.log('userid',userid);
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "rider", //指定操作的集合
        condition: { //指定where查找的要求字段
          stu_ID: userid
        }
      },
      success: res => {
        this.setData({
          mysale1: res.result.data[0],
  
        });
  
        console.log(this.data.mysale1)


 
      }
    })
  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },

  getMothElectro: function (mysale) {
    var windowWidth = 320;

    this.testFunction();
    var me = this;
    var sales1 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
  
    var sales2 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    
    //console.log(sales1)
    setTimeout(function () {
            // var time;
            // var i = me.data.today_day-7;
            // var j =0;
            // var m ;

      var time;
      var i = me.data.today_day - 7;
      var this_month = me.data.today_month;
      var j = 0;
      var m;
      for (m = 1; m < 31; m++) {
        if(m<10){
        time = '_' + me.data.today_year + '_' + this_month + '_' +'0'+ m;
        }
        else{
          time = '_' + me.data.today_year + '_' + this_month + '_' + m;
        }
        console.log(time);
        if (typeof me.data.mysale1.sales_number[time] != 'undefined') {
          sales1[j] = me.data.mysale1.sales_number[time];
          console.log(me.data.mysale1.sales_number[time])
        };
        if (typeof me.data.mysale1.income[time] != 'undefined') {
          sales2[j] = me.data.mysale1.income[time];
          console.log(me.data.mysale1.income[time])
        };



        j++;
      }

            // for (m=i; m<i+7; m++) {
            //   time = '_' + me.data.today_year + '_' + me.data.today_month + '_' + m;        
            //   if (typeof me.data.mysale1.income[time] != 'undefined') {
            //      sales1[j] = me.data.mysale1.income[time];  
            //     console.log(me.data.mysale1.income[time])
            //   }
            //   j++
            //   }
            //  i = me.data.today_day - 30;
            //  j=0;
            // for (m = i; m < i + 30; m++) {
            //   time = '_' + me.data.today_year + '_' + me.data.today_month + '_' + m; 
            //   if (typeof me.data.mysale1.income[time] != 'undefined') {
            //     sales2[j] = me.data.mysale1.income[time];
            //     console.log(me.data.mysale1.income[time])
            //   };                     
            //  j++
            
          
            // }
            console.log(sales1);
            console.log(sales2);

      yuelineChart = new wxCharts({ 
        canvasId: "yueEle",
        type: 'line',
        categories: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30'] , //categories X轴
        animation: true,
        // background: '#f5f5f5',
        series: [
          {

            name: '本月收入分析',
            data: sales2,

            format: function (val, name) {
              return val.toFixed(2) + '元';
            }
          }],
        xAxis: {
          disableGrid: false
        },
        yAxis: {
          title: '收入(元/天)',
          format: function (val) {
            return val.toFixed(2);
          },
          max: 500,
          min: 0
        },
        width: windowWidth,
        height: 200,
        dataLabel: false,
        dataPointShape: true,
        extra: {
          lineStyle: 'curve'
        }
      });



    }, 1000) //延迟时间 这里是1秒
    
    try {
      var res = wx.getSystemInfoSync();
      windowWidth = res.windowWidth;
    } catch (e) {
      console.error('getSystemInfoSync failed!');
    }

   

    yuelineChart = new wxCharts({ //当月用电折线图配置Float("{{mysale.test}}")
      canvasId: "yue2Ele",
      type: 'line',
      categories: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30' ] ,//categories X轴
      animation: true,
      // background: '#f5f5f5',
      series: [
     
        {
          name: '本月订单数分析',
          data: sales1,
          format: function (val, name) {
            return val.toFixed(2) + '元';
          }
        }],
      xAxis: {
        disableGrid: false
      },
      yAxis: {
        title: '订单数(单/天)',
        format: function (val) {
          return val.toFixed(2);
        },
        max: 150,
        min: 0
      },
      width: windowWidth,
      height: 200,
      dataLabel: false,
      dataPointShape: true,
      extra: {
        lineStyle: 'curve'
      }
    });

  },


  getToday:function(){

    var timestamp = Date.parse(new Date());
    var date = new Date(timestamp);
    //获取年份  
    var Y = date.getFullYear();
    //获取月份  
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    //获取当日日期 
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    // console.log("_" + Y + '_' + M + '_' + D);
    var todaydate ="_" + Y + '_' + M + '_' + D;
    var today = this;
 
    today.setData({
      today_year  : Y,
      today_month: M,
      today_day: D,
    });
    // console.log(today.data.today_year);
    // console.log(today.data.today_month);
    // console.log(today.data.today_day)

  }

 })


