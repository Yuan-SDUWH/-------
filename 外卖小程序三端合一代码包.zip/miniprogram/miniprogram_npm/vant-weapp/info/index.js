import { VantComponent } from '../common/component';
VantComponent({
    props: {
        info: null,
        customStyle: String
    }
});
