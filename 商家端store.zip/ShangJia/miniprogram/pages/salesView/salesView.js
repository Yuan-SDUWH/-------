// pages/addFunction/addFunction.js

// let app1 = getApp();
//拿到小程序app.js的对象

const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`

Page({
  data: {
   storeGoods:'',
   storeOrder:'',
   todaydate:'',
    sales_today:[],
    sales_number_today:[],
    donation_today:[],
  },
  onLoad: function () {
    this.getToday();
    this.GetStoreGoods();
  },
  //获取商品列表存入storeGoods
  GetStoreGoods:function(){
 
    var _Store = wx.getStorageSync('MyStore');
    console.log('_Store', _Store)
   
    var userid = _Store._id;
    console.log(userid)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "store", //指定操作的集合
        condition: { //指定where查找的要求字段
          _id: userid
        }
      },
      success: res => {
        this.setData({
          storeGoods: res.result.data[0].goods
        })
        var todaydate = this.data.todaydate;
        var storeGoods = res.result.data[0].goods;
        //获取订单列表
        wx.cloud.callFunction({
          name: 'runDB',
          data: {
            type: "get", //指定操作是get  
            collection: "order", //指定操作的集合
            condition: { //指定where查找的要求字段
              接单商家id: '81b25908-d5e8-4baa-a30c-cc55c7fe17c7',
              time_get_date: todaydate,
              订单状态:'已完成'
            }
          },
          success: res => {
            //两次运行云函数成功，获取到商家商品列表storeGoods和订单列表 storeOrder
            this.setData({
              storeOrder: res.result.data
            })
            var storeOrder = res.result.data;
          
            var i = 0;
            var m = 0;
            var n = 0;
            var storeGoods_length = storeGoods['length'];
            var storeOrder_length = storeOrder['length'];
          

            //console.log(storeGoods_length);
            //console.log(storeOrder_length);
            //console.log('订单列表storeOrder为',storeOrder);
            // console.log(goodsList_length);
            //初始化每个商品对应的今日销量，销售额，公益金额数组（初始化全为0）[0, 0, 0, 0, 0]
            var sales_today = [];
            var sales_number_today = [];
            var donation_today = [];
            for (i; i < storeGoods_length; i++) {
              sales_today[i] = 0;
              sales_number_today[i] = 0;
              donation_today[i] = 0;
            };
            i = 0;
            //对于每样菜品，循环一遍今日份的订单 i表示第i个商品
            for (i; i < storeGoods_length; i++) {
              var sales = 0;
              var sales_number = 0;
              var donation = 0;
              //遍历每个订单 m表示第m个订单
              m = 0;
              for (m; m < storeOrder_length; m++) {
                //console.log('订单列表长度为',storeOrder_length);
                // console.log('当前m为',m)
                // console.log('订单列表中的第m个订单的购买商品个数为',m,storeOrder[m].goodsList['length']);
                var goodsList_length = storeOrder[m].goodsList['length'];
                // console.log('第m个订单的商品长度为', m, goodsList_length)
                //遍历这个订单的每个商品 n表示这个订单中的第n个菜品
                n = 0;
                for (n; n < goodsList_length; n++) {
                  //判断第i个商品的名称storeGoods[i][0]['商品名称']是否与第m个订单的第n个菜品名称storeOrder[m].goodsList[n].name相同 若相同，则第i个菜品销量加storeOrder[m].goodsList[n].num  销售额增加storeOrder[m].goodsList[n].price 公益金额增加storeOrder[m].goodsList[n].price*storeOrder[m].goodsList[n].['公益抽成百分比']/100
                  var name = storeGoods[i][0]['商品名称']
                  if (storeOrder[m].goodsList[n].name == name) {
                    sales = sales + storeOrder[m].goodsList[n].price * storeOrder[m].goodsList[n].num;
                    sales_number = sales_number + storeOrder[m].goodsList[n].num;
                    donation = donation + storeOrder[m].goodsList[n].price * storeOrder[m].goodsList[n].num*storeOrder[m].goodsList[n]['公益抽成百分比'] / 100;

                    // console.log('现在商家的第i个商品**销量增加**',storeOrder[m].goodsList[n].name,storeOrder[m].goodsList[n].num);
                    // console.log('现在商家的第i个商品**销售额增加**', storeOrder[m].goodsList[n].name, storeOrder[m].goodsList[n].price);
                    // console.log('现在商家的第i个商品**公益百分比为**公益金额增加**', storeOrder[m].goodsList[n].name, storeOrder[m].goodsList[n]['公益抽成百分比'] / 100,storeOrder[m].goodsList[n].price*storeOrder[m].goodsList[n]['公益抽成百分比']/100);
                    //计算商家第i个商品的累计销量、累计销售额、累计捐助金额


                  }

                  //console.log("第m个订单中的第n个菜品为", m, n, storeOrder[m].goodsList[n])
                  //console.log("第m个订单中的第n个菜品名字为", m, n,storeOrder[m].goodsList[n].name)
                }
              }
              // console.log('第i个商品的今日销量为', i, sales_number);
              // console.log('第i个商品的今日销售额为', i, sales)
              // console.log('第i个商品的今日捐助金额为', i, donation);
              sales_today[i] = sales;
              sales_number_today[i] = sales_number;
              donation_today[i] = donation;
            }
            var that=this;
            that.setData({
              sales_today: sales_today,
              sales_number_today: sales_number_today,
              donation_today: donation_today
            }),
              console.log(sales_today);
            console.log(sales_number_today);
            console.log(donation_today);

            //console.log('商品列表storeGoods1为', this.data.storeGoods);
            // console.log('订单列表storeOrder1为',this.data.storeOrder)
          }
        })
        

      }
    })

  },
  //获取今日日期
  getToday: function () {
    var timestamp = Date.parse(new Date());
    var date = new Date(timestamp);
    //获取年份  
    var Y = date.getFullYear();
    //获取月份  
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    //获取当日日期 
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    var todaydate =  Y + '-' + M + '-' + D;
    var today = this;

    today.setData({
      todaydate: todaydate
    });
    console.log(today.data.todaydate)

  },
})