//index.js
var app = getApp()
Page({
  data: {

  },
  onShow: function () {
    var that = this;
    var storeid=wx.getStorageSync('id');
    var comment;
    var comment_speed;
    var comment_taste;
    var comment_health;
    var i;
    var sum=0;
    var allsum;
    var sum_speed=0;
    var allsum_speed;
    var sum_taste=0;
    var allsum_taste;
    var sum_health = 0;
    var allsum_health;
    wx.cloud.database().collection('store').doc(storeid).get({
      success(res){
        console.log('获取已登录商家数据成功',res)
        let storeIm=res.data;
        that.setData({
          store_name: storeIm.store_name,
          store_location: storeIm.店铺地址.建筑 + storeIm.店铺地址.楼层,
          store_icon_url: storeIm.store_icon_url,
          store_rate: storeIm.综合评分,
          store_delicious: storeIm.好吃程度评分,
          store_speed: storeIm.出餐速度评分,
          store_health: storeIm.饮食卫生评分,
          store_rejectNum:storeIm.拒单次数,
        })
        comment=storeIm.comment
        comment_speed=storeIm.comment_speed
        comment_taste=storeIm.comment_taste
        comment_health = storeIm.comment_health
        console.log('COMCOMCO',comment);
        for(i = 0;i<comment.length;i++)
        {
          sum+=comment[i];
          console.log('AAAAA',sum)
        }
        for (i = 0; i < comment_speed.length; i++) {
          sum_speed += comment_speed[i];
        }
        for (i = 0; i < comment_taste.length; i++) {
          sum_taste += comment_taste[i];
        }
        for (i = 0; i < comment_health.length; i++) {
          sum_health += comment_health[i];
        }
        console.log('SUMMMMM',sum)
        allsum=sum/comment.length;
        allsum_speed=sum_speed/comment_speed.length;
        allsum_taste=sum_taste/comment_taste.length;
        allsum_health=sum_health/comment_health.length;
        console.log('ALLSUN',allsum_health)
        wx.cloud.callFunction({
          name:'runDB',
          data:{
            type: 'update',
            collection: 'store',
            _id: storeid,
            data: {
              出餐速度评分: allsum_speed,
              好吃程度评分: allsum_taste,
              饮食卫生评分: allsum_health,
              综合评分: allsum,
            },
          },  
          success: res=>{
            console.log('双层嵌套读评分')
          }
        })
      },
      fail(res){
        console.log('获取数据失败')
      }
    })
  },
  Page1: function(){
    wx.navigateTo({
      url: '../AdjustStore/AdjustStore',
    })
  },
  Page2: function () {
    wx.navigateTo({
      url: '../AdjustGoods/AdjustGoods',
    })
  },
  switch1Change: function (e) {
    var that = this;
    var storeid=wx.getStorageSync('id');
    var storeNow;
    console.log('switch1 发生 change 事件，携带值为', e.detail.value)
    let openflag=e.detail.value;
    if(openflag==1)
    {
      storeNow='营业中'
    }
    else if(openflag==0)
    {
      storeNow='已打烊'
    }
    wx.cloud.database().collection('store').doc(storeid).update({
      data: {
        店铺状态: storeNow,
      },
      complete: function (res) {
        console.log('打烊/开业成功')
      }
    })
  },
  switch2Change: function (e) {
    var that = this;
    var storeid = wx.getStorageSync('id');
    console.log('switch2 发生 change 事件，携带值为', e.detail.value)
    let openflag = e.detail.value;
    if (openflag == 1) {
      wx.setStorageSync('autoTake', 1)
    }
    else if (openflag == 0) {
      wx.setStorageSync('autoTake', 0)
    }
    console.log('设置自动接单成功')
  }
})