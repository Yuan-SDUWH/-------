Page({
  Signin: function(){
    wx.navigateTo({
      url: '../Signin/Signin',
    })
  },

  Signup: function () {
    wx.navigateTo({
      url: '../Signup/Signup',
    })
  },

})