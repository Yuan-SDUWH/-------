// pages/addFunction/addFunction.js

// let app1 = getApp();
//拿到小程序app.js的对象

const db = wx.cloud.database()
const code = `// 云函数入口函数
exports.main = (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`
Page({
	data: {
    time: '',
    today:'',
    mysale1:'',
    store_icon_url:wx.getStorageSync('MyStore').store_icon_url
  },
	onLoad: function () {
    this.getToday();
    var _Store = wx.getStorageSync('MyStore');
    console.log('_Store', _Store)

    var userid = _Store._id;
    console.log(userid)
    wx.cloud.callFunction({
      name: 'runDB',
      data: {
        type: "get", //指定操作是get  
        collection: "store", //指定操作的集合
        condition: { //指定where查找的要求字段
          _id: userid
        }
      },
      success: res => {
        this.setData({
          mysale1: res.result.data[0],     
        });        
      }
    })
	},
	onShow: function () {
	
	},
  toOut: () => {
    wx.navigateTo({
      url: '../out/out',
    })
  },
  ToAnalysis: function () {
    wx.navigateTo({
      url: '../chart/chart'
    })
  },
  TosalesView: function () {
    wx.navigateTo({
      url: '../salesView/salesView'
    })
  },
  getToday: function () {

    var timestamp = Date.parse(new Date());
    var date = new Date(timestamp);
    //获取年份  
    var Y = date.getFullYear();
    //获取月份  
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    //获取当日日期 
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    // console.log("_" + Y + '_' + M + '_' + D);
    var today = this;
  

    today.setData({
      time : '_' + Y + '_' + M + '_' + D
    });

    console.log(today.data.time)

  },

});

